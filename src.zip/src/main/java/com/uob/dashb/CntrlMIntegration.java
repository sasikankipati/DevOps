package com.uob.dashb;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

public class CntrlMIntegration {

	public static void main(String[] args) {
		try {
			//connectCntrlM1();
			//connectCntrlM("http://ctmusg03:18080/ctmruninfo/GetRunInfoHistory");
			testConnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void connectCntrlM1(){
		try {
			BufferedReader reader=null;
			String urlParameters  = "dataCenter: table: app: group: jobName: owner: nodeID: jobStatus: ALLorderDateBeg:20160628 orderDateEnd:20160628 startTimeBeg: startTimeEnd: endTimeBeg: endTimeEnd:";
			byte[] postData       = urlParameters.getBytes( StandardCharsets.UTF_8 );
			int    postDataLength = postData.length;
			String request        = "http://ctmusg03:18080/ctmruninfo/GetRunInfoHistory";
			URL    url            = new URL( request );
			HttpURLConnection conn= (HttpURLConnection) url.openConnection();           
			conn.setDoOutput( true );
			conn.setInstanceFollowRedirects( false );
			conn.setRequestMethod( "POST" );
			conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			conn.setRequestProperty("Accept-Encoding", "gzip, deflate");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			conn.setRequestProperty( "Content-Length", Integer.toString( postDataLength ));
			conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
			conn.setUseCaches( false );
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(urlParameters);
			writer.flush();
			
			int status = conn.getResponseCode();
			if(HttpURLConnection.HTTP_OK == status){
	        	reader=new BufferedReader(new InputStreamReader(conn.getInputStream())); // now reading the data..
	            StringBuffer buff=new StringBuffer();
	            String outputData=null;
	            while((outputData=reader.readLine())!=null) {
	            	buff.append(outputData);
	            }
	        }
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	private static String connectCntrlM(String url) throws Exception{
		HttpURLConnection connection=null;
		BufferedReader reader=null;
		String charset = java.nio.charset.StandardCharsets.UTF_8.name(); //"UTF-8";  
		try{
			URL urlConnection=new URL(url);
			connection = (HttpURLConnection) urlConnection.openConnection();
			connection.setDoOutput(true); 
	        connection.setInstanceFollowRedirects(false); 
	        connection.setRequestMethod("POST"); 
	        connection.setConnectTimeout(5000); 
	        connection.setRequestProperty("Content-Type", "application/xml");
	        connection.setRequestProperty("Content-Language", "en-US");
	        connection.setRequestProperty("Accept-Charset", charset);
	        connection.setUseCaches(false);
	        connection.connect();
	        int status = connection.getResponseCode();
	        if(HttpURLConnection.HTTP_OK == status){
	        	reader=new BufferedReader(new InputStreamReader(connection.getInputStream())); // now reading the data..
	            StringBuffer buff=new StringBuffer();
	            String outputData=null;
	            while((outputData=reader.readLine())!=null) {
	            	buff.append(outputData);
	            }
	            return buff.toString();
	        }
	        else {
	        	return null;
	        }
		}
		catch(UnknownHostException uhe){
			uhe.printStackTrace();
			throw uhe;
		}
        catch(Exception ex){
        	ex.printStackTrace();
        	 throw ex;
        }finally {
			if(connection!=null) {
				connection.disconnect();
			}
			if(reader!=null) {
				try {
					reader.close();
				} catch (IOException e) {
				}
			}
		}
       // return "";
	}

	private static void testConnect(){
		try {
			BufferedReader reader;
			URL url = new URL("http://ctmusg03:18080/ctmruninfo/GetRunInfoHistory");
			Map<String,Object> params = new LinkedHashMap<>();
			params.put("dataCenter:", " ");
			params.put("table:", " ");
			params.put("app:", " ");
			params.put("group:", " ");
			params.put("jobName:", " ");
			params.put("owner:", " ");
			params.put("nodeID:", " ");
			params.put("jobStatus:", "ALL ");
			params.put("orderDateBeg:", "20160628 ");
			params.put("orderDateEnd:", "20160628 ");
			params.put("startTimeBeg:", " ");
			params.put("startTimeEnd:", " ");
			params.put("endTimeBeg:", " ");
			params.put("endTimeEnd:", "");

			StringBuilder postData = new StringBuilder();
			for (Map.Entry<String,Object> param : params.entrySet()) {
			   // if (postData.length() != 0) postData.append('&');
			    postData.append(param.getKey());
			    //postData.append('=');
			    postData.append(String.valueOf(param.getValue()));
			}
			String reqParam = "dataCenter=&table=&app=&group=&jobName=&owner=&nodeID=&jobStatus=ALL&orderDateBeg=20160628&orderDateEnd=20160628&startTimeBeg=&startTimeEnd=&endTimeBeg=&endTimeEnd=";
			byte[] postDataBytes = reqParam.toString().getBytes("UTF-8");

			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod( "POST" );
			conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			conn.setRequestProperty("Accept-Encoding", "gzip, deflate");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
			conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
			conn.setDoOutput(true);
			conn.getOutputStream().write(postDataBytes);

			int status = conn.getResponseCode();
	        if(HttpURLConnection.HTTP_OK == status){
	        	reader=new BufferedReader(new InputStreamReader(conn.getInputStream())); // now reading the data..
	            StringBuffer buff=new StringBuffer();
	            String outputData=null;
	            BufferedWriter bf = new BufferedWriter(new FileWriter("D:/JOB_28062016.csv"));
	            while((outputData=reader.readLine())!=null) {
	            	buff.append(outputData);
	            	buff.append("\n");
	            	
	            	bf.write(outputData);
	            	bf.write("\n");
	            }
	            bf.flush();
	            System.out.println(buff);
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
