package com.uob.dashb;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;




@SpringBootApplication
@EnableScheduling
public class MainDashBController {

	public static void main(String[] args) {

		SpringApplication.run(MainDashBController.class, args);
        System.out.println("Dev Ops Spring Boot Application - Started:");
		
	}

}
