package com.uob.dashb;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.uob.dashb.service.CreateNewActivitiesService;
import com.uob.dashb.service.CtrlMJobStatusService;

@Component
public class ScheduledTasks {

	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

	@Autowired
	CreateNewActivitiesService objCreateNewActivitiesService;
	
	
	@Autowired
	CtrlMJobStatusService objCtrlMJobStatusService; 
	
    @Scheduled(fixedRate = 3600000)
	//@Scheduled(cron="0 0 * * * *")
    public void reportCurrentTime() {
        System.out.println("This is sceduled task "+dateFormat.format(new Date()));
        try{
        	objCreateNewActivitiesService.createNewActivities();
        }catch(Exception e){
        	
        }
    }
    
    
    //0 0/30 8-10 * * *
	//@Scheduled(fixedRate = 3600000)
    @Scheduled(cron="0 42 9 * * ?")
    public void fetchJobsFromCtrlM() {
        System.out.println("This is sceduled task for fetching Jobs status from Ctrl-M 0 45 9 * * ?"+dateFormat.format(new Date()));
        try{
        	//objCtrlMJobStatusService.fetchJobsFromCtrlM();
        }catch(Exception e){
        	
        }
    }
    
    @Scheduled(cron="0 42 09 * * ?")
    public void fetchJobsFromCtrlM1() {
        System.out.println("This is sceduled task for fetching Jobs status from Ctrl-M 0 45 09 * * ?"+dateFormat.format(new Date()));
        try{
        	//objCtrlMJobStatusService.fetchJobsFromCtrlM();
        }catch(Exception e){
        	
        }
    }
    
    @Scheduled(cron="0 42 09 * * *")
    public void fetchJobsFromCtrlM2() {
        System.out.println("This is sceduled task for fetching Jobs status from Ctrl-M 0 45 09 * * * "+dateFormat.format(new Date()));
        try{
        	//objCtrlMJobStatusService.fetchJobsFromCtrlM();
        }catch(Exception e){
        	
        }
    }
    
    @Scheduled(cron="0 42 9 * * *")
    public void fetchJobsFromCtrlM3() {
        System.out.println("This is sceduled task for fetching Jobs status from Ctrl-M 0 45 9 * * * "+dateFormat.format(new Date()));
        try{
        	//objCtrlMJobStatusService.fetchJobsFromCtrlM();
        }catch(Exception e){
        	
        }
    }
    
}
