package com.uob.dashb.common.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.User;

public class AuthenticationFilter implements Filter {
	

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletResponse serResponse = (HttpServletResponse) response; 
		try {
			HttpServletRequest serRequest = (HttpServletRequest) request;
		    HttpSession session = serRequest.getSession(false);
		    if(null != session){
		    	System.out.println("Inside Filter"+session.getId());
		    	User objUser = (User) serRequest.getSession().getAttribute("userProfile");
		    	System.out.println("HTTP Request URI >>"+serRequest.getRequestURI());
		    	if(objUser != null){
		    		if(objUser.isSuccess()){
		    			chain.doFilter(request, response);
			    	}else{
			    		serResponse.sendRedirect("/DashBoard/dashBException");
			    	}
		    	}else{
		    		if(!serRequest.getRequestURI().contains("/loginAuthenticate")){
		    			chain.doFilter(request, response);
		    		}else{
		    			chain.doFilter(request, response);
		    		}
		    	}
		    }else{
		    	session = serRequest.getSession(true);
		    	/*if(serRequest.getRequestURI().endsWith("/DashBoard/")
		    			|| serRequest.getRequestURI().contains("/Login")){
		    		session = serRequest.getSession(true);
		    		chain.doFilter(request, response);
		    	}else{
		    		//throw new Exception("Security Exception");
		    	}*/
		    }
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception encountered");
			CommonVO objCommonVO = new CommonVO();
			ObjectMapper mapper = new ObjectMapper(); 
			objCommonVO.setSuccess(false);
			objCommonVO.setMessage("Action Not Allowed");
			serResponse.getWriter().write(mapper.writeValueAsString(objCommonVO));
			serResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
			serResponse.sendRedirect("/DashBoard/dashBException");
			return ;
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
}

