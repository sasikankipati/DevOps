package com.uob.dashb.common.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

public class CommonUtil {

	
	public static ArrayList<String> getStatusColors(){
		ArrayList<String> arlStatusColors = new ArrayList<String>();
		arlStatusColors.add("Green");
		arlStatusColors.add("Red");
		return arlStatusColors;
	}
	
	public static ArrayList<String> getSeverity(){
		ArrayList<String> arlSeverity = new ArrayList<String>();
		arlSeverity.add("High");
		arlSeverity.add("Medium");
		arlSeverity.add("Critical");
		arlSeverity.add("Low");
		return arlSeverity;
	}
	
	public static ArrayList<String> getEnvironment(){
		ArrayList<String> arlStatusColors = new ArrayList<String>();
		arlStatusColors.add("PROD");
		arlStatusColors.add("UAT");
		return arlStatusColors;
	}
	
	public static LinkedHashMap<String, String> emailConfig() {
		LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();
		map.put("HOST_NAME", "mailhost");
		map.put("FROM_ADDR", "U-Safe@uobgroup.com");
		return map;
	}
	
	
	private static InternetAddress[] getMailAddressArray(String mailTo) throws Exception{
		InternetAddress[] address = null;
		String[] strMailAddreses = mailTo.split(",");
		address = new InternetAddress[strMailAddreses.length];
			for (int i = 0; i < strMailAddreses.length; i++) {
				try {
					address[i] = new InternetAddress(strMailAddreses[i]);
				} catch (AddressException e) {
					throw new Exception("Exception in preparing the InternetAddress array for multiple e-mail recepients. "+e.getMessage(),e);
				}
			}			
		return address;
	}
	
	public static void sendMail(Hashtable<String, String> inputs)
			throws Exception {
		try {

			String mailSubject = inputs.get("MAIL_SUBJECT");
			String mailBody = inputs.get("MAIL_BODY");
			String emailIdTo = inputs.get("MAIL_ID_TO");
			String emailIdFrom = inputs.get("MAIL_ID_FROM");
			String ckaHostName = inputs.get("HOST_NAME");

			// create some properties and get the default Session
			Properties props = System.getProperties();
			props.put("mail.smtp.host", ckaHostName);

			Session session = Session.getDefaultInstance(props, null);
			session.setDebug(false);

			// create a message
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(emailIdFrom));
			InternetAddress[] address = getMailAddressArray(emailIdTo);
			msg.setRecipients(Message.RecipientType.TO, address);
			msg.setSubject(mailSubject);

			// create message boddy
			MimeBodyPart messageBody = new MimeBodyPart();
			// messageBody.setText(mailBody +"\n");
			messageBody.setDataHandler(new DataHandler(new ByteArrayDataSource(mailBody, "text/html")));
			Multipart mp = new MimeMultipart();
			mp.addBodyPart(messageBody);

			// add the Multipart to the message
			msg.setContent(mp);

			// set the Date: header
			msg.setSentDate(new Date());

			// send the message
			Transport.send(msg);

		} catch (MessagingException mex) {
			throw new Exception("Error while sending the Mail Failed Message. "+ mex.getMessage() + mex);
		}
	}
	
	public static String validString(String str){
		if(null != str && str.length() > 0){
			return str.trim();
		}else{
			return "";
		}
	}
}
