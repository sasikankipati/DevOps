package com.uob.dashb.common.util;

public class NextSequenceUtil {

	public static final String DOP_SEQ_JOB_MASTER_SEQNO_SQL = "SELECT SEQ_JOB_MASTER.nextval FROM DUAL";
	public static final String DOP_SEQ_JOB_DEPENDENCY_SEQNO_SQL = "SELECT SEQ_JOB_DEPENDENCY.nextval FROM DUAL";
	public static final String DOP_SEQ_APP_GROUP_SEQNO_SQL = "SELECT SEQ_APP_GROUP.nextval FROM DUAL";
	public static final String DOP_SEQ_USER_SEQNO_SQL = "SELECT SEQ_USER.nextval FROM DUAL";
	public static final String DOP_SEQ_ROLE_SEQNO_SQL = "SELECT SEQ_ROLE.nextval FROM DUAL";
	public static final String DOP_SEQ_USER_ROLE_SEQNO_SQL = "SELECT SEQ_USER_ROLE.nextval FROM DUAL";
	public static final String DOP_SEQ_USER_APP_GROUP_SEQNO_SQL = "SELECT SEQ_USER_APP_GROUP.nextval FROM DUAL";
	public static final String DOP_SEQ_TASK_SEQNO_SQL = "SELECT SEQ_TASK.nextval FROM DUAL";
	public static final String DOP_SEQ_ACTIVITY_SEQNO_SQL = "SELECT SEQ_ACTIVITY.nextval FROM DUAL";
	public static final String DOP_SEQ_TASK_ACTIVITY_SEQNO_SQL = "SELECT SEQ_TASK_ACTIVITY.nextval FROM DUAL";
	public static final String DOP_SEQ_ACT_TNX_SEQNO_SQL = "SELECT SEQ_ACT_TNX.nextval FROM DUAL";
	public static final String DOP_SEQ_SYSTEM_HEALTH_SEQNO_SQL = "SELECT SEQ_SYSTEM_HEALTH.nextval FROM DUAL";
	public static final String DOP_SEQ_TEST_CASE_SEQNO_SQL = "SELECT SEQ_TEST_CASE.nextval FROM DUAL";
	public static final String DOP_SEQ_ENVIRONMENT_SEQNO_SQL = "SELECT SEQ_ENVIRONMENT.nextval FROM DUAL";
	public static final String DOP_SEQ_TEST_SCENARIO_SEQNO_SQL = "SELECT SEQ_TEST_SCENARIO.nextval FROM DUAL";
	public static final String DOP_SEQ_TEST_STATUS_SEQNO_SQL = "SELECT SEQ_TEST_STATUS.nextval FROM DUAL";
	public static final String DOP_SEQ_TEST_TRACKER_ID_SEQNO_SQL = "SELECT SEQ_TEST_TRACKER_ID.nextval FROM DUAL";
	public static final String DOP_SEQ_ACTIVITY_GROUP_ID_SEQNO_SQL = "SELECT SEQ_ACTIVITY_GROUP.nextval FROM DUAL";
	public static final String DOP_SEQ_JOB_LOG_ID_SEQNO_SQL = "SELECT SEQ_JOB_LOG.nextval FROM DUAL";
	public static final String DOP_SEQ_JOB_TRACKER_ID_SEQNO_SQL = "SELECT seq_job_tracker.nextval FROM DUAL";
	
}
