package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.CommonUtil;
import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.framework.database.entity.ActivityMaster;
import com.uob.dashb.framework.database.entity.TaskMasterLink;
import com.uob.dashb.service.ActivityHistoryService;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.JobMasterService;
import com.uob.dashb.service.TasksService;
import com.uob.dashb.vo.ActivitiesMainVO;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.JobVO;
import com.uob.dashb.vo.TaskDetailVO;
import com.uob.dashb.vo.User;


@RestController
public class ActivitiesController {
	
	@Autowired
	ActivityHistoryService objActivityHistory;
	
	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	JobMasterService objJobMasterService;
	
	@Autowired
	TasksService objTasksService;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	@RequestMapping(value="/viewSelectedActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewSelectedActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = objActivityHistory.viewSelectedActivity(objActivityVO,String.valueOf(objUser.getUserId()));
			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			// ArrayList<JobVO> arlJobs = objJobMasterService.fetchAllJobs(String.valueOf(objUser.getUserId()));
			 objCommonVO.setArlAppGroups(arlGroups);
			 objCommonVO.setEnvList(CommonUtil.getEnvironment());
			 //objCommonVO.setArlJobs(arlJobs);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/fetchAllActivities",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllActivities(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 ActivitiesMainVO objActivitiesMainVO = new ActivitiesMainVO();
			 ArrayList<ActivityVO> arlActivityVO = objActivityHistory.listActivities(objUser.getUserId());
			 objActivitiesMainVO.setArlActivityVO(arlActivityVO);
			 objActivitiesMainVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objActivitiesMainVO);
		    } catch (Exception e) { 
		    	CommonVO objCommonVO = new CommonVO();
		    	objCommonVO.setSuccess(false);
		    	objCommonVO.setMessage("Exception Occured ...!");
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/fetchNewActivityInfo",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchNewActivityInfo(HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			/* ArrayList<TaskDetailVO> arlTaskDetailVO = objActivityHistory.listTasks();
			 objCommonVO.setArlTaskDetailVO(arlTaskDetailVO);*/
			 
			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			 objCommonVO.setArlAppGroups(arlGroups);
			 objCommonVO.setEnvList(CommonUtil.getEnvironment());
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/submitActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String submitActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<TaskDetailVO> arlTaskDetailVO = objActivityHistory.listTasks(objActivityVO.getGroupId());
			 ArrayList<JobVO> arlJobs = objJobMasterService.fetchAllJobs(String.valueOf(objUser.getUserId()));
			 objCommonVO.setArlJobs(arlJobs);
			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			 objCommonVO.setArlTaskDetailVO(arlTaskDetailVO);
			 objCommonVO.setEnvList(CommonUtil.getEnvironment());
			 objCommonVO.setArlAppGroups(arlGroups);
			 objCommonVO.setObjActivityVO(objActivityVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/saveActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 
			 ActivityMaster objActivityMaster = objActivityHistory.findActivity(objActivityVO);
			 if(null == objActivityMaster){
				 objActivityMaster = new ActivityMaster();
				 objActivityMaster.setActivity_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ACTIVITY_SEQNO_SQL));
				 objActivityMaster.setEnvironment(objActivityVO.getEnvironment());
				 objActivityMaster.setActivity_desc(objActivityVO.getActivityDesc());
				 objActivityHistory.saveActivity(objActivityMaster);
				 
				 objActivityMaster = objActivityHistory.findActivity(objActivityVO);
				 int nextGroupId = objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ACTIVITY_GROUP_ID_SEQNO_SQL);
				 
				 TaskMasterLink objTaskMasterLink;
					for(String strTaskId: objActivityVO.getTaskList()){
						objTaskMasterLink = new TaskMasterLink();
						objTaskMasterLink.setTask_activity_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TASK_ACTIVITY_SEQNO_SQL));
						objTaskMasterLink.setActivity_id(objActivityMaster.getActivity_id());
						objTaskMasterLink.setActivitygroup(nextGroupId);
						objTaskMasterLink.setApp_id(objActivityVO.getAppId());
						System.out.println("***************GroupId **********"+objActivityVO.getGroupId());
						objTaskMasterLink.setGroup_id(Integer.valueOf(objActivityVO.getGroupId()));
						objTaskMasterLink.setDay_of_week(objActivityVO.getDaysOfWeek());
						objTaskMasterLink.setMinutes(objActivityVO.getGivenTime());
						objTaskMasterLink.setPriority(objActivityVO.getPriority());
						objTaskMasterLink.setStart_time(objActivityVO.getScheduleAt());
						objTaskMasterLink.setTask_id(Integer.valueOf(strTaskId));
						objActivityHistory.saveTaskMasterLink(objTaskMasterLink);
					}
					
					for(String strJobMasterId: objActivityVO.getJobList()){
						objTaskMasterLink = new TaskMasterLink();
						objTaskMasterLink.setActivity_id(objActivityMaster.getActivity_id());
						objTaskMasterLink.setActivitygroup(nextGroupId);
						objTaskMasterLink.setApp_id(objActivityVO.getAppId());
						System.out.println("***************GroupId **********"+objActivityVO.getGroupId());
						objTaskMasterLink.setGroup_id(Integer.valueOf(objActivityVO.getGroupId()));
						objTaskMasterLink.setDay_of_week(objActivityVO.getDaysOfWeek());
						objTaskMasterLink.setMinutes(objActivityVO.getGivenTime());
						objTaskMasterLink.setPriority(objActivityVO.getPriority());
						objTaskMasterLink.setStart_time(objActivityVO.getScheduleAt());
						objTaskMasterLink.setJob_master_id(Integer.valueOf(strJobMasterId));
						objActivityHistory.saveTaskMasterLink(objTaskMasterLink);
					}
					
					ArrayList<ActivityVO> arlPendingAct = objTasksService.fetchPendingTasks(String.valueOf(objUser.getUserId()),5);
					objCommonVO.setArlPendingAct(arlPendingAct);
					
					objCommonVO.setSuccess(true);
			 }else{
				 objCommonVO.setMessage("Activity already exists ..!");
				 objCommonVO.setSuccess(false);
			 }
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }

	 @RequestMapping(value="/updateActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 
			 ActivityMaster objActivityMaster = objActivityHistory.findActivity(objActivityVO);
			 
			 if(null != objActivityMaster){
				 
				 objActivityHistory.deleteActivityGroup(objActivityVO.getActivityGroup());

				 int nextGroupId = objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ACTIVITY_GROUP_ID_SEQNO_SQL);
				 
				 TaskMasterLink objTaskMasterLink;
					for(String strTaskId: objActivityVO.getTaskList()){
						objTaskMasterLink = new TaskMasterLink();
						objTaskMasterLink.setTask_activity_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TASK_ACTIVITY_SEQNO_SQL));
						objTaskMasterLink.setActivity_id(objActivityMaster.getActivity_id());
						objTaskMasterLink.setActivitygroup(nextGroupId);
						System.out.println("***************GroupId **********"+objActivityVO.getGroupId());
						objTaskMasterLink.setGroup_id(Integer.valueOf(objActivityVO.getGroupId()));
						objTaskMasterLink.setApp_id(objActivityVO.getAppId());
						objTaskMasterLink.setDay_of_week(objActivityVO.getDaysOfWeek());
						objTaskMasterLink.setMinutes(objActivityVO.getGivenTime());
						objTaskMasterLink.setPriority(objActivityVO.getPriority());
						objTaskMasterLink.setStart_time(objActivityVO.getScheduleAt());
						objTaskMasterLink.setTask_id(Integer.valueOf(strTaskId));
						objActivityHistory.saveTaskMasterLink(objTaskMasterLink);
					}
					
					for(String strJobMasterId: objActivityVO.getJobList()){
						objTaskMasterLink = new TaskMasterLink();
						objTaskMasterLink.setActivity_id(objActivityMaster.getActivity_id());
						objTaskMasterLink.setActivitygroup(nextGroupId);
						objTaskMasterLink.setApp_id(objActivityVO.getAppId());
						System.out.println("***************GroupId **********"+objActivityVO.getGroupId());
						objTaskMasterLink.setGroup_id(Integer.valueOf(objActivityVO.getGroupId()));
						objTaskMasterLink.setDay_of_week(objActivityVO.getDaysOfWeek());
						objTaskMasterLink.setMinutes(objActivityVO.getGivenTime());
						objTaskMasterLink.setPriority(objActivityVO.getPriority());
						objTaskMasterLink.setStart_time(objActivityVO.getScheduleAt());
						objTaskMasterLink.setJob_master_id(Integer.valueOf(strJobMasterId));
						objActivityHistory.saveTaskMasterLink(objTaskMasterLink);
					}
					
					ArrayList<ActivityVO> arlPendingAct = objTasksService.fetchPendingTasks(String.valueOf(objUser.getUserId()),5);
					objCommonVO.setArlPendingAct(arlPendingAct);
					
					objCommonVO.setSuccess(true);
			 }else{
				 objCommonVO.setMessage("Activity already exists ..!");
				 objCommonVO.setSuccess(false);
			 }
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}