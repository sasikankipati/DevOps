package com.uob.dashb.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.CommonUtil;
import com.uob.dashb.service.ActivityHistoryService;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.TasksService;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.CalendarVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.JobVO;
import com.uob.dashb.vo.TaskDetailVO;
import com.uob.dashb.vo.User;

@RestController
public class ActivityTxnController {
	
	@Autowired
	ActivityHistoryService objActivityHistory;
	
	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	TasksService objTasksService;
	
	
	@RequestMapping(value="/fetchActivityHistory",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchActivityHistory(HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO(); 
					
			 ArrayList<CalendarVO> arlCalendarVO = new ArrayList<CalendarVO>();
			 
 			 CalendarVO objCalendarVO = new CalendarVO();
			 
 			objCalendarVO.setDraggable(true);
 			objCalendarVO.setResizable(true);
 			objCalendarVO.setTitle("Test");
 			objCalendarVO.setType("warning");
 			objCalendarVO.setStartsAt("16 Jun 2016 13:00:00 GMT+0800");
 			objCalendarVO.setEndsAt("16 Jun 2016 13:00:00 GMT+0800");
			 
 			arlCalendarVO.add(objCalendarVO);
 			
 			objCalendarVO = new CalendarVO();
 			objCalendarVO.setDraggable(true);
 			objCalendarVO.setResizable(true);
 			objCalendarVO.setTitle("Test1");
 			objCalendarVO.setType("success");
 			objCalendarVO.setStartsAt("16 Jun 2016 13:00:00 GMT+0800");
 			objCalendarVO.setEndsAt("16 Jun 2016 13:00:00 GMT+0800");
 			arlCalendarVO.add(objCalendarVO);
 			
 			
 			objCommonVO.setArlCalendarVO(arlCalendarVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/actOnActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String actOnActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = objTasksService.viewSelectedTxn(objActivityVO,String.valueOf(objUser.getUserId()));
			 
			 ArrayList<TaskDetailVO> arlNewTaskVO = new ArrayList<TaskDetailVO>();
			 ArrayList<TaskDetailVO> arlAllTaskVO = objCommonVO.getArlTaskDetailVO();
			 for(TaskDetailVO objTaskDetailVO:arlAllTaskVO){
				 if(objTaskDetailVO.getChecked()){
					 arlNewTaskVO.add(objTaskDetailVO);
				 }
			 }
			 objCommonVO.setArlTaskDetailVO(arlNewTaskVO);
			 
			 
			 ArrayList<JobVO> arlNewJobVO = new ArrayList<JobVO>();
			 ArrayList<JobVO> arlAllJobVO = objCommonVO.getArlJobs();
			 for(JobVO objJobVO:arlAllJobVO){
				 if(objJobVO.getChecked()){
					 arlNewJobVO.add(objJobVO);
				 }
			 }
			 objCommonVO.setArlJobs(arlNewJobVO);
			 
			 
			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			 objCommonVO.setArlAppGroups(arlGroups);
			 objCommonVO.setEnvList(CommonUtil.getEnvironment());
			 objCommonVO.setRagList(CommonUtil.getStatusColors());
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	
	@RequestMapping(value="/updateFilledActivity",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateFilledActivity(@RequestBody ActivityVO objActivityVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 CommonVO objCommonVO = new CommonVO();
		 try {
			 
			 System.out.println(objActivityVO.getActivityGroup());
			 System.out.println(objActivityVO.getArlTasks().size());
			 boolean succ = objTasksService.updateActTxn(objActivityVO,objUser.getUserId());
			 String emailDistribution = objTasksService.getEmailDistribution(objActivityVO.getGroupId());
			 if(succ && objActivityVO.getSendmail()){
				    HashMap<String, String> mailConf = CommonUtil.emailConfig();
				    
				 	Hashtable<String, String> inputs = new Hashtable<String, String>();
					inputs.put("HOST_NAME",mailConf.get("HOST_NAME"));
					inputs.put("MAIL_ID_FROM",mailConf.get("FROM_ADDR"));
					
					inputs.put("MAIL_ID_TO", emailDistribution);
					inputs.put("MAIL_SUBJECT",objActivityVO.getActivityDesc() +" Scheduled At: "+objActivityVO.getScheduleAt());

					StringBuffer strBuf = new StringBuffer(" <br>");
					strBuf.append("<br>");
					
					strBuf.append("<html><body><table border='1'>");
					
					strBuf.append("<tr><td colspan='5'><table border='1'><tr><td> Activity Name </td><td>");
					strBuf.append(objActivityVO.getActivityDesc());
					strBuf.append("</td><td> Scheduled At </td><td>");
					strBuf.append(objActivityVO.getScheduleAt());
					strBuf.append("</td></tr></table></td></tr>");
					
					if(null != objActivityVO.getArlTasks() && objActivityVO.getArlTasks().size() > 0){
						strBuf.append("<tr><td colspan='5'>Tasks</td></tr>");
						
						strBuf.append("<tr><td>Task</td><td>Status</td><td>Remarks</td>");
						strBuf.append("<td>Force Ok</td><td>Force Ok Reason</td></tr>");
						
						for(TaskDetailVO objTaskDetailVO: objActivityVO.getArlTasks()){
							
							strBuf.append("<tr>");
							
							strBuf.append("<td>");
							strBuf.append(objTaskDetailVO.getTaskDesc());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objTaskDetailVO.getStatus());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(CommonUtil.validString(objTaskDetailVO.getRemarks()));
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objTaskDetailVO.getForceOk());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(CommonUtil.validString(objTaskDetailVO.getForceOkReason()));
							strBuf.append("</td>");
							
							strBuf.append("</tr>");
						}
					}
					
					if(null != objActivityVO.getArlJobs() && objActivityVO.getArlJobs().size() > 0){
						strBuf.append("<tr><td colspan='5'>Jobs</td></tr>");
						
						strBuf.append("<tr><td>Job Name</td><td>Standard Start Time</td><td>Standard End Time</td>");
						strBuf.append("<td>Actual Start Time</td><td>Actual End Time</td></tr>");
						
						for(JobVO objJob: objActivityVO.getArlJobs()){
							strBuf.append("<tr>");
							strBuf.append("<td>");
							strBuf.append(objJob.getJobDesc());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objJob.getStandardStartTime());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objJob.getStandardEndTime());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objJob.getActualStartTime());
							strBuf.append("</td>");
							
							strBuf.append("<td>");
							strBuf.append(objJob.getActualEndTime());
							strBuf.append("</td>");
							
							strBuf.append("</tr>");
						}
					}
					
					
					
					strBuf.append("</table></body></html>");
					System.out.println(strBuf.toString());
					inputs.put("MAIL_BODY", strBuf.toString());
					try{
						CommonUtil.sendMail(inputs);
					}
					catch(Exception ex){
						ex.printStackTrace();
						System.out.println("Error while sending email ....!");
					}
				 
			 }
			 
			 ArrayList<ActivityVO> arlPendingAct = objTasksService.fetchPendingTasks(String.valueOf(objUser.getUserId()),5);
			 objCommonVO.setArlPendingAct(arlPendingAct);
			 
			 objCommonVO.setSuccess(succ);
			 
			 if(!succ){
				 objCommonVO.setMessage("Exception while saving the data ...!");
			 }
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    	objCommonVO.setSuccess(false);
				objCommonVO.setMessage("Exception while saving the data ...!");
				try{
					jsonObject = mapper.writeValueAsString(objCommonVO);
				}catch(Exception ex){
					ex.printStackTrace();
				}
		    }
	  return jsonObject;
	 }
	
}