package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.LoginService;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.ApplicationVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.User;
import com.uob.dashb.vo.UserVO;


@RestController
public class ApplicationController {
	
	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	LoginService objLoginService;
	
	
	
	@RequestMapping(value="/newApplication",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String newApplication(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ApplicationGroupVO objApplicationGroupVO;
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 
			 ArrayList<UserProfile> arlUsers = (ArrayList<UserProfile>) objLoginService.getAll();
			 UserVO objUserVO;
			 ArrayList<UserVO> arlUsersVO = new ArrayList<UserVO>();
			 for(UserProfile objUserProfile:arlUsers){
				 System.out.println(objUserProfile.toString());
				 objUserVO = new UserVO();
				 objUserVO.setUserId(String.valueOf(objUserProfile.getUser_id()));
				 objUserVO.setUserName(objUserProfile.getUser_name());
				 arlUsersVO.add(objUserVO);
			 }
			 
			 objCommonVO.setArlUsersVO(arlUsersVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/saveNewApplication",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveNewApplication(@RequestBody ApplicationVO objApplicationVO,HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean flag = objApplicationService.saveApplication(objApplicationVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/updateApplication",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateApplication(@RequestBody ApplicationVO objApplicationVO,HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean flag = objApplicationService.updateApplication(objApplicationVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/fetchAllApplications",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllApplications(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<ApplicationVO> arlApplications = objApplicationService.fetchAllApplications();
			 objCommonVO.setArlApplications(arlApplications);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/viewApplication",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewApplication(@RequestBody ApplicationVO objApplicationVO, HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objApplicationVO = objApplicationService.viewApplication(objApplicationVO.getAppId());
			
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ApplicationGroupVO objApplicationGroupVO;
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 objCommonVO.setObjApplicationVO(objApplicationVO);
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 
			 ArrayList<UserProfile> arlUsers = (ArrayList<UserProfile>) objLoginService.getAll();
			 UserVO objUserVO;
			 ArrayList<UserVO> arlUsersVO = new ArrayList<UserVO>();
			 for(UserProfile objUserProfile:arlUsers){
				 System.out.println(objUserProfile.toString());
				 objUserVO = new UserVO();
				 objUserVO.setUserId(String.valueOf(objUserProfile.getUser_id()));
				 objUserVO.setUserName(objUserProfile.getUser_name());
				 arlUsersVO.add(objUserVO);
			 }
			 
			 objCommonVO.setArlUsersVO(arlUsersVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
}