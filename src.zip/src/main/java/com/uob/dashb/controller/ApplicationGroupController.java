package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.User;


@RestController
public class ApplicationGroupController {
	
	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	 @RequestMapping(value="/fetchAllAppGroups",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllAppGroups(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ApplicationGroupVO objApplicationGroupVO;
			 
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/saveNewAppGroup",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveNewAppGroup(@RequestBody ApplicationGroupVO objApplicationGroupVO, HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 
			 System.out.println(objApplicationGroupVO.getDisplayOrder());
			 System.out.println(objApplicationGroupVO.getEmail());
			 System.out.println(objApplicationGroupVO.getGroup_id());
			 System.out.println(objApplicationGroupVO.getGroupName());
			 System.out.println(objApplicationGroupVO.getGroupOwner());
			 

			 ApplicationGroup objApplicationGroup = new ApplicationGroup();
			 objApplicationGroup.setApp_group_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_APP_GROUP_SEQNO_SQL));
			 objApplicationGroup.setApp_group_name(objApplicationGroupVO.getGroupName());
			 objApplicationGroup.setApp_group_owner(objApplicationGroupVO.getGroupOwner());
			 objApplicationGroup.setDisplay_order(objApplicationGroupVO.getDisplayOrder());
			 objApplicationGroup.setEmail_distribution(objApplicationGroupVO.getEmail());
			 
			 objApplicationService.save(objApplicationGroup);
			 
			 CommonVO objCommonVO = new CommonVO();
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }

	 @RequestMapping(value="/viewAppGroup",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewAppGroup(@RequestBody ApplicationGroupVO objApplicationGroupVO, HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 
			 ApplicationGroup objApplicationGroup = objApplicationService.viewAppGroup(objApplicationGroupVO.getGroup_id());
			 
			 objApplicationGroupVO.setDisplayOrder(objApplicationGroup.getDisplay_order());
			 objApplicationGroupVO.setEmail(objApplicationGroup.getEmail_distribution());
			 objApplicationGroupVO.setGroup_id(String.valueOf(objApplicationGroup.getApp_group_id()));
			 objApplicationGroupVO.setGroupName(objApplicationGroup.getApp_group_name());
			 objApplicationGroupVO.setGroupOwner(objApplicationGroup.getApp_group_owner());
			 
			 System.out.println(objApplicationGroupVO.getDisplayOrder());
			 System.out.println(objApplicationGroupVO.getEmail());
			 System.out.println(objApplicationGroupVO.getGroup_id());
			 System.out.println(objApplicationGroupVO.getGroupName());
			 System.out.println(objApplicationGroupVO.getGroupOwner());
			 
			 CommonVO objCommonVO = new CommonVO();
			 
			 objCommonVO.setObjApplicationGroupVO(objApplicationGroupVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
	 @RequestMapping(value="/updateAppGroup",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateAppGroup(@RequestBody ApplicationGroupVO objApplicationGroupVO, HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 
			 System.out.println(objApplicationGroupVO.getDisplayOrder());
			 System.out.println(objApplicationGroupVO.getEmail());
			 System.out.println(objApplicationGroupVO.getGroup_id());
			 System.out.println(objApplicationGroupVO.getGroupName());
			 System.out.println(objApplicationGroupVO.getGroupOwner());
			 
			 objApplicationService.update(objApplicationGroupVO);			 
			 
			 
			 CommonVO objCommonVO = new CommonVO();
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}