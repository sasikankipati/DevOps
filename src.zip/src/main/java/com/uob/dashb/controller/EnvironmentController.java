package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.service.EnvironmentService;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.EnvironmentVO;
import com.uob.dashb.vo.User;


@RestController
public class EnvironmentController {
	
	@Autowired
	EnvironmentService objEnvironmentService;
	
	@RequestMapping(value="/deleteEnvironment",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String deleteEnvironment(@RequestBody EnvironmentVO objEnvironmentVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean success = objEnvironmentService.deleteEnvironment(objEnvironmentVO);
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	
	
	 @RequestMapping(value="/fetchAllEnvironments",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllTestCases(HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<EnvironmentVO> arlEnvironmentVO = objEnvironmentService.fetchAllList();
			 objCommonVO.setArlEnvironmentVO(arlEnvironmentVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/saveEnvironment",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveEnvironment(@RequestBody EnvironmentVO objEnvironmentVO, HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean success = false;
			 /** Field validation check **/
			 
			 /** Duplicate validation check **/
			 boolean exists = objEnvironmentService.duplicateCheck(objEnvironmentVO);
			 if(exists){
				 objCommonVO.setMessage("Duplicate Case ID exists ..!");
			 }else{
				 success = objEnvironmentService.saveEnvironment(objEnvironmentVO);
			 }
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/updateEnvironment",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateEnvironment(@RequestBody EnvironmentVO objEnvironmentVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objEnvironmentVO.setRec_status("A");
			 boolean success = false;
			 /** Field validation check **/
			 
			 /** Duplicate validation check **/
			 boolean exists = objEnvironmentService.duplicateCheck(objEnvironmentVO);
			 if(exists){
				 objCommonVO.setMessage("Duplicate Case ID exists ..!");
			 }else{
				 success = objEnvironmentService.updateEnvironment(objEnvironmentVO);
			 }
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 
	 @RequestMapping(value="/viewEnvironment",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewEnvironment(@RequestBody EnvironmentVO objEnvironmentVO, HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objEnvironmentVO = objEnvironmentService.viewEnvironment(objEnvironmentVO);
			 objCommonVO.setObjEnvironmentVO(objEnvironmentVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}