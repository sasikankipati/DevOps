package com.uob.dashb.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.service.LoginService;
import com.uob.dashb.vo.CommonVO;


@RestController
public class ExceptionController {
	
	@Autowired
	LoginService loginService;
	
	 @RequestMapping(value="/Exception",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String authenticate(@RequestBody CommonVO objCommonVO,HttpServletRequest request, 
		        HttpServletResponse response) {
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 System.out.println(objCommonVO.getMessage());
			 objCommonVO.setSuccess(false);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}