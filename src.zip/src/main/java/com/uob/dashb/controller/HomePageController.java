package com.uob.dashb.controller;

import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.service.ActivityHistoryService;
import com.uob.dashb.vo.SummaryParentVO;
import com.uob.dashb.vo.SummaryVO;
import com.uob.dashb.vo.User;


@RestController
public class HomePageController {
	
	@Autowired
	ActivityHistoryService objActivityHistory;
	
	
	
	 @RequestMapping(value="/groupSummary",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String groupSummary(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 
			 HashMap<String, String> consolData = objActivityHistory.getConsolidateList(objUser.getUserId());

			 if(null != consolData){
				 SummaryVO objSummaryVO = new SummaryVO();
				 ArrayList<SummaryVO> arlSummaryVO = new ArrayList<SummaryVO>();
				 
				 objSummaryVO.setApplication("PIB");
				 objSummaryVO.setLastActivity("22-May-2016 07:00");
				 objSummaryVO.setLatestActivity("22-May-2016 09:00");
				 objSummaryVO.setStatus("RED");
				 objSummaryVO.setGroupId("1");
				 arlSummaryVO.add(objSummaryVO);
				 
				 objSummaryVO = new SummaryVO();
				 objSummaryVO.setApplication("GEB");
				 objSummaryVO.setLastActivity("22-May-2016 07:00");
				 objSummaryVO.setLatestActivity("22-May-2016 09:00");
				 objSummaryVO.setStatus("GREEN");
				 objSummaryVO.setGroupId("2");
				 arlSummaryVO.add(objSummaryVO);
				 
				 SummaryParentVO objSummaryParentVO = new SummaryParentVO();
				 objSummaryParentVO.setSuccess(true);
				 objSummaryParentVO.setArlSummary(arlSummaryVO);
				 
				 jsonObject = mapper.writeValueAsString(objSummaryParentVO);
			 }
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/showSummary",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String showSummary(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 
			 HashMap<String, String> consolData = objActivityHistory.getConsolidateList(objUser.getUserId());

			 ArrayList<UserApplicationGroup> arlGroups = objActivityHistory.getGroupIdsOfUser(objUser.getUserId());
			 
			/* if(null != arlGroups && arlGroups.size() > 0){
				 
				 // Making list of groups belongs to logged in user
				 List<Integer> groupList = new ArrayList<Integer>();
				 for(UserApplicationGroup objGroup: arlGroups){
					 groupList.add(objGroup.getApp_group_id());
				 }
				 
				 ArrayList<Application> arlApplications = objActivityHistory.getAppofGroup(groupList);
				 
				 // Making list of applications belongs to groups of logged in user
				 List<Integer> appList = new ArrayList<Integer>();
				 for(Application objApp: arlApplications){
					 appList.add(objApp.getApp_id());
				 }
				 
				 ArrayList<TaskMasterLink> arlTaskForApp = objActivityHistory.getScheduledActivities(appList);
				 
				 
			 }else{
				 System.out.println("User not assigned to any group");
			 }
			 */
			 
			 
			 if(null != consolData){
				 SummaryVO objSummaryVO = new SummaryVO();
				 ArrayList<SummaryVO> arlSummaryVO = new ArrayList<SummaryVO>();
				 
				 objSummaryVO.setApplication("eChannels Retail");
				 objSummaryVO.setLastActivity("22-May-2016 07:00");
				 objSummaryVO.setLatestActivity("22-May-2016 09:00");
				 objSummaryVO.setStatus("RED");
				 objSummaryVO.setGroupId("1");
				 arlSummaryVO.add(objSummaryVO);
				 
				 objSummaryVO = new SummaryVO();
				 objSummaryVO.setApplication("Wholesales Cash & Trade");
				 objSummaryVO.setLastActivity("22-May-2016 07:00");
				 objSummaryVO.setLatestActivity("22-May-2016 09:00");
				 objSummaryVO.setStatus("GREEN");
				 objSummaryVO.setGroupId("2");
				 arlSummaryVO.add(objSummaryVO);
				 
				 
				 SummaryParentVO objSummaryParentVO = new SummaryParentVO();
				 objSummaryParentVO.setSuccess(true);
				 objSummaryParentVO.setArlSummary(arlSummaryVO);
				 
				 jsonObject = mapper.writeValueAsString(objSummaryParentVO);
			 }
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}