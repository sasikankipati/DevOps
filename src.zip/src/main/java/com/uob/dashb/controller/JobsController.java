package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.service.JobMasterService;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.JobDependencyVO;
import com.uob.dashb.vo.JobVO;
import com.uob.dashb.vo.User;


@RestController
public class JobsController {
	
	@Autowired
	JobMasterService objJobMasterService;

	
	 @RequestMapping(value="/fetchAllJobs",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllJobs(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<JobVO> arlJobs = objJobMasterService.fetchAllJobs(String.valueOf(objUser.getUserId()));
			 ArrayList<JobDependencyVO> arlJobDependencyVO;
			 for(JobVO objJobVO:arlJobs){
				 arlJobDependencyVO = objJobMasterService.fetchDependencies(objJobVO.getJobMasterId());
				 objJobVO.setArlDependents(arlJobDependencyVO);
			 }
			 objCommonVO.setArlJobs(arlJobs);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/fetchJobLogs",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchJobLogs(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<JobVO> arlJobs = objJobMasterService.fetchJobLogs();
			 ArrayList<JobDependencyVO> arlJobDependencyVO;
			 for(JobVO objJobVO:arlJobs){
				 arlJobDependencyVO = objJobMasterService.fetchDependencies(objJobVO.getJobMasterId());
				 objJobVO.setArlDependents(arlJobDependencyVO);
			 }
			 objCommonVO.setArlJobs(arlJobs);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
}