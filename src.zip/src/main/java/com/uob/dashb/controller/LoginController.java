package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.service.LoginService;
import com.uob.dashb.service.TasksService;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.User;
import com.uob.dashb.vo.UserVO;


@RestController
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	TasksService objTasksService;
	
	 @RequestMapping(value="/loginAuthenticate",method = RequestMethod.POST,consumes="application/json",produces = "application/json")
	 @ResponseBody
	 public String authenticate(@RequestBody User objUser,HttpServletRequest request, 
		        HttpServletResponse response) {
		 
		 UserProfile objUserProfile = null;
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 if(null != objUser){
				 String message = objUser.validate();
				 if(message != null && message.length() == 0){
					 objUserProfile = loginService.authenticateUser(objUser.getUsername(),objUser.getPassword());
					 if(null != objUserProfile){
						 UserVO objUserVO = loginService.getUserRole(objUserProfile.getUser_id());
						 
						 objUser.setRole(objUserVO.getRole());
						 objUser.setEmail(objUser.getUsername());
						 objUser.setLanid(objUserProfile.getLanid());
						 objUser.setPhone(objUserProfile.getPhone());
						 objUser.setStatus(objUserProfile.getStatus());
						 objUser.setUsername(objUserProfile.getUser_name());
						 objUser.setUserId(objUserProfile.getUser_id());
						 if(null != objUserProfile.getAdminflag() && objUserProfile.getAdminflag().equalsIgnoreCase("Y")){
							 objUser.setAdmin(true);
						 }
						 objUser.setSuccess(true);
						 
						 //Fetch Pending activities under user group
						 ArrayList<ActivityVO> arlPendingAct = objTasksService.fetchPendingTasks(String.valueOf(objUserProfile.getUser_id()),3);
						 //ArrayList<ActivityVO> arlPendingAct = new ArrayList<ActivityVO>();
						 objUser.setArlPendAct(arlPendingAct);
						 
						 jsonObject = mapper.writeValueAsString(objUser);
						 request.getSession().setAttribute("userProfile", objUser);
					 }else{
						 CommonVO objCommonVO = new CommonVO();
						 objCommonVO.setSuccess(false);
						 objCommonVO.setMessage("Login not successful ...!");
						 jsonObject = mapper.writeValueAsString(objCommonVO);
					 }
				 }
			 }else{
				 CommonVO objCommonVO = new CommonVO();
				 objCommonVO.setSuccess(false);
				 objCommonVO.setMessage("Login not successful ...!");
				 jsonObject = mapper.writeValueAsString(objCommonVO);
			 }
			
		    } catch (Exception e) { 
		    	e.printStackTrace();
		    	try {
					CommonVO objCommonVO = new CommonVO();
					 objCommonVO.setSuccess(false);
					 objCommonVO.setMessage("Login not successful, DB Exception ...!");
					 jsonObject = mapper.writeValueAsString(objCommonVO);
				} catch (Exception e1) {
					e1.printStackTrace();
				} 
		    }
	  return jsonObject;
	 }
	 
}