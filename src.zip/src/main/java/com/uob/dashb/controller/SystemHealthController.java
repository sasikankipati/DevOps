package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.service.SystemHealthService;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.SystemHealthChkVO;


@RestController
public class SystemHealthController {
	
	@Autowired
	SystemHealthService objSystemHealthService;
	
	
	
	@RequestMapping(value="/fetchTsLevelHealthCheck",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchTsLevelHealthCheck(@RequestBody SystemHealthChkVO objSystemHealthChkVO,HttpServletRequest request, HttpServletResponse response) {
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<SystemHealthChkVO> arlSystemHealthChk = objSystemHealthService.fetchTSLevelHealthCheck(objSystemHealthChkVO.getAppId(),objSystemHealthChkVO.getCountry());
			 objCommonVO.setArlSystemHealthChk(arlSystemHealthChk);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/fetchEnvLevelHealthCheck",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchEnvLevelHealthCheck(@RequestBody SystemHealthChkVO objSystemHealthChkVO,HttpServletRequest request, HttpServletResponse response) {
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<SystemHealthChkVO> arlSystemHealthChk = objSystemHealthService.fetchEnvLevelHealthCheck(objSystemHealthChkVO.getAppId());
			 objCommonVO.setArlSystemHealthChk(arlSystemHealthChk);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }

	@RequestMapping(value="/fetchAppLevelHealthCheck",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAppLevelHealthCheck(HttpServletRequest request, HttpServletResponse response) {
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<SystemHealthChkVO> arlSystemHealthChk = objSystemHealthService.fetchAppLevelHealthCheck();
			 objCommonVO.setArlSystemHealthChk(arlSystemHealthChk);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/postSysHealthChk",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json",consumes = "application/json")
	 @ResponseBody
	 public String postSysHealthChk(@RequestBody SystemHealthChkVO objSystemHealthChkVO,HttpServletRequest request, HttpServletResponse response) {
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 
			 String errorCode = objSystemHealthService.save(objSystemHealthChkVO);
			 objCommonVO.setSuccess(false);
			 if(errorCode.equalsIgnoreCase("000")){
				 objCommonVO.setMessage("Successfully saved");
				 objCommonVO.setSuccess(true);
			 }else if(errorCode.equalsIgnoreCase("001")){
				 objCommonVO.setMessage("Test Scenario and Test Case Id doesn't exists");
				 objCommonVO.setErrorCode(errorCode);
			 }else{
				 objCommonVO.setMessage("Exception while inserting");
				 objCommonVO.setErrorCode(errorCode);
			 }
			 
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
	 
}