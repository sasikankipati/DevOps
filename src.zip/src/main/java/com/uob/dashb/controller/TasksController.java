package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.framework.database.entity.TaskMaster;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.TasksService;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TaskDetailVO;
import com.uob.dashb.vo.User;


@RestController
public class TasksController {
	
	@Autowired
	TasksService objTasksService;

	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	 @RequestMapping(value="/fetchAllTasks",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllTasks(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<TaskDetailVO> arlTaskDetailVO = objTasksService.fetchAllTasks();
			 
			 objCommonVO.setArlTaskDetailVO(arlTaskDetailVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/viewSelectedTask",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewSelectedTask(@RequestBody TaskDetailVO objTaskDetailVO,HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objTaskDetailVO = objTasksService.viewSelectedTask(objTaskDetailVO.getTaskId());
			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			 objCommonVO.setArlAppGroups(arlGroups);
			 objCommonVO.setObjTaskDetailVO(objTaskDetailVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/setNewTask",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String setNewTask(HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();

			 ArrayList<ApplicationGroupVO> arlGroups = objApplicationService.fetchAllGroups();
			 objCommonVO.setArlAppGroups(arlGroups);
			 
			 
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 //updateTask
	 
	 @RequestMapping(value="/deleteTask",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String deleteTask(@RequestBody TaskDetailVO objTaskDetailVO, HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean flag = objTasksService.deleteTask(objTaskDetailVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/updateTask",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateTask(@RequestBody TaskDetailVO objTaskDetailVO, HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean flag = objTasksService.updateTask(objTaskDetailVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/saveNewTask",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveNewTask(@RequestBody TaskDetailVO objTaskDetailVO, HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 TaskMaster objTaskMaster = new TaskMaster();
			 objTaskMaster.setTask_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TASK_SEQNO_SQL));
			 objTaskMaster.setTask_desc(objTaskDetailVO.getTaskDesc());
			 objTaskMaster.setApp_group_id(Integer.valueOf(objTaskDetailVO.getGroupId()));
			 objTaskMaster.setStatus("A");
			 boolean flag = objTasksService.save(objTaskMaster);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
}