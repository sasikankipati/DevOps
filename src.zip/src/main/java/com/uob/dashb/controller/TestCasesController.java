package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.CommonUtil;
import com.uob.dashb.service.TestCaseService;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TestCaseVO;
import com.uob.dashb.vo.User;


@RestController
public class TestCasesController {
	
	@Autowired
	TestCaseService objTestCaseService;
	
	
	
	@RequestMapping(value="/loadNewTestCase",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String loadNewTestCase(HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objCommonVO.setArlSeverity(CommonUtil.getSeverity());
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/fetchAllTestCases",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllTestCases(HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<TestCaseVO> arlTestCaseVO = objTestCaseService.fetchAllTestCases();
			 objCommonVO.setArlTestCases(arlTestCaseVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/saveNewTestCase",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveNewTestCase(@RequestBody TestCaseVO objTestCaseVO, HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 boolean success =false;
			 objTestCaseVO.setRec_status("A");
			 /** Field validation check **/
			 
			 
			 /** Duplicate validation check **/
			 boolean exists = objTestCaseService.duplicateCheck(objTestCaseVO);
			 if(exists){
				 objCommonVO.setMessage("Duplicate Case ID exists ..!");
			 }else{
				 success = objTestCaseService.saveTestCase(objTestCaseVO);
			 }
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/deleteTestCase",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String deleteTestCase(@RequestBody TestCaseVO objTestCaseVO, HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objTestCaseVO.setRec_status("A");
			 boolean success = objTestCaseService.deleteTestCase(objTestCaseVO);
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 @RequestMapping(value="/viewTestCase",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewTestCase(@RequestBody TestCaseVO objTestCaseVO, HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objTestCaseVO.setRec_status("A");
			 objTestCaseVO = objTestCaseService.viewTestCase(objTestCaseVO);
			 objCommonVO.setObjTestCaseVO(objTestCaseVO);
			 objCommonVO.setArlSeverity(CommonUtil.getSeverity());
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
	 
	 @RequestMapping(value="/updateTestCase",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateTestCase(@RequestBody TestCaseVO objTestCaseVO, HttpServletRequest request,HttpServletResponse response) {
		 
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 objTestCaseVO.setRec_status("A");
			 boolean success = false;
			 /** Field validation check **/
			 
			 /** Duplicate validation check **/
			 boolean exists = objTestCaseService.duplicateCheck(objTestCaseVO);
			 if(exists){
				 objCommonVO.setMessage("Duplicate Case ID exists ..!");
			 }else{
				 success = objTestCaseService.updateTestCase(objTestCaseVO);
			 }
			 objCommonVO.setSuccess(success);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	 
}