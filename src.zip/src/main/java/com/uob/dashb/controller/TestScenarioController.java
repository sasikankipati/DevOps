package com.uob.dashb.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.EnvironmentService;
import com.uob.dashb.service.TestCaseService;
import com.uob.dashb.service.TestScenarioService;
import com.uob.dashb.vo.ApplicationVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.EnvironmentVO;
import com.uob.dashb.vo.TestCaseVO;
import com.uob.dashb.vo.TestScenarioVO;
import com.uob.dashb.vo.User;

@RestController
public class TestScenarioController {

	@Autowired
	TestScenarioService objTestScenarioService;
	
	@Autowired
	EnvironmentService objEnvironmentService;
	
	@Autowired
	ApplicationService objApplicationService;
	
	@Autowired
	TestCaseService objTestCaseService;

	@RequestMapping(value = "/fetchAllTestScenarios", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String fetchAllTestScenarios(HttpServletRequest request,
			HttpServletResponse response) {

		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");

		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			ArrayList<TestScenarioVO> arlTestScenarioVO = objTestScenarioService
					.fetchAllList();
			objCommonVO.setArlTestScenarioVO(arlTestScenarioVO);
			objCommonVO.setSuccess(true);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}

	@RequestMapping(value = "/loadTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String loadTestScenario(HttpServletRequest request,HttpServletResponse response) {

		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");

		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			ArrayList<ApplicationVO> arlApplications = objApplicationService.fetchAllApplications();
			objCommonVO.setArlApplications(arlApplications);
			
			ArrayList<EnvironmentVO> arlEnvironmentVO = objEnvironmentService.fetchAllList();
			objCommonVO.setArlEnvironmentVO(arlEnvironmentVO);
			
			ArrayList<TestCaseVO> arlTestCaseVO = objTestCaseService.fetchAllTestCases();
			 objCommonVO.setArlTestCases(arlTestCaseVO);
			 
			objCommonVO.setSuccess(true);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}

	@RequestMapping(value = "/deleteTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String deleteTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");

		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			boolean success = objTestScenarioService.deleteTestScenario(objTestScenarioVO);
			objCommonVO.setSuccess(success);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value = "/updateTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String updateTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {

		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");

		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			boolean success = false;
			/** Field validation check **/

			/** Duplicate validation check **/
			boolean exists = objTestScenarioService.duplicateCheck(objTestScenarioVO);
			if (!exists) {
				objCommonVO.setMessage("Scenario ID doesn't exists ..!");
			} else {
				success = objTestScenarioService.updateTestScenario(objTestScenarioVO);
			}
			objCommonVO.setSuccess(success);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	
	@RequestMapping(value = "/copyNewTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String copyNewTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {

		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");

		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			boolean success = false;
			/** Field validation check **/

			/** Duplicate validation check **/
			boolean exists = objTestScenarioService.duplicateCheck(objTestScenarioVO);
			if (exists) {
				objCommonVO.setMessage("Duplicate Scenario ID exists ..!");
			} else {
				success = objTestScenarioService.saveTestScenario(objTestScenarioVO);
			}
			 
			objCommonVO.setSuccess(success);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value = "/saveTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String saveTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");
		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = new CommonVO();
			boolean success = false;
			/** Field validation check **/

			/** Duplicate validation check **/
			boolean exists = objTestScenarioService.duplicateCheck(objTestScenarioVO);
			if (exists) {
				objCommonVO.setMessage("Duplicate Scenario ID exists ..!");
			} else {
				success = objTestScenarioService.saveTestScenario(objTestScenarioVO);
			}

			objCommonVO.setSuccess(success);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value = "/viewTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String viewTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");
		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = objTestScenarioService.viewTestScenario(objTestScenarioVO);
			ArrayList<ApplicationVO> arlApplications = objApplicationService.fetchAllApplications();
			objCommonVO.setArlApplications(arlApplications);
			ArrayList<EnvironmentVO> arlEnvironmentVO = objEnvironmentService.fetchAllList();
			objCommonVO.setArlEnvironmentVO(arlEnvironmentVO);
			objCommonVO.setSuccess(true);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
	
	@RequestMapping(value = "/copyTestScenario", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	@ResponseBody
	public String copyTestScenario(@RequestBody TestScenarioVO objTestScenarioVO,HttpServletRequest request,HttpServletResponse response) {
		System.out.println("Session ID >>>" + request.getSession().getId());
		User objUser = (User) request.getSession().getAttribute("userProfile");
		ObjectMapper mapper = new ObjectMapper();
		String jsonObject = "";
		try {
			CommonVO objCommonVO = objTestScenarioService.copyTestScenario(objTestScenarioVO);
			ArrayList<ApplicationVO> arlApplications = objApplicationService.fetchAllApplications();
			objCommonVO.setArlApplications(arlApplications);
			ArrayList<EnvironmentVO> arlEnvironmentVO = objEnvironmentService.fetchAllList();
			objCommonVO.setArlEnvironmentVO(arlEnvironmentVO);
			objCommonVO.setSuccess(true);
			jsonObject = mapper.writeValueAsString(objCommonVO);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonObject;
	}
}