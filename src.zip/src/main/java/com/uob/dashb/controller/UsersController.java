package com.uob.dashb.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.LoginService;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.User;
import com.uob.dashb.vo.UserApplicationGroupVO;
import com.uob.dashb.vo.UserRolesVO;
import com.uob.dashb.vo.UserVO;


@RestController
public class UsersController {
	
	@Autowired
	LoginService loginService;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	@Autowired
	ApplicationService objApplicationService;
	
	
	@RequestMapping(value="/logout",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String logout(HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 request.getSession().removeAttribute("userProfile");
			 request.getSession().invalidate();
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/changePassword",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String changePassword(@RequestBody UserVO objUserVO,HttpServletRequest request,HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 CommonVO objCommonVO = new CommonVO();
		 try {
			 UserProfile objUserProfile = loginService.authenticateUser(objUser.getLanid(),objUserVO.getCurPassword());
			 
			 if(null != objUserProfile){
				 objUserVO.setUserId(String.valueOf(objUser.getUserId()));
				 objUserVO.setPassword(objUserVO.getNewPassword());
				 loginService.updatePassword(objUserVO);
				 objCommonVO.setSuccess(true);
			 }else{
				 objCommonVO.setSuccess(false);
				 objCommonVO.setMessage("Password updation failed ..!");
			 }
		    } catch (Exception e) { 
		    	objCommonVO.setSuccess(false);
				objCommonVO.setMessage("Password updation failed ..!");
		    }finally{
		    	try {
					jsonObject = mapper.writeValueAsString(objCommonVO);
				} catch (Exception e) {
					e.printStackTrace();
				}
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/viewProfile",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewProfile(HttpServletRequest request,HttpServletResponse response) {
		
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 UserVO objUserVO = new UserVO();
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<UserApplicationGroupVO> arlUserAppGroup = new ArrayList<UserApplicationGroupVO>();
			 
			 UserProfile objUserProfile = loginService.getUser(String.valueOf(objUser.getUserId()));
			 objUserVO.setEmail(objUserProfile.getEmail());
			 objUserVO.setLanId(objUserProfile.getLanid());
			 objUserVO.setMobile(objUserProfile.getPhone());
			 objUserVO.setPassword(objUserProfile.getPassword());
			 objUserVO.setUserId(String.valueOf(objUserProfile.getUser_id()));
			 objUserVO.setUserName(objUserProfile.getUser_name());
			 if(null != objUserProfile.getAdminflag() && objUserProfile.getAdminflag().equalsIgnoreCase("Y")){
				 objUser.setAdmin(true);
			 }
			 
			 UserVO objUserRole = loginService.getUserRole(objUserProfile.getUser_id());
			 objUserVO.setRole(objUserRole.getRole());
			 objUserVO.setRoleDesc(objUserRole.getRoleDesc());
			 
			 ArrayList<UserRolesVO> arlRoles = loginService.fetchAllRoles();
			 objCommonVO.setArlUserRoles(arlRoles);
			 
			 StringBuffer appGroupIds = new StringBuffer();
			 UserApplicationGroupVO objUserApplicationGroupVO;
			 List<String> lsAppGroupIds = new ArrayList<String>();
			 
			 ArrayList<UserApplicationGroup> arlUserAppGroups = objApplicationService.fetchUserAppGroups(String.valueOf(objUserProfile.getUser_id()));
			 if(null != arlUserAppGroups && arlUserAppGroups.size() > 0){
				 for(UserApplicationGroup objUserApplicationGroup:arlUserAppGroups){
					 
					 appGroupIds.append(objUserApplicationGroup.getApp_group_id());
					 
					 lsAppGroupIds.add(String.valueOf(objUserApplicationGroup.getApp_group_id()));
					 objUserApplicationGroupVO = new UserApplicationGroupVO();
					 objUserApplicationGroupVO.setAppGroupId(String.valueOf(objUserApplicationGroup.getApp_group_id()));
					 objUserApplicationGroupVO.setUserAppGroupId(String.valueOf(objUserApplicationGroup.getUser_app_group_id()));
					 objUserApplicationGroupVO.setUserId(String.valueOf(objUserApplicationGroup.getUser_id()));
					 arlUserAppGroup.add(objUserApplicationGroupVO);
				 }
			 }
			 objCommonVO.setArlUserAppGroup(arlUserAppGroup);
			 objUserVO.setAppGroupIds(appGroupIds.toString());
			 objCommonVO.setObjUserVO(objUserVO);
			 objCommonVO.setLsAppGroupIds(lsAppGroupIds);
			 
			 ApplicationGroupVO objApplicationGroupVO;
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 
			 objCommonVO.setSuccess(true);
			 
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/viewUser",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String viewUser(@RequestBody UserVO objUserVO,HttpServletRequest request,HttpServletResponse response) {
		
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<UserApplicationGroupVO> arlUserAppGroup = new ArrayList<UserApplicationGroupVO>();
			 
			 UserProfile objUserProfile = loginService.getUser(objUserVO.getUserId());
			 objUserVO.setEmail(objUserProfile.getEmail());
			 objUserVO.setLanId(objUserProfile.getLanid());
			 objUserVO.setMobile(objUserProfile.getPhone());
			 objUserVO.setPassword(objUserProfile.getPassword());
			 objUserVO.setUserId(String.valueOf(objUserProfile.getUser_id()));
			 objUserVO.setUserName(objUserProfile.getUser_name());
			 if(null != objUserProfile.getAdminflag() && objUserProfile.getAdminflag().equalsIgnoreCase("Y")){
				 objUserVO.setAdmin(true);
			 }
			 UserVO objUserRole = loginService.getUserRole(objUserProfile.getUser_id());
			 objUserVO.setRole(objUserRole.getRole());
			 objUserVO.setRoleDesc(objUserRole.getRoleDesc());
			 
			 ArrayList<UserRolesVO> arlRoles = loginService.fetchAllRoles();
			 objCommonVO.setArlUserRoles(arlRoles);
			 
			 StringBuffer appGroupIds = new StringBuffer();
			 UserApplicationGroupVO objUserApplicationGroupVO;
			 List<String> lsAppGroupIds = new ArrayList<String>();
			 
			 ArrayList<UserApplicationGroup> arlUserAppGroups = objApplicationService.fetchUserAppGroups(String.valueOf(objUserProfile.getUser_id()));
			 if(null != arlUserAppGroups && arlUserAppGroups.size() > 0){
				 for(UserApplicationGroup objUserApplicationGroup:arlUserAppGroups){
					 
					 appGroupIds.append(objUserApplicationGroup.getApp_group_id());
					 
					 lsAppGroupIds.add(String.valueOf(objUserApplicationGroup.getApp_group_id()));
					 objUserApplicationGroupVO = new UserApplicationGroupVO();
					 objUserApplicationGroupVO.setAppGroupId(String.valueOf(objUserApplicationGroup.getApp_group_id()));
					 objUserApplicationGroupVO.setUserAppGroupId(String.valueOf(objUserApplicationGroup.getUser_app_group_id()));
					 objUserApplicationGroupVO.setUserId(String.valueOf(objUserApplicationGroup.getUser_id()));
					 arlUserAppGroup.add(objUserApplicationGroupVO);
				 }
			 }
			 objCommonVO.setArlUserAppGroup(arlUserAppGroup);
			 objUserVO.setAppGroupIds(appGroupIds.toString());
			 objCommonVO.setObjUserVO(objUserVO);
			 objCommonVO.setLsAppGroupIds(lsAppGroupIds);
			 
			 ApplicationGroupVO objApplicationGroupVO;
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 
			 objCommonVO.setSuccess(true);
			 
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/updateUser",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String updateUser(@RequestBody UserVO objUserVO,HttpServletRequest request,HttpServletResponse response) {
		
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();

			 System.out.println(objUserVO.getEmail());
			 System.out.println(objUserVO.getAppGroupIds());
			 System.out.println(objUserVO.getLanId());
			 System.out.println(objUserVO.getMobile());
			 System.out.println(objUserVO.getPassword());
			 System.out.println(objUserVO.getUserId());
			 System.out.println(objUserVO.getRole());
			 System.out.println(objUserVO.getLsAppGroupIds().size());
			 
			 UserProfile objUserProfile = loginService.updateUser(objUserVO);
			 objApplicationService.updateUserAppGroup(objUserVO.getLsAppGroupIds(),objUserVO.getUserId());
			 UserApplicationGroup objUserApplicationGroup;
			for(String strGroupId: objUserVO.getLsAppGroupIds()){
				objUserApplicationGroup = new UserApplicationGroup();
				objUserApplicationGroup.setUser_app_group_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_USER_APP_GROUP_SEQNO_SQL));
				objUserApplicationGroup.setApp_group_id(Integer.valueOf(strGroupId));
				objUserApplicationGroup.setUser_id(Integer.valueOf(objUserVO.getUserId()));
				objApplicationService.saveUserAppGroup(objUserApplicationGroup);
			}
			
			UserVO objUserRole = loginService.getUserRole(objUserProfile.getUser_id());
			if(null != objUserRole && null != objUserRole.getRole() && !objUserRole.getRole().equalsIgnoreCase(objUserVO.getRole())){
				loginService.updateUserRole(objUserProfile.getUser_id(),objUserVO.getRole());
			}else{
				loginService.insertUserRole(objUserProfile.getUser_id(),objUserVO.getRole());
			}
			
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/saveNewUser",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String saveNewUser(@RequestBody UserVO objUserVO,HttpServletRequest request,HttpServletResponse response) {
		
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();

			 System.out.println(objUserVO.getEmail());
			 System.out.println(objUserVO.getAppGroupIds());
			 System.out.println(objUserVO.getLanId());
			 System.out.println(objUserVO.getMobile());
			 System.out.println(objUserVO.getPassword());
			 System.out.println(objUserVO.getUserId());
			 System.out.println(objUserVO.getUserName());
			 
			 UserProfile userProfile = new UserProfile();
			 userProfile.setUser_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_USER_SEQNO_SQL));
			 userProfile.setEmail(objUserVO.getEmail());
			 userProfile.setLanid(objUserVO.getLanId());
			 userProfile.setPassword(objUserVO.getPassword());
			 userProfile.setPhone(objUserVO.getMobile());
			 userProfile.setStatus("A");
			 if(objUserVO.getAdmin()){
				 userProfile.setAdminflag("Y");
			 }else{
				 userProfile.setAdminflag("N");
			 }
			 userProfile.setUser_name(objUserVO.getUserName());
			 userProfile = loginService.save(userProfile);
			 
			 userProfile = loginService.fetchUserByLanId(userProfile.getLanid());
			 
			 System.out.println(userProfile.getUser_id());
			 UserApplicationGroup objUserApplicationGroup;
			 for(String appGroupId: objUserVO.getLsAppGroupIds()){
				 objUserApplicationGroup = new UserApplicationGroup();
				 objUserApplicationGroup.setUser_app_group_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_USER_APP_GROUP_SEQNO_SQL));
				 objUserApplicationGroup.setUser_id(userProfile.getUser_id());
				 objUserApplicationGroup.setApp_group_id(Integer.valueOf(appGroupId));
				 objApplicationService.saveUserAppGroup(objUserApplicationGroup);
			 }
			 
			 loginService.insertUserRole(userProfile.getUser_id(),objUserVO.getRole());
			 
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	@RequestMapping(value="/newUser",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String newUser(HttpServletRequest request,HttpServletResponse response) {
		
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();

			 ApplicationGroupVO objApplicationGroupVO;
			 ArrayList<ApplicationGroup> arlAppGroupEntity = objApplicationService.fetchAllAppGroups();
			 ArrayList<ApplicationGroupVO> arlApplicationGroupVO = new ArrayList<ApplicationGroupVO>();
			 for(ApplicationGroup objAppGroup:arlAppGroupEntity){
				 objApplicationGroupVO = new ApplicationGroupVO();
				 objApplicationGroupVO.setGroupName(objAppGroup.getApp_group_name());
				 objApplicationGroupVO.setDisplayOrder(objAppGroup.getDisplay_order());
				 objApplicationGroupVO.setEmail(objAppGroup.getEmail_distribution());
				 objApplicationGroupVO.setGroup_id(String.valueOf(objAppGroup.getApp_group_id()));
				 objApplicationGroupVO.setGroupOwner(objAppGroup.getApp_group_owner());
				 arlApplicationGroupVO.add(objApplicationGroupVO);
			 }
			 
			 ArrayList<UserRolesVO> arlRoles = loginService.fetchAllRoles();
			 objCommonVO.setArlUserRoles(arlRoles);
			 
			 objCommonVO.setArlAppGroups(arlApplicationGroupVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 @RequestMapping(value="/fetchAllUsers",method = RequestMethod.POST,headers="Accept=application/json",produces = "application/json")
	 @ResponseBody
	 public String fetchAllUsers(HttpServletRequest request, 
		        HttpServletResponse response) {
		 System.out.println("Session ID >>>"+request.getSession().getId());
		 User objUser = (User) request.getSession().getAttribute("userProfile");
		 
		 ObjectMapper mapper = new ObjectMapper(); 
		 String jsonObject = "";
		 try {
			 CommonVO objCommonVO = new CommonVO();
			 ArrayList<UserProfile> arlUserEntity = (ArrayList<UserProfile>) loginService.getAll();
			 ArrayList<UserVO> arlUserVO = new ArrayList<UserVO>();
			 UserVO objUserVO;

			 for(UserProfile objUserProfile:arlUserEntity){
				 objUserVO = new UserVO();
				 objUserVO.setEmail(objUserProfile.getEmail());
				 objUserVO.setLanId(objUserProfile.getLanid());
				 objUserVO.setMobile(objUserProfile.getPhone());
				 objUserVO.setUserId(String.valueOf(objUserProfile.getUser_id()));
				 objUserVO.setUserName(objUserProfile.getUser_name());
				 if(null != objUserProfile.getAdminflag() && objUserProfile.getAdminflag().equalsIgnoreCase("Y")){
					 objUserVO.setAdmin(true);
				 }
				 UserVO objUserRole = loginService.getUserRole(objUserProfile.getUser_id());
				 objUserVO.setRole(objUserRole.getRole());
				 objUserVO.setRoleDesc(objUserRole.getRoleDesc());
				 
				 arlUserVO.add(objUserVO);
			 }
			 
			 objCommonVO.setArlUser(arlUserVO);
			 objCommonVO.setSuccess(true);
			 jsonObject = mapper.writeValueAsString(objCommonVO);
		    } catch (Exception e) { 
		    	e.printStackTrace(); 
		    }
	  return jsonObject;
	 }
	
	 
}