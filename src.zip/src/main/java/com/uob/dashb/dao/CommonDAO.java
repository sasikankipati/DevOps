package com.uob.dashb.dao;



public interface CommonDAO {

	public int getNextSequence(String seqKey);

}
