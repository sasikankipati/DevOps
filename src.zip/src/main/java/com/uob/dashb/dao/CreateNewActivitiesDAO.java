package com.uob.dashb.dao;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.ActivityTransaction;
import com.uob.dashb.vo.NewActivityVO;



public interface CreateNewActivitiesDAO {

	ArrayList<NewActivityVO> fetchNextActivities(String valueOf, String curTime,
			String toTime);


	boolean saveNewActivity(ActivityTransaction objActivityTransaction);


}
