package com.uob.dashb.dao;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.Environment;
import com.uob.dashb.vo.EnvironmentVO;


public interface EnvironmentDAO {

	public ArrayList<Environment> fetchAllList();

	public boolean saveEnvironment(Environment objEnvironment);

	public Environment viewTestCase(Integer valueOf);

	public boolean updateEnvironment(EnvironmentVO objEnvironmentVO);

	public boolean deleteEnvironment(Integer valueOf);

	public ArrayList<Environment> getEnvironment(String valueOf);

}
