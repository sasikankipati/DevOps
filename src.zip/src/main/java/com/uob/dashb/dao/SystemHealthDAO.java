package com.uob.dashb.dao;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.TestStatus;
import com.uob.dashb.framework.database.entity.TestTracker;
import com.uob.dashb.vo.SystemHealthChkVO;


public interface SystemHealthDAO {



	public ArrayList<TestTracker> checkTestTracker(String scenario_id);

	public boolean saveTracker(TestTracker objTestTracker);

	public boolean saveTestStatus(TestStatus objTestStatus);

	public ArrayList<SystemHealthChkVO> fetchAppLvlStatus();

	public ArrayList<SystemHealthChkVO> fetchEnvLvlStatus(String appId);

	public ArrayList<SystemHealthChkVO> fetchTSLvlStatus(String appId,String country);

	public boolean updateTracker(SystemHealthChkVO objSystemHealthChkVO,TestTracker objTestTracker);

}
