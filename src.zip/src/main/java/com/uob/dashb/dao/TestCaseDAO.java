package com.uob.dashb.dao;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.TestCase;
import com.uob.dashb.framework.database.entity.TestScenario;
import com.uob.dashb.vo.TestCaseVO;


public interface TestCaseDAO {

	public ArrayList<TestCase> fetchAllTestCases();
	public boolean saveTestCase(TestCase objTestCase);
	public boolean deleteTestCase(Integer valueOf);
	public TestCase viewTestCase(Integer valueOf);
	public boolean updateTestCase(TestCaseVO objTestCaseVO);
	public ArrayList<TestCase> getTestCase(String case_id);

}
