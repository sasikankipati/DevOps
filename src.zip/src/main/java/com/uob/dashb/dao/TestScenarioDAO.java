package com.uob.dashb.dao;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.TestScenario;
import com.uob.dashb.vo.TestScenarioVO;

public interface TestScenarioDAO {

	public ArrayList<TestScenario> fetchAllList();

	public boolean saveTestScenario(TestScenario objTestScenario);

	public ArrayList<TestScenario> viewTestScenario(String scenario_id);

	public boolean deleteTestScenario(String scenario_id);

	public ArrayList<TestScenario> checkTSifExists(String scenario_id, String case_id);



}
