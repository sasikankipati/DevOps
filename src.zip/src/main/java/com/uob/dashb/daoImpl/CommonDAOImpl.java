package com.uob.dashb.daoImpl;


import java.math.BigDecimal;
import java.math.BigInteger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.CommonDAO;



@Service("CommonDAO")
public class CommonDAOImpl implements CommonDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public int getNextSequence(String seqKey){
		Query queryFindItems = entityManager.createNativeQuery(seqKey);
		BigDecimal nextVal = (BigDecimal)queryFindItems.getResultList().get(0);
		return nextVal.intValue();
	}

	
}