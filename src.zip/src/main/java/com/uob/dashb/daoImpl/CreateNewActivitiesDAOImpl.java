package com.uob.dashb.daoImpl;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.CreateNewActivitiesDAO;
import com.uob.dashb.framework.database.entity.ActivityTransaction;
import com.uob.dashb.framework.database.entity.TaskMasterLink;
import com.uob.dashb.vo.NewActivityVO;



@Service("CreateNewActivitiesDAO")
public class CreateNewActivitiesDAOImpl implements CreateNewActivitiesDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	@Override
	public ArrayList<NewActivityVO> fetchNextActivities(String dayOfWeek,
			String curTime, String toTime) {
		ArrayList<NewActivityVO> arlNewActVO = new ArrayList<NewActivityVO>();
		NewActivityVO objNewActivityVO;
		System.out.println(" Parameters passing >>"+curTime + toTime);
		Query query = entityManager.createQuery("select p from TaskMasterLink p where substr(day_of_week,:DOF,1) = 1 and start_time >=:StartTIME and start_time <=:ENDTIME");
		query.setParameter("DOF", dayOfWeek);
		query.setParameter("StartTIME", curTime);
		query.setParameter("ENDTIME", toTime);
		ArrayList<TaskMasterLink> items = (ArrayList<TaskMasterLink>) query.getResultList();
		
		if(null != items && items.size() > 0){
			for(TaskMasterLink fromObj:items){
				objNewActivityVO = new NewActivityVO();
				BeanUtils.copyProperties(fromObj, objNewActivityVO);
				arlNewActVO.add(objNewActivityVO);
			}
		}
		
		return arlNewActVO;
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED)
	public boolean saveNewActivity(ActivityTransaction objActivityTransaction) {
		entityManager.persist(objActivityTransaction);
		entityManager.flush();
		return true;
	}

	
}