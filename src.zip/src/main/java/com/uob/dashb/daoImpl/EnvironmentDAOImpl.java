package com.uob.dashb.daoImpl;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.EnvironmentDAO;
import com.uob.dashb.framework.database.entity.Environment;
import com.uob.dashb.vo.EnvironmentVO;



@Service("EnvironmentDAO")
public class EnvironmentDAOImpl implements EnvironmentDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Override
	public ArrayList<Environment> fetchAllList() {
		Query query = entityManager.createQuery("SELECT p FROM Environment p where rec_status=:rec_status");
		query.setParameter("rec_status", "A");
		ArrayList<Environment> items = (ArrayList<Environment>) query.getResultList();
		return items;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveEnvironment(Environment objEnvironment) {
		entityManager.persist(objEnvironment);
		entityManager.flush();
		return true;
	}

	@Override
	public Environment viewTestCase(Integer id) {
		Environment objEnvironment = entityManager.find(Environment.class, id);
		return objEnvironment;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean updateEnvironment(EnvironmentVO objEnvironmentVO) {
		Environment objEnvironment = entityManager.find(Environment.class, Integer.valueOf(objEnvironmentVO.getEnvironment_id()));
		objEnvironment.setEnv_id(objEnvironmentVO.getEnv_id());
		objEnvironment.setEnv_name(objEnvironmentVO.getEnv_name());
		objEnvironment.setEnv_desc(objEnvironmentVO.getEnv_desc());
		objEnvironment.setRemarks(objEnvironmentVO.getRemarks());
		objEnvironment.setCountry(objEnvironmentVO.getCountry());
		entityManager.persist(objEnvironment);
		entityManager.flush();
		return true;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean deleteEnvironment(Integer id) {
		Environment objEnvironment = entityManager.find(Environment.class, id);
		objEnvironment.setRec_status("D");
		entityManager.persist(objEnvironment);
		entityManager.flush();
		return true;
	}

	@Override
	public ArrayList<Environment> getEnvironment(String env_id) {
		Query query = entityManager.createQuery("SELECT p FROM Environment p where rec_status=:rec_status and env_id=:env_id");
		query.setParameter("rec_status", "A");
		query.setParameter("env_id", env_id);
		ArrayList<Environment> items = (ArrayList<Environment>) query.getResultList();
		return items;
	}
	
}