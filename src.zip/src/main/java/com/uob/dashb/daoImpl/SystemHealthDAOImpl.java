package com.uob.dashb.daoImpl;


import java.math.BigDecimal;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.SystemHealthDAO;
import com.uob.dashb.framework.database.entity.TestStatus;
import com.uob.dashb.framework.database.entity.TestTracker;
import com.uob.dashb.vo.SystemHealthChkVO;



@Service("SystemHealthDAO")
public class SystemHealthDAOImpl implements SystemHealthDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}


	@Override
	public ArrayList<TestTracker> checkTestTracker(String scenario_id) {
		Query query = entityManager.createQuery("SELECT p FROM TestTracker p where scenario_id=:scenario_id");
		query.setParameter("scenario_id", scenario_id);
		//query.setParameter("exec_date", exec_date);
		//query.setParameter("exec_time", exec_time);
		ArrayList<TestTracker> items = (ArrayList<TestTracker>) query.getResultList();
		return items;
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED)
	public boolean saveTracker(TestTracker objTestTracker) {
		entityManager.persist(objTestTracker);
		entityManager.flush();
		return true;
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED)
	public boolean saveTestStatus(TestStatus objTestStatus) {
		entityManager.persist(objTestStatus);
		entityManager.flush();
		return true;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchAppLvlStatus() {
		/*String query = "select app_id, RAG, Country, count(1) cnt,max(exec_date) exec_date, max(exec_time) exec_time from (select app_id, env_id, country, count(total) total, count(completed) completed, decode (MAX(RAG), '1', 'G', '2', 'A','3','R') RAG,,max(exec_date) exec_date, max(exec_time) exec_time " 
					  +"from (select tc.case_id, e.env_id, ts.app_id, e.country, ts.SCENARIO_ID total, ss.SCENARIO_ID completed, ss.EXEC_DATE,ss.EXEC_TIME, "
					  +"DECODE ( NVL(ss.status, tc.severity), '0', tc.severity, 1, '1', tc.severity) RAG from test_case tc, test_scenario ts, environment e, "
					  +"(select ss.* from test_status ss,  test_Tracker tk where ss.scenario_id(+) = tk.scenario_id AND ss.exec_date (+) = tk.exec_date AND ss.exec_time (+) = tk.exec_time ) ss "
					  +"where ts.case_id = tc.case_id (+) and e.env_id = ts.env_id and ts.case_id = ss.case_id (+) and ts.scenario_id = ss.scenario_id (+) ) group by app_id, country, env_id ) "
					  +"group by app_id, country, RAG order by app_id, country, exec_date, exec_time";*/
		
		/*String query = 		"select app_id, RAG, Country,count(1) cnt,max(exec_date) exec_date, max(exec_time) exec_time  from (select app_id, env_id, country, count(total) total, count(completed) completed, decode (MAX(RAG), '1', 'G', '2', 'A','3','R') RAG, max(exec_date) exec_date, max(exec_time) exec_time " 
			+"from (select tc.case_id, e.env_id, ts.app_id, e.country, ts.SCENARIO_ID total, ss.SCENARIO_ID completed, ss.EXEC_DATE,ss.EXEC_TIME, DECODE ( NVL(ss.status, tc.severity), '0', tc.severity, 1, '1', tc.severity) RAG " 
				+"from test_case tc, test_scenario ts, environment e, (select ss.* from test_status ss,  test_Tracker tk where ss.scenario_id(+) = tk.scenario_id AND ss.exec_date (+) = tk.exec_date AND ss.exec_time (+) = tk.exec_time ) ss " 
				+"where ts.case_id = tc.case_id (+) and e.env_id = ts.env_id and ts.case_id = ss.case_id (+) and ts.scenario_id = ss.scenario_id (+) ) group by app_id, country, env_id ) group by app_id, country, RAG order by app_id, country, exec_date, exec_time ";*/ 
		
		
		String query = "select A.app_id, RAG, Country,count(1) cnt,max(exec_date) exec_date, max(exec_time) exec_time  from (select app_id, env_id, country, count(total) total, count(completed) completed, decode (MAX(RAG), '1', 'G', '2', 'A','3','R') RAG, max(exec_date) exec_date, max(exec_time) exec_time " 
						+"from (select tc.case_id, e.env_id, ts.app_id, e.country, ts.SCENARIO_ID total, ss.SCENARIO_ID completed, ss.EXEC_DATE,ss.EXEC_TIME, DECODE ( NVL(ss.status, tc.severity), '0', tc.severity, 1, '1', tc.severity) RAG " 
						+"from test_case tc, test_scenario ts, environment e, (select ss.* from test_status ss,  test_Tracker tk where ss.scenario_id(+) = tk.scenario_id AND ss.exec_date (+) = tk.exec_date AND ss.exec_time (+) = tk.exec_time ) ss " 
						+"where ts.case_id = tc.case_id (+) and e.env_id = ts.env_id and ts.case_id = ss.case_id (+) and ts.scenario_id = ss.scenario_id (+) ) group by app_id, country, env_id ) INN, APPLICATION A " 
						+"WHERE A.APP_ID='GEB' and A.APP_ID = INN.APP_ID (+) group by A.DISPLAY_ORDER, A.app_id, country, RAG  order by A.DISPLAY_ORDER, country, exec_date, exec_time ";
		
		Query activityList = entityManager.createNativeQuery(query);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<SystemHealthChkVO> arlHealthCheck = new ArrayList<SystemHealthChkVO>();
		SystemHealthChkVO objSystemHealthChkVO;
		for(Object[] obj:arlResult){
			objSystemHealthChkVO = new SystemHealthChkVO();
			objSystemHealthChkVO.setAppId((String)obj[0]);
			objSystemHealthChkVO.setStatus((String)obj[1]);
			objSystemHealthChkVO.setCountry((String)obj[2]);
			objSystemHealthChkVO.setCount(String.valueOf(((BigDecimal)obj[3]).intValue()));
			objSystemHealthChkVO.setExec_date((String)obj[4]);
			objSystemHealthChkVO.setExec_time((String)obj[5]);
			arlHealthCheck.add(objSystemHealthChkVO);
		}
		return arlHealthCheck;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchEnvLvlStatus(String appId) {
		String query = 		"select app_id, RAG, Country, sum(total) total, sum(completed) completed, max(exec_date) exec_date, max(exec_time) exec_time, env_id  from ( " 
							+"select app_id, env_id, country, count(total) total, count(completed) completed, decode ((RAG), '1', 'G', '2', 'A','3','R') RAG, max(exec_date) exec_date, max(exec_time) exec_time " 
							+"from (select tc.case_id, e.env_id, ts.app_id, e.country, ts.SCENARIO_ID total, ss.SCENARIO_ID completed, ss.EXEC_DATE,ss.EXEC_TIME, DECODE ( NVL(ss.status, tc.severity), '0', tc.severity, 1, '1', tc.severity) RAG " 
							+"from test_case tc, test_scenario ts, environment e, (select ss.* from test_status ss,  test_Tracker tk where ss.scenario_id(+) = tk.scenario_id AND ss.exec_date (+) = tk.exec_date AND ss.exec_time (+) = tk.exec_time ) ss " 
							+"where ts.case_id = tc.case_id (+) and e.env_id = ts.env_id and ts.case_id = ss.case_id (+) and ts.scenario_id = ss.scenario_id (+) AND APP_ID =:appId ) group by app_id, country, env_id ,decode ((RAG), '1', 'G', '2', 'A','3','R')) " 
							+"group by app_id, country, RAG, env_id order by app_id, country, env_id, exec_date, exec_time"; 
			
			Query activityList = entityManager.createNativeQuery(query);
			activityList.setParameter("appId", appId);
			ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
			ArrayList<SystemHealthChkVO> arlHealthCheck = new ArrayList<SystemHealthChkVO>();
			SystemHealthChkVO objSystemHealthChkVO;
			for(Object[] obj:arlResult){
				objSystemHealthChkVO = new SystemHealthChkVO();
				objSystemHealthChkVO.setAppId((String)obj[0]);
				objSystemHealthChkVO.setStatus((String)obj[1]);
				objSystemHealthChkVO.setCountry((String)obj[2]);
				objSystemHealthChkVO.setTotalCnt(((BigDecimal)obj[3]).intValue());
				objSystemHealthChkVO.setCompletedCnt(((BigDecimal)obj[4]).intValue());
				objSystemHealthChkVO.setExec_date((String)obj[5]);
				objSystemHealthChkVO.setExec_time((String)obj[6]);
				objSystemHealthChkVO.setEnv((String)obj[7]);
				arlHealthCheck.add(objSystemHealthChkVO);
			}
			return arlHealthCheck;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchTSLvlStatus(String appId,String country) {
		String query = "select app_id, RAG, Country, SCENARIO_ID, sum(completed) completed, max(exec_date) exec_date, max(exec_time) exec_time, env_id,case_id  from ( "
						+"select app_id, env_id, country, SCENARIO_ID, count(completed) completed, decode ((RAG), '1', 'G', '2', 'A','3','R') RAG, max(exec_date) exec_date, max(exec_time) exec_time ,case_id "
						+"from (select tc.case_id, e.env_id, ts.app_id, e.country, ts.SCENARIO_ID, ss.SCENARIO_ID completed, ss.EXEC_DATE,ss.EXEC_TIME, DECODE ( NVL(ss.status, tc.severity), '0', tc.severity, 1, '1', tc.severity) RAG " 
						+"from test_case tc, test_scenario ts, environment e, (select ss.* from test_status ss,  test_Tracker tk where ss.scenario_id(+) = tk.scenario_id AND ss.exec_date (+) = tk.exec_date AND ss.exec_time (+) = tk.exec_time ) ss " 
						+"where ts.case_id = tc.case_id (+) and e.env_id = ts.env_id and ts.case_id = ss.case_id (+) and ts.scenario_id = ss.scenario_id (+) " 
						+"AND APP_ID =:appId and COUNTRY=:country ) group by app_id, country, env_id ,decode ((RAG), '1', 'G', '2', 'A','3','R') ,SCENARIO_ID,case_id ) group by app_id, country, RAG, env_id,SCENARIO_ID,case_id "
						+"order by app_id, country, env_id, exec_date, exec_time ";
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("appId", appId);
		activityList.setParameter("country", country);
		
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<SystemHealthChkVO> arlHealthCheck = new ArrayList<SystemHealthChkVO>();
		SystemHealthChkVO objSystemHealthChkVO;
		
		for(Object[] obj:arlResult){
			objSystemHealthChkVO = new SystemHealthChkVO();
			objSystemHealthChkVO.setAppId((String)obj[0]);
			objSystemHealthChkVO.setStatus((String)obj[1]);
			objSystemHealthChkVO.setCountry((String)obj[2]);
			objSystemHealthChkVO.setScenario_id((String)obj[3]);
			objSystemHealthChkVO.setExec_date((String)obj[5]);
			objSystemHealthChkVO.setExec_time((String)obj[6]);
			objSystemHealthChkVO.setEnv((String)obj[7]);
			objSystemHealthChkVO.setCase_id((String)obj[8]);
			arlHealthCheck.add(objSystemHealthChkVO);
		}
		return arlHealthCheck;
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED)
	public boolean updateTracker(SystemHealthChkVO objSystemHealthChkVO,TestTracker objTestTracker1) {
		TestTracker objTestTracker = entityManager.find(TestTracker.class, Integer.valueOf(objTestTracker1.getTest_tracker_id()));
		objTestTracker.setExec_date(objSystemHealthChkVO.getExec_date());
		objTestTracker.setExec_time(objSystemHealthChkVO.getExec_time());
		entityManager.flush();
		return true;
	}
	
}