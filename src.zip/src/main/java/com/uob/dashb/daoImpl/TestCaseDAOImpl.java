package com.uob.dashb.daoImpl;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.TestCaseDAO;
import com.uob.dashb.framework.database.entity.TestCase;
import com.uob.dashb.vo.TestCaseVO;



@Service("TestCaseDAO")
public class TestCaseDAOImpl implements TestCaseDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Override
	public ArrayList<TestCase> fetchAllTestCases() {
		Query query = entityManager.createQuery("SELECT p FROM TestCase p where rec_status=:rec_status");
		query.setParameter("rec_status", "A");
		ArrayList<TestCase> items = (ArrayList<TestCase>) query.getResultList();
		return items;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveTestCase(TestCase objTestCase) {
		entityManager.persist(objTestCase);
		entityManager.flush();
		return true;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean deleteTestCase(Integer id) {
		TestCase objTestCase = entityManager.find(TestCase.class, id);
		objTestCase.setRec_status("D");
		entityManager.persist(objTestCase);
		entityManager.flush();
		return true;
	}

	@Override
	public TestCase viewTestCase(Integer id) {
		TestCase objTestCase = entityManager.find(TestCase.class, id);
		return objTestCase;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean updateTestCase(TestCaseVO objTestCaseVO) {
		TestCase objTestCase = entityManager.find(TestCase.class, Integer.valueOf(objTestCaseVO.getTest_case_id()));
		objTestCase.setCase_desc(objTestCaseVO.getCase_desc());
		objTestCase.setCase_id(objTestCaseVO.getCase_id());
		objTestCase.setRemarks(objTestCaseVO.getRemarks());
		objTestCase.setSeverity(objTestCaseVO.getSeverity());
		entityManager.persist(objTestCase);
		entityManager.flush();
		return true;
	}

	@Override
	public ArrayList<TestCase> getTestCase(String case_id) {
		Query query = entityManager.createQuery("SELECT p FROM TestCase p where rec_status=:rec_status and case_id=:case_id");
		query.setParameter("rec_status", "A");
		query.setParameter("case_id", case_id);
		ArrayList<TestCase> items = (ArrayList<TestCase>) query.getResultList();
		return items;
	}
}