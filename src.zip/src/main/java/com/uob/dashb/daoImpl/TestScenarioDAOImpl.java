package com.uob.dashb.daoImpl;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.dao.TestScenarioDAO;
import com.uob.dashb.framework.database.entity.TestScenario;



@Service("TestScenarioDAO")
public class TestScenarioDAOImpl implements TestScenarioDAO {

	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Override
	public ArrayList<TestScenario> fetchAllList() {
		String strQuery = "select scenario_id,scenario_desc,env_id,app_id from test_scenario group by scenario_id,scenario_desc,env_id,app_id";
		Query query = entityManager.createNativeQuery(strQuery);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) query.getResultList();
		TestScenario objTestScenario;
		ArrayList<TestScenario> items = new ArrayList<TestScenario>();
		for(Object[] obj:arlResult){
			objTestScenario = new TestScenario();
			objTestScenario.setScenario_id((String)obj[0]);
			objTestScenario.setScenario_desc((String)obj[1]);
			objTestScenario.setEnv_id((String)obj[2]);
			objTestScenario.setApp_id((String)obj[3]);
			items.add(objTestScenario);
		}
		return items;
	}
	
	

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveTestScenario(TestScenario objTestScenario) {
		entityManager.persist(objTestScenario);
		entityManager.flush();
		return true;
	}

	@Override
	public ArrayList<TestScenario> viewTestScenario(String scenario_id) {
		Query query = entityManager.createQuery("SELECT p FROM TestScenario p where scenario_id=:scenario_id");
		query.setParameter("scenario_id", scenario_id);
		ArrayList<TestScenario> items = (ArrayList<TestScenario>) query.getResultList();
		return items;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean deleteTestScenario(String scenario_id) {
		Query query = entityManager.createQuery("SELECT p FROM TestScenario p where scenario_id=:scenario_id");
		query.setParameter("scenario_id", scenario_id);
		ArrayList<TestScenario> arlTestScenEntity = (ArrayList<TestScenario>) query.getResultList();
		for(TestScenario objEntity:arlTestScenEntity){
			deleteEntity(objEntity);
		}
		return true;
	}

	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void deleteEntity(TestScenario objTestScenario) {
		entityManager.remove(entityManager.getReference(TestScenario.class, objTestScenario.getTest_scenario_id()));
		entityManager.flush();
	}

	@Override
	public ArrayList<TestScenario> checkTSifExists(String scenario_id,String case_id) {
		Query query = entityManager.createQuery("SELECT p FROM TestScenario p where scenario_id=:scenario_id and case_id=:case_id");
		query.setParameter("scenario_id", scenario_id);
		query.setParameter("case_id", case_id);
		ArrayList<TestScenario> items = (ArrayList<TestScenario>) query.getResultList();
		return items;
	}
	
}