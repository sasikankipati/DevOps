package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "activity_master")
public class ActivityMaster {
	
	@Id
	@Column(name = "activity_id", updatable=false)
	 private int activity_id;
	
	@Basic
    @Column(name = "activity_desc")
	 private String activity_desc;
	
	@Basic
	@Column(name="environment")
	private String environment;
	
	 
	 @Override
	 public String toString() {
	  return "Task [activity_id=" + activity_id + ", activity_desc=" + activity_desc +"]";
	 }

	public int getActivity_id() {
		return activity_id;
	}

	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}

	public String getActivity_desc() {
		return activity_desc;
	}

	public void setActivity_desc(String activity_desc) {
		this.activity_desc = activity_desc;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	

}
