package com.uob.dashb.framework.database.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "activity_transaction")
public class ActivityTransaction implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "act_tnx_id", updatable=false)
	private int act_tnx_id;
	
	@Basic
    @Column(name = "job_master_id")
	private int job_master_id;
	
	@Basic
    @Column(name = "group_id")
	private int group_id;
	
	@Basic
    @Column(name = "task_activity_id")
	private int task_activity_id;
	
	@Basic
    @Column(name = "created_on")
	private Timestamp created_on;
	
	@Basic
	@Column(name="activitygroup")
	private int activitygroup;
	
	@Basic
    @Column(name = "scheduled_on")
	private Timestamp scheduled_on;
	
	@Basic
    @Column(name = "to_be_completed_on")
	private Timestamp to_be_completed_on;
	
	@Basic
    @Column(name = "created_by")
	private String created_by;
	
	@Basic
    @Column(name = "updated_on")
	private Timestamp updated_on;
	
	@Basic
    @Column(name = "updated_by")
	private String updated_by;
	
	@Basic
    @Column(name = "remarks")
	private String remarks;
	
	@Basic
    @Column(name = "completion_flag")
	private String completion_flag;
	
	@Basic
    @Column(name = "completed_time")
	private Timestamp completed_time;
	
	@Basic
    @Column(name = "completed_by")
	private String completed_by;
	
	@Basic
    @Column(name = "rag")
	private String rag;
	
	@Basic
    @Column(name = "alert_sent_time")
	private Timestamp alert_sent_time;
	
	@Basic
    @Column(name = "reminder_sent_time")
	private Timestamp reminder_sent_time;
	
	@Basic
    @Column(name = "force_time")
	private Timestamp force_time;
	
	@Basic
    @Column(name = "force_by")
	private String force_by;
	
	@Basic
    @Column(name = "force_reason")
	private String  force_reason;
	
	
	@Basic
    @Column(name = "environment")
	private String  environment;
	
	
	@Basic
    @Column(name = "actual_stime")
	 private String actual_stime;
	
	@Basic
    @Column(name = "actual_etime")
	private String actual_etime;
	
	@Basic
    @Column(name = "activity_id")
	private int activity_id;
	
	@Basic
    @Column(name = "txngroup")
	private int txngroup;
	
	public int getAct_tnx_id() {
		return act_tnx_id;
	}
	public void setAct_tnx_id(int act_tnx_id) {
		this.act_tnx_id = act_tnx_id;
	}
	public int getTask_activity_id() {
		return task_activity_id;
	}
	public void setTask_activity_id(int task_activity_id) {
		this.task_activity_id = task_activity_id;
	}
	public Timestamp getCreated_on() {
		return created_on;
	}
	public void setCreated_on(Timestamp created_on) {
		this.created_on = created_on;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public Timestamp getUpdated_on() {
		return updated_on;
	}
	public void setUpdated_on(Timestamp updated_on) {
		this.updated_on = updated_on;
	}
	public String getUpdated_by() {
		return updated_by;
	}
	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Timestamp getCompleted_time() {
		return completed_time;
	}
	public void setCompleted_time(Timestamp completed_time) {
		this.completed_time = completed_time;
	}
	public String getCompleted_by() {
		return completed_by;
	}
	public void setCompleted_by(String completed_by) {
		this.completed_by = completed_by;
	}
	public String getRag() {
		return rag;
	}
	public void setRag(String rag) {
		this.rag = rag;
	}
	public Timestamp getAlert_sent_time() {
		return alert_sent_time;
	}
	public void setAlert_sent_time(Timestamp alert_sent_time) {
		this.alert_sent_time = alert_sent_time;
	}
	public Timestamp getReminder_sent_time() {
		return reminder_sent_time;
	}
	public void setReminder_sent_time(Timestamp reminder_sent_time) {
		this.reminder_sent_time = reminder_sent_time;
	}
	public Timestamp getForce_time() {
		return force_time;
	}
	public void setForce_time(Timestamp force_time) {
		this.force_time = force_time;
	}
	public String getForce_by() {
		return force_by;
	}
	public void setForce_by(String force_by) {
		this.force_by = force_by;
	}
	public String getForce_reason() {
		return force_reason;
	}
	public void setForce_reason(String force_reason) {
		this.force_reason = force_reason;
	}
	public Timestamp getScheduled_on() {
		return scheduled_on;
	}
	public void setScheduled_on(Timestamp scheduled_on) {
		this.scheduled_on = scheduled_on;
	}
	public Timestamp getTo_be_completed_on() {
		return to_be_completed_on;
	}
	public void setTo_be_completed_on(Timestamp to_be_completed_on) {
		this.to_be_completed_on = to_be_completed_on;
	}
	public int getActivitygroup() {
		return activitygroup;
	}
	public void setActivitygroup(int activitygroup) {
		this.activitygroup = activitygroup;
	}
	public int getJob_master_id() {
		return job_master_id;
	}
	public void setJob_master_id(int job_master_id) {
		this.job_master_id = job_master_id;
	}
	public String getActual_stime() {
		return actual_stime;
	}
	public void setActual_stime(String actual_stime) {
		this.actual_stime = actual_stime;
	}
	public String getActual_etime() {
		return actual_etime;
	}
	public void setActual_etime(String actual_etime) {
		this.actual_etime = actual_etime;
	}
	public int getActivity_id() {
		return activity_id;
	}
	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}
	public int getTxngroup() {
		return txngroup;
	}
	public void setTxngroup(int txngroup) {
		this.txngroup = txngroup;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getCompletion_flag() {
		return completion_flag;
	}
	public void setCompletion_flag(String completion_flag) {
		this.completion_flag = completion_flag;
	}
	public int getGroup_id() {
		return group_id;
	}
	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}

	
	
	/* @Override
	 public String toString() {
	  return "Task [app_id=" + app_id + ", app_desc=" + app_desc
	    + ", app_owner=" + app_owner + ", status="
	    + status +",ascc_app_code="+ascc_app_code+",display_order="+display_order
	    +",app_group_id="+app_group_id +"]";
	 }*/
		
}
