package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "application")
public class Application {
	
	@Id
	@Column(name = "app_id", updatable=false)
	private String app_id;
	
	@Basic
    @Column(name = "app_desc")
	private String app_desc;
	
	@Basic
    @Column(name = "app_owner")
	private int app_owner;
	
	@Basic
    @Column(name = "status")
	private String status;
	
	@Basic
    @Column(name = "ascc_app_code")
	private String ascc_app_code;
	
	@Basic
    @Column(name = "display_order")
	private String display_order;
	
	@Basic
    @Column(name = "app_group_id")
	private int app_group_id;
	 
	 @Override
	 public String toString() {
	  return "Task [app_id=" + app_id + ", app_desc=" + app_desc
	    + ", app_owner=" + app_owner + ", status="
	    + status +",ascc_app_code="+ascc_app_code+",display_order="+display_order
	    +",app_group_id="+app_group_id +"]";
	 }
		
	 public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getApp_desc() {
		return app_desc;
	}

	public void setApp_desc(String app_desc) {
		this.app_desc = app_desc;
	}


	public int getApp_owner() {
		return app_owner;
	}

	public void setApp_owner(int app_owner) {
		this.app_owner = app_owner;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAscc_app_code() {
		return ascc_app_code;
	}

	public void setAscc_app_code(String ascc_app_code) {
		this.ascc_app_code = ascc_app_code;
	}

	public String getDisplay_order() {
		return display_order;
	}

	public void setDisplay_order(String display_order) {
		this.display_order = display_order;
	}

	public int getApp_group_id() {
		return app_group_id;
	}

	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}

}
