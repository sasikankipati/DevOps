package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "application_group")
public class ApplicationGroup {
	
	@Id
	@Column(name = "app_group_id", updatable=false)
	private int app_group_id;
	
	@Basic
	@Column(name="app_group_name")
	private String app_group_name;
	
	@Basic
	@Column(name="email_distribution")
	private String email_distribution;
	
	@Basic
	@Column(name="app_group_owner")
	private String app_group_owner;
	
	@Basic
	@Column(name="display_order")
	private String display_order;
	 
	 @Override
	 public String toString() {
	  return "Task [app_group_id=" + app_group_id + ", app_group_name=" + app_group_name
	    + ", email_distribution=" + email_distribution + ", app_group_owner="
	    + app_group_owner +",display_order="+display_order +"]";
	 }

	public int getApp_group_id() {
		return app_group_id;
	}

	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}

	public String getApp_group_name() {
		return app_group_name;
	}

	public void setApp_group_name(String app_group_name) {
		this.app_group_name = app_group_name;
	}

	public String getEmail_distribution() {
		return email_distribution;
	}

	public void setEmail_distribution(String email_distribution) {
		this.email_distribution = email_distribution;
	}

	public String getApp_group_owner() {
		return app_group_owner;
	}

	public void setApp_group_owner(String app_group_owner) {
		this.app_group_owner = app_group_owner;
	}

	public String getDisplay_order() {
		return display_order;
	}

	public void setDisplay_order(String display_order) {
		this.display_order = display_order;
	}

}
