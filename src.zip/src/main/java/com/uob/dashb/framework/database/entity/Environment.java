package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "environment")
public class Environment {
	
	@Id
	@Column(name = "environment_id", updatable=false)
	private int environment_id;
	
	@Basic
    @Column(name = "env_id")
	private String env_id;
	
	@Basic
	@Column(name="env_name")
	private String env_name;
	
	@Basic
	@Column(name="env_desc")
	private String env_desc;

	@Basic
	@Column(name="rec_status")
	private String rec_status;

	@Basic
	@Column(name="remarks")
	private String remarks;

	@Basic
	@Column(name="country")
	private String country;

	public int getEnvironment_id() {
		return environment_id;
	}

	public void setEnvironment_id(int environment_id) {
		this.environment_id = environment_id;
	}

	public String getEnv_id() {
		return env_id;
	}

	public void setEnv_id(String env_id) {
		this.env_id = env_id;
	}

	public String getEnv_name() {
		return env_name;
	}

	public void setEnv_name(String env_name) {
		this.env_name = env_name;
	}

	public String getEnv_desc() {
		return env_desc;
	}

	public void setEnv_desc(String env_desc) {
		this.env_desc = env_desc;
	}

	public String getRec_status() {
		return rec_status;
	}

	public void setRec_status(String rec_status) {
		this.rec_status = rec_status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
}
