package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "job_dependency")
public class JobDependency {
	
	@Id
	@Column(name = "job_dependency_id", updatable=false)
	 private int job_dependency_id;
	
	@Basic
    @Column(name = "job_master_id")
	private int job_master_id;
	
	@Basic
    @Column(name = "upstream_dep")
	 private String upstream_dep;
	
	@Basic
    @Column(name = "downstream_dep")
	 private String downstream_dep;
	
	@Basic
    @Column(name = "impact")
	 private String impact;
	
	@Basic
    @Column(name = "remparks")
	 private String remarks;

	public int getJob_dependency_id() {
		return job_dependency_id;
	}

	public void setJob_dependency_id(int job_dependency_id) {
		this.job_dependency_id = job_dependency_id;
	}

	public int getJob_master_id() {
		return job_master_id;
	}

	public void setJob_master_id(int job_master_id) {
		this.job_master_id = job_master_id;
	}

	public String getUpstream_dep() {
		return upstream_dep;
	}

	public void setUpstream_dep(String upstream_dep) {
		this.upstream_dep = upstream_dep;
	}

	public String getDownstream_dep() {
		return downstream_dep;
	}

	public void setDownstream_dep(String downstream_dep) {
		this.downstream_dep = downstream_dep;
	}

	public String getImpact() {
		return impact;
	}

	public void setImpact(String impact) {
		this.impact = impact;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
