package com.uob.dashb.framework.database.entity;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "job_log")
public class JobLog {
	
	@Id
	@Column(name = "job_log_id", updatable=false)
	private int job_log_id;
	
	@Basic
    @Column(name = "job_id")
	private int job_id;
	
	@Basic
    @Column(name = "job_tracker_id")
	private int job_tracker_id;
	
	@Basic
    @Column(name = "app_id")
	private String app_id;
	
	@Basic
    @Column(name = "data_center")
	private String data_center;
	
	@Basic
    @Column(name = "job_table")
	private String job_table;
	
	@Basic
    @Column(name = "job_name")
	private String job_name;
	
	@Basic
    @Column(name = "job_application")
	private String job_application;
	
	@Basic
    @Column(name = "job_group")
	private String job_group;
	
	@Basic
    @Column(name = "job_owner")
	private String job_owner;
	
	@Basic
    @Column(name = "node_id")
	private String node_id;
	
	@Basic
    @Column(name = "job_status")
	private String job_status;
	
	@Basic
    @Column(name = "start_time")
	private Timestamp start_time;
	
	@Basic
    @Column(name = "end_time")
	private Timestamp end_time;
	
	@Basic
    @Column(name = "order_date")
	private Timestamp order_date;
	
	@Basic
    @Column(name = "rerun_counter")
	private int rerun_counter;
	
	@Basic
    @Column(name = "run_time_sec")
	private int run_time_sec;
	
	@Basic
    @Column(name = "created_on")
	private Timestamp created_on;
	
	@Basic
    @Column(name = "updated_on")
	private Timestamp updated_on;
	
	@Basic
    @Column(name = "updated_by")
	private String updated_by;
	
	public int getJob_log_id() {
		return job_log_id;
	}

	public void setJob_log_id(int job_log_id) {
		this.job_log_id = job_log_id;
	}

	public int getJob_id() {
		return job_id;
	}

	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getData_center() {
		return data_center;
	}

	public void setData_center(String data_center) {
		this.data_center = data_center;
	}

	public String getJob_table() {
		return job_table;
	}

	public void setJob_table(String job_table) {
		this.job_table = job_table;
	}

	public String getJob_name() {
		return job_name;
	}

	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}

	public String getJob_application() {
		return job_application;
	}

	public void setJob_application(String job_application) {
		this.job_application = job_application;
	}

	public String getJob_group() {
		return job_group;
	}

	public void setJob_group(String job_group) {
		this.job_group = job_group;
	}

	public String getJob_owner() {
		return job_owner;
	}

	public void setJob_owner(String job_owner) {
		this.job_owner = job_owner;
	}

	public String getNode_id() {
		return node_id;
	}

	public void setNode_id(String node_id) {
		this.node_id = node_id;
	}

	public String getJob_status() {
		return job_status;
	}

	public void setJob_status(String job_status) {
		this.job_status = job_status;
	}

	public Timestamp getStart_time() {
		return start_time;
	}

	public void setStart_time(Timestamp start_time) {
		this.start_time = start_time;
	}

	public Timestamp getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Timestamp end_time) {
		this.end_time = end_time;
	}

	public Timestamp getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Timestamp order_date) {
		this.order_date = order_date;
	}

	public int getRerun_counter() {
		return rerun_counter;
	}

	public void setRerun_counter(int rerun_counter) {
		this.rerun_counter = rerun_counter;
	}

	public int getRun_time_sec() {
		return run_time_sec;
	}

	public void setRun_time_sec(int run_time_sec) {
		this.run_time_sec = run_time_sec;
	}

	public int getJob_tracker_id() {
		return job_tracker_id;
	}

	public void setJob_tracker_id(int job_tracker_id) {
		this.job_tracker_id = job_tracker_id;
	}

	public Timestamp getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Timestamp created_on) {
		this.created_on = created_on;
	}

	public Timestamp getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Timestamp updated_on) {
		this.updated_on = updated_on;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}
	
	
}
