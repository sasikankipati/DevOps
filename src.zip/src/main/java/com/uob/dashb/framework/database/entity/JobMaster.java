package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "job_master")
public class JobMaster {
	
	@Id
	@Column(name = "job_master_id", updatable=false)
	 private int job_master_id;
	
	@Basic
    @Column(name = "app_group_id")
	private int app_group_id;
	
	@Basic
    @Column(name = "app_id")
	 private String app_id;
	
	@Basic
    @Column(name = "job_desc")
	 private String job_desc;
	
	@Basic
    @Column(name = "job_name")
	 private String job_name;
	
	@Basic
    @Column(name = "standard_stime")
	 private String standard_stime;
	
	@Basic
    @Column(name = "standard_etime")
	 private String standard_etime;
	
	@Basic
    @Column(name = "drop_dtime")
	 private String drop_dtime;
	
	@Basic
    @Column(name = "frequency")
	 private String frequency;
	
	@Basic
    @Column(name = "day_of_month")
	 private String day_of_month;
	

	public int getJob_master_id() {
		return job_master_id;
	}

	public void setJob_master_id(int job_master_id) {
		this.job_master_id = job_master_id;
	}

	public int getApp_group_id() {
		return app_group_id;
	}

	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getJob_desc() {
		return job_desc;
	}

	public void setJob_desc(String job_desc) {
		this.job_desc = job_desc;
	}

	public String getJob_name() {
		return job_name;
	}

	public void setJob_name(String job_name) {
		this.job_name = job_name;
	}

	public String getStandard_stime() {
		return standard_stime;
	}

	public void setStandard_stime(String standard_stime) {
		this.standard_stime = standard_stime;
	}

	public String getStandard_etime() {
		return standard_etime;
	}

	public void setStandard_etime(String standard_etime) {
		this.standard_etime = standard_etime;
	}

	public String getDrop_dtime() {
		return drop_dtime;
	}

	public void setDrop_dtime(String drop_dtime) {
		this.drop_dtime = drop_dtime;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getDay_of_month() {
		return day_of_month;
	}

	public void setDay_of_month(String day_of_month) {
		this.day_of_month = day_of_month;
	}
	


}
