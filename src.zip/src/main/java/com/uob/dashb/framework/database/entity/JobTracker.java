package com.uob.dashb.framework.database.entity;

import java.sql.Timestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "job_tracker")
public class JobTracker {
	
	@Id
	@Column(name = "job_tracker_id", updatable=false)
	private int job_tracker_id;
	
	@Basic
    @Column(name = "job_id")
	private int job_id;
	
	@Basic
    @Column(name = "order_date")
	private Timestamp order_date;
	
	@Basic
    @Column(name = "created_on")
	private Timestamp created_on;

	public int getJob_tracker_id() {
		return job_tracker_id;
	}

	public void setJob_tracker_id(int job_tracker_id) {
		this.job_tracker_id = job_tracker_id;
	}

	public int getJob_id() {
		return job_id;
	}

	public void setJob_id(int job_id) {
		this.job_id = job_id;
	}

	public Timestamp getOrder_date() {
		return order_date;
	}

	public void setOrder_date(Timestamp order_date) {
		this.order_date = order_date;
	}

	public Timestamp getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Timestamp created_on) {
		this.created_on = created_on;
	}
	
	
	
}
