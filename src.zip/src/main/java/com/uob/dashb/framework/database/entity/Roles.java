package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "roles")
public class Roles {
	
	@Id
	@Column(name = "role_id", updatable=false)
	private int role_id;
	
	@Basic
	@Column(name="role_desc")
	private String role_desc;
	 
	 @Override
	 public String toString() {
	  return "Task [role_id=" + role_id + ", role_desc=" + role_desc +"]";
	 }

	public int getRole_id() {
		return role_id;
	}

	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}

	public String getRole_desc() {
		return role_desc;
	}

	public void setRole_desc(String role_desc) {
		this.role_desc = role_desc;
	}


}
