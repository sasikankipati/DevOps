package com.uob.dashb.framework.database.entity;


import java.sql.Timestamp;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "system_health")
public class SystemHealth {
	
	@Id
	@Column(name = "system_health_id", updatable=false)
	private int system_health_id;
	
	@Basic
	@Column(name="app_id")
	private String app_id;
	
	@Basic
	@Column(name="app_group_id")
	private int app_group_id;
	
	@Basic
	@Column(name="status")
	private String status;
	 
	@Basic
	@Column(name="country")
	private String country;	
	
	@Basic
    @Column(name = "status_on")
	private Timestamp status_on;
	
	@Basic
    @Column(name = "env")
	private String env;
	

	public int getSystem_health_id() {
		return system_health_id;
	}

	public void setSystem_health_id(int system_health_id) {
		this.system_health_id = system_health_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public int getApp_group_id() {
		return app_group_id;
	}

	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Timestamp getStatus_on() {
		return status_on;
	}

	public void setStatus_on(Timestamp status_on) {
		this.status_on = status_on;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}


	
	
}
