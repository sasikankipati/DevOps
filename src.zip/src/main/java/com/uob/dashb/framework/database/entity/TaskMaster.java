package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "task_master")
public class TaskMaster {
	
	@Id
	@Column(name = "task_id", updatable=false)
	private int task_id;
	
	@Basic
	@Column(name="task_desc")
	private String task_desc;
	
	@Basic
	@Column(name="app_group_id")
	private int app_group_id;
	
	@Basic
	@Column(name="status")
	private String status;
	 
	 @Override
	 public String toString() {
	  return "Task [task_id=" + task_id + ", task_desc=" + task_desc
	    + ", app_group_id=" + app_group_id + ", status="
	    + status  +"]";
	 }

	public int getTask_id() {
		return task_id;
	}

	public void setTask_id(int task_id) {
		this.task_id = task_id;
	}

	public String getTask_desc() {
		return task_desc;
	}

	public void setTask_desc(String task_desc) {
		this.task_desc = task_desc;
	}

	public int getApp_group_id() {
		return app_group_id;
	}

	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
		

}
