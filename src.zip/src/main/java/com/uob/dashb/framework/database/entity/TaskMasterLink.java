package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "task_activity_link")
public class TaskMasterLink {
	
	@Id
	@Column(name = "task_activity_id", updatable=false)
	private int task_activity_id;
	
	@Basic
	@Column(name="task_id")
	private int task_id;
	
	@Basic
    @Column(name = "job_master_id")
	private int job_master_id;
	
	@Basic
	@Column(name="activity_id")
	private int activity_id; 
	
	@Basic
	@Column(name="group_id")
	private int group_id;
	
	@Basic
	@Column(name="app_id")
	private String app_id;
	
	@Basic
	@Column(name="start_time")
	private String start_time;
	
	@Basic
	@Column(name="minutes")
	private String minutes;
	
	@Basic
	@Column(name="priority")
	private String priority;
	
	@Basic
	@Column(name="day_of_week")
	private String day_of_week;
	
	@Basic
	@Column(name="activitygroup")
	private int activitygroup;
	 
	 @Override
	 public String toString() {
	  return "Task [task_activity_id=" + task_activity_id + ", task_id=" + task_id
	    + ", activity_id=" + activity_id + ", app_id="
	    + app_id +",start_time="+start_time+",minutes="+minutes
	    +",priority="+priority+",day_of_week="+day_of_week +"]";
	 }

	public int getTask_activity_id() {
		return task_activity_id;
	}

	public void setTask_activity_id(int task_activity_id) {
		this.task_activity_id = task_activity_id;
	}

	public int getTask_id() {
		return task_id;
	}

	public void setTask_id(int task_id) {
		this.task_id = task_id;
	}

	public int getActivity_id() {
		return activity_id;
	}

	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getMinutes() {
		return minutes;
	}

	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getDay_of_week() {
		return day_of_week;
	}

	public void setDay_of_week(String day_of_week) {
		this.day_of_week = day_of_week;
	}

	public int getActivitygroup() {
		return activitygroup;
	}

	public void setActivitygroup(int activitygroup) {
		this.activitygroup = activitygroup;
	}

	public int getGroup_id() {
		return group_id;
	}

	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}

	public int getJob_master_id() {
		return job_master_id;
	}

	public void setJob_master_id(int job_master_id) {
		this.job_master_id = job_master_id;
	}
		

}
