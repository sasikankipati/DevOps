package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "test_case")
public class TestCase {
	
	@Id
	@Column(name = "test_case_id", updatable=false)
	private int test_case_id;
	
	@Basic
    @Column(name = "case_id")
	private String case_id;
	
	@Basic
	@Column(name="case_desc")
	private String case_desc;
	
	@Basic
	@Column(name="rec_status")
	private String rec_status;

	@Basic
	@Column(name="severity")
	private String severity;

	@Basic
	@Column(name="remarks")
	private String remarks;

	public int getTest_case_id() {
		return test_case_id;
	}

	public void setTest_case_id(int test_case_id) {
		this.test_case_id = test_case_id;
	}

	public String getCase_id() {
		return case_id;
	}

	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}

	public String getCase_desc() {
		return case_desc;
	}

	public void setCase_desc(String case_desc) {
		this.case_desc = case_desc;
	}

	public String getRec_status() {
		return rec_status;
	}

	public void setRec_status(String rec_status) {
		this.rec_status = rec_status;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
