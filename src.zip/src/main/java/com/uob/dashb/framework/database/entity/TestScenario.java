package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "test_scenario")
public class TestScenario {
	
	@Id
	@Column(name = "test_scenario_id", updatable=false)
	private int test_scenario_id;
	
	@Basic
    @Column(name = "scenario_id")
	private String scenario_id;
	
	@Basic
	@Column(name="scenario_desc")
	private String scenario_desc;
	
	@Basic
	@Column(name="case_id")
	private String case_id;

	@Basic
	@Column(name="env_id")
	private String env_id;

	@Basic
	@Column(name="app_id")
	private String app_id;

	public int getTest_scenario_id() {
		return test_scenario_id;
	}

	public void setTest_scenario_id(int test_scenario_id) {
		this.test_scenario_id = test_scenario_id;
	}

	public String getScenario_id() {
		return scenario_id;
	}

	public void setScenario_id(String scenario_id) {
		this.scenario_id = scenario_id;
	}

	public String getScenario_desc() {
		return scenario_desc;
	}

	public void setScenario_desc(String scenario_desc) {
		this.scenario_desc = scenario_desc;
	}

	public String getCase_id() {
		return case_id;
	}

	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}

	public String getEnv_id() {
		return env_id;
	}

	public void setEnv_id(String env_id) {
		this.env_id = env_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

}
