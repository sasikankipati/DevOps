package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "test_status")
public class TestStatus {
	
	@Id
	@Column(name = "test_status_id", updatable=false)
	private int test_status_id;
	
	@Basic
    @Column(name = "scenario_id")
	private String scenario_id;
	
	@Basic
	@Column(name="case_id")
	private String case_id;
	
	@Basic
	@Column(name="status")
	private String status;

	@Basic
	@Column(name="exec_date")
	private String exec_date;

	@Basic
	@Column(name="exec_time")
	private String exec_time;

	public int getTest_status_id() {
		return test_status_id;
	}

	public void setTest_status_id(int test_status_id) {
		this.test_status_id = test_status_id;
	}

	public String getScenario_id() {
		return scenario_id;
	}

	public void setScenario_id(String scenario_id) {
		this.scenario_id = scenario_id;
	}

	public String getCase_id() {
		return case_id;
	}

	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getExec_date() {
		return exec_date;
	}

	public void setExec_date(String exec_date) {
		this.exec_date = exec_date;
	}

	public String getExec_time() {
		return exec_time;
	}

	public void setExec_time(String exec_time) {
		this.exec_time = exec_time;
	}

}
