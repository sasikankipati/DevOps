package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "test_tracker")
public class TestTracker {
	
	@Id
	@Column(name = "test_tracker_id", updatable=false)
	private int test_tracker_id;
	
	@Basic
    @Column(name = "scenario_id")
	private String scenario_id;
	
	@Basic
	@Column(name="exec_date")
	private String exec_date;

	@Basic
	@Column(name="exec_time")
	private String exec_time;

	public int getTest_tracker_id() {
		return test_tracker_id;
	}

	public void setTest_tracker_id(int test_tracker_id) {
		this.test_tracker_id = test_tracker_id;
	}

	public String getScenario_id() {
		return scenario_id;
	}

	public void setScenario_id(String scenario_id) {
		this.scenario_id = scenario_id;
	}

	public String getExec_date() {
		return exec_date;
	}

	public void setExec_date(String exec_date) {
		this.exec_date = exec_date;
	}

	public String getExec_time() {
		return exec_time;
	}

	public void setExec_time(String exec_time) {
		this.exec_time = exec_time;
	}


}
