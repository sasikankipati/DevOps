package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_application_group")
public class UserApplicationGroup {
	
	@Id
	@Column(name = "user_app_group_id", updatable=false)
	private int user_app_group_id;
	
	
	@Basic
	@Column(name = "app_group_id")
	private int app_group_id;
	
	
	@Basic
	@Column(name="user_id")
	private int user_id;
	 
	 @Override
	 public String toString() {
	  return "Task [app_group_id=" + app_group_id + ", user_id=" + user_id +"]";
	 }


	public int getApp_group_id() {
		return app_group_id;
	}


	public void setApp_group_id(int app_group_id) {
		this.app_group_id = app_group_id;
	}


	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}


	public int getUser_app_group_id() {
		return user_app_group_id;
	}


	public void setUser_app_group_id(int user_app_group_id) {
		this.user_app_group_id = user_app_group_id;
	}



}
