package com.uob.dashb.framework.database.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "user_profile")
public class UserProfile {
	
	@Id
	@Column(name = "user_id", updatable=false)
	private int user_id;
	
	@Basic
	@Column(name = "user_name")
	private String user_name;
	
	@Basic
	@Column(name = "password")
	private String password;
	
	@Basic
	@Column(name = "status")
	private String status;
	
	@Basic
	@Column(name = "email")
	private String email;
	
	@Basic
	@Column(name = "lanid")
	private String lanid;
	
	@Basic
	@Column(name = "phone")
	private String phone;
	
	@Basic
	@Column(name = "adminflag")
	private String adminflag;
	 
	 @Override
	 public String toString() {
	  return "Task [user_id=" + user_id + ", user_name=" + user_name
	    + ", password=" + password + ", status="
	    + status +",email="+email+",lanid="+lanid
	    +",phone="+phone +"]";
	 }

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLanid() {
		return lanid;
	}

	public void setLanid(String lanid) {
		this.lanid = lanid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAdminflag() {
		return adminflag;
	}

	public void setAdminflag(String adminflag) {
		this.adminflag = adminflag;
	}



}
