package com.uob.dashb.framework.database.utility;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class PersistenceManager {
    private EntityManagerFactory entityManagerFactory;
    private EntityManager em;

    public PersistenceManager(){
        entityManagerFactory = Persistence.createEntityManagerFactory("pssdash");
        em = entityManagerFactory.createEntityManager();
    }

    public EntityManager getEm(){
        return em;
    }

}
