package com.uob.dashb.framework.validator.core;

import java.util.ArrayList;




/*import com.uob.pib.framework.base.PIBBaseForm;
import com.uob.pib.framework.constant.FrameworkConstants;
import com.uob.pib.framework.constant.DashBErrorConstants;
import com.uob.pib.framework.exception.DashBError;
import com.uob.pib.framework.exception.DashBErrors;
import com.uob.pib.framework.logging.LogUtil;
import com.uob.pib.framework.validator.util.core.FormData;
import com.uob.pib.framework.validator.util.core.VOData;*/

public class ServerValidator {
	
	/**
	 * The method validates a BaseForm
	 * 
	 * @param BaseForm -
	 *			the BaseForm tobe validated, String - name of the form bean
	 * @return void
	 * @exception IllegalAccessException,
	 *				InvocationTargetException
	 */
	/*public static DashBErrors validate(PIBBaseForm bForm, String formBeanName, String methodName) 
											throws SecurityException, IllegalAccessException, 
											InvocationTargetException, NoSuchMethodException 
	{	
		LogUtil.performApplicationLogging("ServerValidator", null, null, "Start  validate method, formBeanName :" + formBeanName, FrameworkConstants.DEBUG);
		DashBErrors objMHolder = new DashBErrors();
		FormData form = PIBValidatorPlugin.getFormData(formBeanName);
		if(form == null){
			*//** in case if the passed in form bean name not found in XML, throw system exception *//*
			LogUtil.performApplicationLogging("ServerValidator",null, null, "validate method, Form Bean Name :"+ formBeanName, FrameworkConstants.DEBUG);			
			LogUtil.performBMCLogging("ServerValidator", null, null, "validate method, Form Bean Name :"+ formBeanName, FrameworkConstants.DEBUG);			
			throw new PIBSystemException("Form name not present in xml");
		}
		setMethodName(bForm, methodName);
		ArrayList voList = form.getVOList(); 
		for (int k = 0; k < voList.size(); k++) {
			VOData voData = (VOData)voList.get(k);
			String voName = voData.getName();
			LogUtil.performApplicationLogging("ServerValidator",null, null, "validate method, voList voName :"+ voName, FrameworkConstants.DEBUG);
			Object val = PropertyUtils.getProperty(bForm, voName);
			if (val == null) {
				LogUtil.performApplicationLogging("ServerValidator",null, null, "validate method, Incorrect configuration in XML file, The attribute : " + voName +" in the XML file does not exist in the form bean", FrameworkConstants.DEBUG);
				throw new PIBSystemException("Incorrect configuration in XML file. The attribute: " + voName +" in the XML file does not exist in the form bean:"+ formBeanName);
			}			
			if (val instanceof ArrayList) {
				ArrayList aList = (ArrayList)val; 
				for(int ctr = 0; ctr < aList.size(); ctr++){
					Validator.getInstance().validateVO(bForm, aList.get(ctr), voData, objMHolder, ctr, voName + "[" + ctr + "]",null);
				}
			} 
			else {
				Validator.getInstance().validateVO(bForm, val, voData, objMHolder, -1, voName,null);
			}
		}
		LogUtil.performApplicationLogging("ServerValidator", null, null, "validate method, Message Holder size:"+ objMHolder.size(), FrameworkConstants.DEBUG);
		if("confirm".equalsIgnoreCase(methodName)){
			if(objMHolder != null && objMHolder.size() > 0){
				throw new SecurityException("Security Exception occurs while validating confirm action");
			}
		}
		if(objMHolder != null && objMHolder.size() > 0){
			DashBError DashBError = objMHolder.getDashBErrorsHolder().get(0);
			DashBError.setErrorCode(DashBErrorConstants.COMMON_FIELD_VALIDATION_FAILED);
		}
		LogUtil.performApplicationLogging("ServerValidator", null, null, "End validate method, objMHolder size:" + formBeanName, FrameworkConstants.DEBUG);
		return objMHolder;
	}
	*/
	/*public static DashBErrors validate(String formBeanName, String methodName,Object appVO) throws Exception {
		
		FormData form = PIBValidatorPlugin.getFormData(formBeanName);
		if(form == null){
			*//** in case if the passed in form bean name not found in XML, throw system exception *//*
			throw new Exception("Form name not present in xml");
		}
		setMethodName(bForm, methodName);
		ArrayList voList = form.getVOList(); 
		for (int k = 0; k < voList.size(); k++) {
			VOData voData = (VOData)voList.get(k);
			String voName = voData.getName();
			Object val = PropertyUtils.getProperty(bForm, voName);
			if (val == null) {
				throw new Exception("Incorrect configuration in XML file. The attribute: " + voName +" in the XML file does not exist in the form bean:"+ formBeanName);
			}			
			if (val instanceof ArrayList) {
				ArrayList aList = (ArrayList)val; 
				for(int ctr = 0; ctr < aList.size(); ctr++){
					Validator.getInstance().validateVO(bForm, aList.get(ctr), voData, objMHolder, ctr, voName + "[" + ctr + "]",appVO);
				}
			} 
			else {
				Validator.getInstance().validateVO(bForm, val, voData, objMHolder, -1, voName,appVO);
			}
		}
		if("confirm".equalsIgnoreCase(methodName)){
			if(objMHolder != null && objMHolder.size() > 0){
				throw new SecurityException("Security Exception occurs while validating confirm action");
			}
		}
		return objMHolder;
	}
	
	
	// for account auth
	private static void setMethodName(PIBBaseForm bForm, String methodName) {
			bForm.setMethodName(methodName);
		}*/
}
