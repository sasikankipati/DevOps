package com.uob.dashb.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.uob.dashb.framework.database.entity.ActivityMaster;
import com.uob.dashb.framework.database.entity.Application;
import com.uob.dashb.framework.database.entity.TaskMasterLink;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TaskDetailVO;
import com.uob.dashb.vo.User;


public interface ActivityHistoryService {

	
	public HashMap<String, String> getConsolidateList(int userId);
	public ArrayList<UserApplicationGroup> getGroupIdsOfUser(int userId);
	public ArrayList<Application> getAppofGroup(List<Integer> groupList);
	public ArrayList<TaskMasterLink> getScheduledActivities(List<Integer> appList);
	
	public ArrayList<ActivityVO> listActivities(int userId);
	public ArrayList<TaskDetailVO> listTasks(String groupId);
	ActivityMaster findActivity(ActivityVO objActivityVO);
	boolean saveActivity(ActivityMaster objActivityMaster);
	boolean saveTaskMasterLink(TaskMasterLink objTaskMasterLink);
	public CommonVO viewSelectedActivity(ActivityVO objActivityVO,String userId);
	void deleteActivityGroup(String activityGroup);
}
