package com.uob.dashb.service;

import java.util.ArrayList;
import java.util.List;

import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.ApplicationVO;


public interface ApplicationService {

	public ArrayList<ApplicationGroup> fetchAllAppGroups();
	public ArrayList<ApplicationVO> fetchAllApplications();
	public ApplicationGroup viewAppGroup(String group_id);
	public boolean save(ApplicationGroup objApplicationGroup);
	public boolean saveApplication(ApplicationVO objApplicationVO);
	public boolean update(ApplicationGroupVO objApplicationGroupVO);
	public ApplicationVO viewApplication(String appId);
	public boolean updateApplication(ApplicationVO objApplicationVO);
	public boolean saveUserAppGroup(UserApplicationGroup objUserApplicationGroup);
	public ArrayList<UserApplicationGroup> fetchUserAppGroups(String userId);
	public void updateUserAppGroup(List<String> lsAppGroupIds, String userId);
	public ArrayList<ApplicationGroupVO> fetchAllGroups();	
}
