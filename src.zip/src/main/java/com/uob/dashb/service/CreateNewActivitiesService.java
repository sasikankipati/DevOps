package com.uob.dashb.service;



public interface CreateNewActivitiesService {

	boolean createNewActivities();

}
