package com.uob.dashb.service;



public interface CtrlMJobStatusService {

	boolean fetchJobsFromCtrlM();

}
