package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.vo.EnvironmentVO;


public interface EnvironmentService {

	public ArrayList<EnvironmentVO> fetchAllList();

	public boolean saveEnvironment(EnvironmentVO objEnvironmentVO);

	public EnvironmentVO viewEnvironment(EnvironmentVO objEnvironmentVO);

	public boolean updateEnvironment(EnvironmentVO objEnvironmentVO);

	public boolean deleteEnvironment(EnvironmentVO objEnvironmentVO);

	public boolean duplicateCheck(EnvironmentVO objEnvironmentVO);
	
}
