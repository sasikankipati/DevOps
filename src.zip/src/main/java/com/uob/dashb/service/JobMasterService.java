package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.JobLog;
import com.uob.dashb.framework.database.entity.JobTracker;
import com.uob.dashb.vo.JobDependencyVO;
import com.uob.dashb.vo.JobVO;


public interface JobMasterService {

	public ArrayList<JobVO> fetchAllJobs(String userId);
	public ArrayList<JobDependencyVO> fetchDependencies(String jobMasterId);
	ArrayList<JobVO> fetchJobsfullList();
	public void saveJobLog(JobLog objJobLog);
	public ArrayList<JobVO> fetchJobLogs();
	public JobTracker getJobTracker(Integer valueOf);
	public void updateJobTracker(JobTracker objJobTracker);
	void saveJobTracker(JobTracker objJobTracker);
}
