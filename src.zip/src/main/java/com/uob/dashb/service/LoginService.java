package com.uob.dashb.service;

import java.util.ArrayList;
import java.util.List;

import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.vo.UserRolesVO;
import com.uob.dashb.vo.UserVO;


public interface LoginService {

	public List<UserProfile> getAll();
	public UserProfile getUser(String userId);
	public UserProfile authenticateUser(String userId,String password);
	public UserVO getUserRole(Integer userId);
	public ArrayList<UserVO> fetchAllUsers();
	public UserProfile save(UserProfile objUserProfile);
	public UserProfile fetchUserByLanId(String lanid);
	public UserProfile updateUser(UserVO objUserVO);
	public ArrayList<UserRolesVO> fetchAllRoles();
	public void insertUserRole(int user_id, String role);
	public void updateUserRole(int user_id, String role);
	UserProfile updatePassword(UserVO objUserVO);
}
