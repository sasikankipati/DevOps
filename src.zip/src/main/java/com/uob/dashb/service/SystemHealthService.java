package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.vo.SystemHealthChkVO;


public interface SystemHealthService {


	String save(SystemHealthChkVO objSystemHealthChkVO);

	ArrayList<SystemHealthChkVO> fetchAppLevelHealthCheck();

	ArrayList<SystemHealthChkVO> fetchEnvLevelHealthCheck(String appId);

	ArrayList<SystemHealthChkVO> fetchTSLevelHealthCheck(String appId,String country);

}
