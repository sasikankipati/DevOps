package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.framework.database.entity.TaskMaster;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TaskDetailVO;


public interface TasksService {

	public ArrayList<TaskDetailVO> fetchAllTasks();

	boolean save(TaskMaster objTaskMaster);

	public ArrayList<ActivityVO> fetchPendingTasks(String userId,int count);
	
	public CommonVO viewSelectedTxn(ActivityVO objActivityVO,String userId);

	public boolean updateActTxn(ActivityVO objActivityVO,int userId);

	public TaskDetailVO viewSelectedTask(String taskId);

	public boolean deleteTask(TaskDetailVO objTaskDetailVO);

	public boolean updateTask(TaskDetailVO objTaskDetailVO);

	public String getEmailDistribution(String groupId);
}
