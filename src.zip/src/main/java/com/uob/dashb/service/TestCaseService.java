package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TestCaseVO;
import com.uob.dashb.vo.TestScenarioVO;


public interface TestCaseService {

	public ArrayList<TestCaseVO> fetchAllTestCases();

	public boolean saveTestCase(TestCaseVO objTestCaseVO);

	public boolean deleteTestCase(TestCaseVO objTestCaseVO);

	public TestCaseVO viewTestCase(TestCaseVO objTestCaseVO);

	public boolean updateTestCase(TestCaseVO objTestCaseVO);

	public boolean duplicateCheck(TestCaseVO objTestCaseVO);

}
