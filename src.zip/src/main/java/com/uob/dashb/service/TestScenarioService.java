package com.uob.dashb.service;

import java.util.ArrayList;

import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TestScenarioVO;

public interface TestScenarioService {

	public ArrayList<TestScenarioVO> fetchAllList();

	public boolean saveTestScenario(TestScenarioVO objTestScenarioVO);

	public CommonVO viewTestScenario(TestScenarioVO objTestScenarioVO);

	public boolean updateTestScenario(TestScenarioVO objTestScenarioVO);

	public boolean deleteTestScenario(TestScenarioVO objTestScenarioVO);

	public CommonVO copyTestScenario(TestScenarioVO objTestScenarioVO);

	public boolean duplicateCheck(TestScenarioVO objTestScenarioVO);

}
