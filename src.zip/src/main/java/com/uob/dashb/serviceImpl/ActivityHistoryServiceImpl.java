package com.uob.dashb.serviceImpl;


import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.framework.database.entity.ActivityMaster;
import com.uob.dashb.framework.database.entity.Application;
import com.uob.dashb.framework.database.entity.TaskMaster;
import com.uob.dashb.framework.database.entity.TaskMasterLink;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.service.ActivityHistoryService;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.JobVO;
import com.uob.dashb.vo.TaskDetailVO;



@Service("ActivityHistoryService")
public class ActivityHistoryServiceImpl implements ActivityHistoryService {

	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional(readOnly = true)
	public UserProfile getById(int id) {
		return entityManager.find(UserProfile.class, id);
	}
	
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<UserProfile> getAll() {
		Query query = entityManager.createQuery("SELECT p FROM UserProfile p");
		List<UserProfile> items = null;
		items = query.getResultList();
		return items;
	}

	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public UserProfile findUser(String userName) {
		UserProfile result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserProfile p where p.user_id=:userId");
		queryFindItems.setParameter("userId", userName);
		List<UserProfile> userProfileList = queryFindItems.getResultList();
		if(userProfileList.size() > 0) {
			result = userProfileList.get(0);
		}
		return result;
	}

	@Override
	@Transactional(readOnly=true, propagation=Propagation.REQUIRED)
	public ActivityMaster findActivity(ActivityVO objActivityVO) {
		ActivityMaster objActivityMaster=null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM ActivityMaster p where p.activity_desc=:activity_desc");
		queryFindItems.setParameter("activity_desc", objActivityVO.getActivityDesc());
		ArrayList<ActivityMaster> arlActivityMaster = (ArrayList<ActivityMaster>) queryFindItems.getResultList();
		if(null != arlActivityMaster && arlActivityMaster.size() == 1){
			objActivityMaster = arlActivityMaster.get(0);
		}
		return objActivityMaster;
	}

	
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveTaskMasterLink(TaskMasterLink objTaskMasterLink) {
		entityManager.persist(objTaskMasterLink);
		entityManager.flush();
		return true;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveActivity(ActivityMaster objActivityMaster) {
		entityManager.persist(objActivityMaster);
		entityManager.flush();
		return true;
	}

	@Override
	public HashMap<String, String> getConsolidateList(int userId) {
		
		HashMap<String, String> hmConsol = new HashMap<String, String>();
		Query applGroup = entityManager.createQuery("SELECT p FROM UserApplicationGroup p where p.user_id=:userId");
		ArrayList<UserApplicationGroup> arlUserApplicationGroup = null;
		applGroup.setParameter("userId", userId);
		arlUserApplicationGroup = (ArrayList<UserApplicationGroup>) applGroup.getResultList();
		
		hmConsol.put("TEST", "TEST");
		
		return hmConsol;
	}
	
	
	
	
	@Override
	public ArrayList<UserApplicationGroup> getGroupIdsOfUser(int userId) {
		Query applGroup = entityManager.createQuery("SELECT p FROM UserApplicationGroup p where p.user_id=:userId");
		ArrayList<UserApplicationGroup> arlUserApplicationGroup = null;
		applGroup.setParameter("userId", userId);
		arlUserApplicationGroup = (ArrayList<UserApplicationGroup>) applGroup.getResultList();
		return arlUserApplicationGroup;
	}

	@Override
	public ArrayList<Application> getAppofGroup(List<Integer> groupList) {
		Query applGroup = entityManager.createQuery("SELECT p FROM Application p where app_group_id IN ( :groupList )");
		ArrayList<Application> arlApplications = null;
		applGroup.setParameter("groupList", groupList);
		arlApplications = (ArrayList<Application>) applGroup.getResultList();
		return arlApplications;
	}

	@Override
	public ArrayList<TaskMasterLink> getScheduledActivities(List<Integer> appList) {
		Query applGroup = entityManager.createQuery("SELECT p FROM TaskMasterLink p where app_id IN ( :appList )");
		ArrayList<TaskMasterLink> arlApplications = null;
		applGroup.setParameter("appList", appList);
		arlApplications = (ArrayList<TaskMasterLink>) applGroup.getResultList();
		return arlApplications;
	}

	@Override
	public ArrayList<ActivityVO> listActivities(int userId) {
		String query = "select appgroup.app_group_name,appgroup.app_group_id , app.app_id , app.app_desc , actlink.activitygroup ,actlink.start_time, actMas.activity_id , actMas.activity_desc "
				+"from application_group appgroup , user_application_group userappgroup , application app , task_activity_link actlink  , activity_master actMas "
				+"where userappgroup.user_id=:userId and userappgroup.app_group_id = appgroup.app_group_id  and appgroup.app_group_id = app.app_group_id and "
				+"app.app_id = actlink.app_id and actMas.activity_id = actlink.activity_id group by appgroup.app_group_name,appgroup.app_group_id , app.app_id,"
				+" app.app_desc , actlink.activitygroup ,actlink.start_time, actMas.activity_id , actMas.activity_desc";
		
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("userId",userId);
		
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<ActivityVO> arlActivityVO = new ArrayList<ActivityVO>();
		ActivityVO objActivityVO;
		for(Object[] obj:arlResult){
			 
			objActivityVO = new ActivityVO();
			objActivityVO.setActivityGroup(String.valueOf(((BigDecimal)obj[4]).intValue()));
			objActivityVO.setActivityDesc((String)obj[7]);
			objActivityVO.setActivityId(String.valueOf(((BigDecimal)obj[6]).intValue()));
			objActivityVO.setAppName((String)obj[3]);
			objActivityVO.setScheduleAt((String)obj[5]);
			arlActivityVO.add(objActivityVO);
		}
		
		return arlActivityVO;
	}

	@Override
	public ArrayList<TaskDetailVO> listTasks(String groupId) {
		String query = "select appGroup.app_group_name,appGroup.app_group_id,tm.task_id,tm.task_desc from task_master tm,application_group appGroup "
						+"where appGroup.app_group_id = tm.app_group_id and tm.app_group_id=:app_group_id";
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("app_group_id", Integer.valueOf(groupId));
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<TaskDetailVO> arlTaskDetailVO = new ArrayList<TaskDetailVO>();
		TaskDetailVO objTaskDetailVO;
		
		for(Object[] obj:arlResult){
			objTaskDetailVO = new TaskDetailVO();
			objTaskDetailVO.setGroupDesc((String)obj[0]);
			objTaskDetailVO.setGroupId(String.valueOf(((BigDecimal)obj[1]).intValue()));
			objTaskDetailVO.setTaskId(String.valueOf(((BigDecimal)obj[2]).intValue()));
			objTaskDetailVO.setTaskDesc((String)obj[3]);
			arlTaskDetailVO.add(objTaskDetailVO);
		}
		
		return arlTaskDetailVO;
	}

	
	private ArrayList<JobVO> fetchAllJobs(String userId) {
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		JobVO objJobVO;
		
		String query = "select appgroup.app_group_name,appgroup.app_group_id,jobmaster.job_master_id,jobmaster.job_name,jobmaster.job_desc,jobmaster.standard_stime,jobmaster.standard_etime "
				+"from application_group appgroup , job_master jobmaster , user_profile usr, user_application_group userappgroup "
				+"where userappgroup.user_id=usr.user_id and usr.user_id=:userId and userappgroup.app_group_id = appgroup.app_group_id  and "
				+"appgroup.app_group_id=jobmaster.app_group_id ";
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("userId",userId);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		
		for(Object[] obj:arlResult){
			objJobVO = new JobVO();
			objJobVO.setGroupName((String)obj[0]);
			objJobVO.setJobName((String)obj[3]);
			objJobVO.setJobDesc((String)obj[4]);
			objJobVO.setStandardStartTime((String)obj[5]);
			objJobVO.setStandardEndTime((String)obj[6]);
			objJobVO.setJobMasterId(String.valueOf(((BigDecimal)obj[2]).intValue()));
			arlJobs.add(objJobVO);
		}
		return arlJobs;
	}
	
	@Override
	@Transactional(readOnly=true, propagation=Propagation.REQUIRED)
	public CommonVO viewSelectedActivity(ActivityVO objActivityVO,String userId) {
		CommonVO objCommonVO = new CommonVO();
		
		Query applGroup = entityManager.createQuery("SELECT p FROM TaskMasterLink p where p.activitygroup=:activitygroup");
		applGroup.setParameter("activitygroup", Integer.valueOf(objActivityVO.getActivityGroup()));
		ArrayList<TaskMasterLink> arlTaskMasterLink = (ArrayList<TaskMasterLink>) applGroup.getResultList();
		
		ArrayList<JobVO> arlJobs = fetchAllJobs(userId);
		
		objActivityVO.setTaskChecked(false);
		objActivityVO.setJobChecked(false);
		
		for(TaskMasterLink objTaskMasterLink: arlTaskMasterLink){
			for(JobVO objJobVO: arlJobs){
				if(String.valueOf(objTaskMasterLink.getJob_master_id()).equalsIgnoreCase(objJobVO.getJobMasterId())){
					objJobVO.setChecked(true);
				}
			}
			if(objTaskMasterLink.getTask_id() != 0){
				objActivityVO.setTaskChecked(true);
			}
			if(objTaskMasterLink.getJob_master_id() != 0){
				objActivityVO.setJobChecked(true);
			}
		}
		
		ActivityMaster objActivityMaster=null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM ActivityMaster p where p.activity_id=:activity_id");
		queryFindItems.setParameter("activity_id", arlTaskMasterLink.get(0).getActivity_id());
		ArrayList<ActivityMaster> arlActivityMaster = (ArrayList<ActivityMaster>) queryFindItems.getResultList();
		if(null != arlActivityMaster && arlActivityMaster.size() == 1){
			objActivityMaster = arlActivityMaster.get(0);
		}
		
		ArrayList<Integer> arlTaskIds = new ArrayList<Integer>();
		for(TaskMasterLink objTaskMasterLink: arlTaskMasterLink){
			arlTaskIds.add(objTaskMasterLink.getTask_id());
		}
		
		ArrayList<TaskMaster> arlTaskMaster =new ArrayList<TaskMaster>();
		
		if(arlTaskIds.size() > 0){
			Query queryFindTasks = entityManager.createQuery("SELECT p FROM TaskMaster p where p.task_id in (:task_id)");
			queryFindTasks.setParameter("task_id", arlTaskIds);
			arlTaskMaster = (ArrayList<TaskMaster>) queryFindTasks.getResultList();
		}
		
		
		
		ArrayList<TaskDetailVO> arlAllTaskDetailVO = listTasks(String.valueOf(arlTaskMasterLink.get(0).getGroup_id()));
		
		for(TaskDetailVO objTaskDetailVO:arlAllTaskDetailVO){
			for(TaskMaster objTaskMaster:arlTaskMaster){
				if(objTaskDetailVO.getTaskId().equalsIgnoreCase(String.valueOf(objTaskMaster.getTask_id()))){
					objTaskDetailVO.setChecked(true);
				}
			}
		}
		
		for(TaskDetailVO objTaskDetailVO:arlAllTaskDetailVO){
			for(TaskMasterLink objTaskMasterLink:arlTaskMasterLink){
				if(objTaskDetailVO.getTaskId().equalsIgnoreCase(String.valueOf(objTaskMasterLink.getTask_id()))){
					objTaskDetailVO.setTaskActivityId(String.valueOf(objTaskMasterLink.getTask_activity_id()));
				}
			}
		}
		
		objActivityVO.setActivityId(String.valueOf(objActivityMaster.getActivity_id()));
		objActivityVO.setActivityDesc(objActivityMaster.getActivity_desc());
		objActivityVO.setGroupId(String.valueOf(arlTaskMasterLink.get(0).getGroup_id()));
		objActivityVO.setAppId(String.valueOf(arlTaskMasterLink.get(0).getApp_id()));
		objActivityVO.setScheduleAt(arlTaskMasterLink.get(0).getStart_time());
		objActivityVO.setGivenTime(arlTaskMasterLink.get(0).getMinutes());
		objActivityVO.setPriority(arlTaskMasterLink.get(0).getPriority());
		objActivityVO.setDaysOfWeek(arlTaskMasterLink.get(0).getDay_of_week());
		objActivityVO.setEnvironment(objActivityMaster.getEnvironment());
		objActivityVO.setActivityGroup(String.valueOf(arlTaskMasterLink.get(0).getActivitygroup()));
		
		objCommonVO.setArlTaskDetailVO(arlAllTaskDetailVO);
		objCommonVO.setArlJobs(arlJobs);
		objCommonVO.setObjActivityVO(objActivityVO);
		 
		return objCommonVO;
	}

	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void deleteActivityGroup(String activityGroup) {
		Query applGroup = entityManager.createQuery("SELECT p FROM TaskMasterLink p where p.activitygroup=:activitygroup");
		applGroup.setParameter("activitygroup", Integer.valueOf(activityGroup));
		ArrayList<TaskMasterLink> arlTaskMasterLink = (ArrayList<TaskMasterLink>) applGroup.getResultList();
		
		for(TaskMasterLink objTaskMasterLink:arlTaskMasterLink){
			deleteTaskMasterLink(objTaskMasterLink);
		}
	}

	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	private void deleteTaskMasterLink(TaskMasterLink objTaskMasterLink){
		entityManager.remove(entityManager.getReference(TaskMasterLink.class, objTaskMasterLink.getTask_activity_id()));
		entityManager.flush();
	}
	
}