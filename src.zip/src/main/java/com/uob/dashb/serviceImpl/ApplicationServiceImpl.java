package com.uob.dashb.serviceImpl;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.framework.database.entity.Application;
import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.UserApplicationGroup;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.vo.ApplicationGroupVO;
import com.uob.dashb.vo.ApplicationVO;



@Service("ApplicationService")
public class ApplicationServiceImpl implements ApplicationService {

	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional(readOnly = true)
	public ApplicationGroup getById(int id) {
		return entityManager.find(ApplicationGroup.class, id);
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean save(ApplicationGroup objApplicationGroup) {
		entityManager.persist(objApplicationGroup);
		entityManager.flush();
		return true;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveUserAppGroup(UserApplicationGroup objUserApplicationGroup) {
		entityManager.persist(objUserApplicationGroup);
		entityManager.flush();
		return true;
	}
	
	@Override
	public ArrayList<ApplicationGroup> fetchAllAppGroups() {
		Query query = entityManager.createQuery("SELECT p FROM ApplicationGroup p");
		return (ArrayList<ApplicationGroup>) query.getResultList();
	}

	@Override
	public ArrayList<ApplicationVO> fetchAllApplications() {
		ArrayList<ApplicationVO> arlApplications = new ArrayList<ApplicationVO>();
		ApplicationVO objApplication;
		
		String query = "select appGroup.app_group_owner,app.app_id,app.app_desc,app.ascc_app_code,app.display_order,usrp.user_name,appGroup.app_group_name,appGroup.app_group_id "
				+"from application app,application_group appGroup,user_profile usrp "
				+"where usrp.user_id = app.app_owner and app.app_group_id = appGroup.app_group_id";
		Query activityList = entityManager.createNativeQuery(query);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		for(Object[] obj:arlResult){
			objApplication = new ApplicationVO();
			objApplication.setAppDesc((String)obj[2]);
			objApplication.setAppId((String)obj[1]);
			objApplication.setAppOwner((String)obj[5]);
			objApplication.setAsccAppCode((String)obj[3]);
			objApplication.setDisplayOrder((String)obj[4]);
			objApplication.setGroup((String)obj[6]);
			objApplication.setAppGroupId(String.valueOf(((BigDecimal)obj[7]).intValue()));
			arlApplications.add(objApplication);
		}
		
		return arlApplications;
	}

	@Override
	public ApplicationGroup viewAppGroup(String group_id) {
		Query query = entityManager.createQuery("SELECT p FROM ApplicationGroup p where p.app_group_id=:app_group_id");
		query.setParameter("app_group_id", Integer.valueOf(group_id));
		//query.setParameter("app_group_id", group_id);
		return (ApplicationGroup) query.getSingleResult();
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean update(ApplicationGroupVO objApplicationGroupVO) {
		ApplicationGroup objApplicationGroup = entityManager.find(ApplicationGroup.class, Integer.valueOf(objApplicationGroupVO.getGroup_id()));
		objApplicationGroup.setApp_group_name(objApplicationGroupVO.getGroupName());
		objApplicationGroup.setApp_group_owner(objApplicationGroupVO.getGroupOwner());
		objApplicationGroup.setDisplay_order(objApplicationGroupVO.getDisplayOrder());
		objApplicationGroup.setEmail_distribution(objApplicationGroupVO.getEmail());
		//entityManager.persist(objApplicationGroup);
		entityManager.flush();
		return true;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean updateApplication(ApplicationVO objApplicationVO) {
		Application objApplication = entityManager.find(Application.class, objApplicationVO.getAppId());
		objApplication.setApp_desc(objApplicationVO.getAppDesc());
		objApplication.setApp_group_id(Integer.valueOf(objApplicationVO.getAppGroupId()));
		//objApplication.setApp_owner(Integer.valueOf(objApplicationVO.getAppOwnerId()));
		objApplication.setApp_owner(1);
		objApplication.setAscc_app_code(objApplicationVO.getAsccAppCode());
		objApplication.setDisplay_order(objApplicationVO.getDisplayOrder());
		entityManager.flush();
		return true;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean saveApplication(ApplicationVO objApplicationVO) {
		Application objApplication = new Application();
		objApplication.setApp_id(objApplicationVO.getAppId());
		objApplication.setApp_desc(objApplicationVO.getAppDesc());
		objApplication.setApp_group_id(Integer.valueOf(objApplicationVO.getAppGroupId()));
		objApplication.setApp_owner(Integer.valueOf(objApplicationVO.getAppOwnerId()));
		objApplication.setApp_owner(1);
		objApplication.setAscc_app_code(objApplicationVO.getAsccAppCode());
		objApplication.setDisplay_order(objApplicationVO.getDisplayOrder());
		entityManager.persist(objApplication);
		entityManager.flush();
		return true;
	}

	@Override
	public ApplicationVO viewApplication(String app_id) {
		ApplicationVO objApplication = new ApplicationVO();
		try{
			String query = "select appGroup.app_group_owner,app.app_id,app.app_desc,app.ascc_app_code,app.display_order,usr.user_name,appGroup.app_group_name,appGroup.app_group_id,usr.user_id "
					+"from application app,application_group appGroup,user_profile usr "
					+"where usr.user_id = app.app_owner and app.app_group_id = appGroup.app_group_id and app.app_id=:appId";
			Query viewApplication = entityManager.createNativeQuery(query);
			viewApplication.setParameter("appId", app_id);
			ArrayList<Object[]> arlResult = (ArrayList<Object[]>) viewApplication.getResultList();
			Object[] obj  = arlResult.get(0);
			
			objApplication.setAppDesc((String)obj[2]);
			objApplication.setAppId((String)obj[1]);
			objApplication.setAppOwner((String)obj[5]);
			objApplication.setAsccAppCode((String)obj[3]);
			objApplication.setDisplayOrder((String)obj[4]);
			objApplication.setGroup((String)obj[6]);
			objApplication.setAppGroupId(String.valueOf(((BigDecimal)obj[7]).intValue()));
			objApplication.setAppOwnerId(String.valueOf(((BigDecimal)obj[8]).intValue()));
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return objApplication;
	}

	@Override
	public ArrayList<UserApplicationGroup> fetchUserAppGroups(String userId) {
		Query query = entityManager.createQuery("SELECT p FROM UserApplicationGroup p where p.user_id=:user_id");
		query.setParameter("user_id", Integer.valueOf(userId));
		return (ArrayList<UserApplicationGroup>)query.getResultList();
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void updateUserAppGroup(List<String> lsAppGroupIds, String userId) {
		Query query = entityManager.createQuery("SELECT p FROM UserApplicationGroup p where p.user_id=:user_id");
		query.setParameter("user_id", Integer.valueOf(userId));
		ArrayList<UserApplicationGroup> arluserGroup = (ArrayList<UserApplicationGroup>)query.getResultList();
		
		for(UserApplicationGroup objUserApplicationGroup:arluserGroup){
			deleteUserAppGroup1(objUserApplicationGroup);
		}
	}

	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	private void deleteUserAppGroup1(UserApplicationGroup objUserApplicationGroup){
		entityManager.remove(entityManager.getReference(UserApplicationGroup.class, objUserApplicationGroup.getUser_app_group_id()));
		entityManager.flush();
	}

	@Override
	public ArrayList<ApplicationGroupVO> fetchAllGroups() {
		ArrayList<ApplicationGroupVO> arlGroupVO = new ArrayList<ApplicationGroupVO>();
		ApplicationGroupVO objApplicationGroupVO;
		ArrayList<ApplicationVO> arlAppVO;
		ApplicationVO objApplicationVO;
		
		Query query = entityManager.createQuery("SELECT p FROM ApplicationGroup p");
		ArrayList<ApplicationGroup> arlGroupEntity = (ArrayList<ApplicationGroup>) query.getResultList();
		
		for(ApplicationGroup objApplicationGroup : arlGroupEntity){
			objApplicationGroupVO = new ApplicationGroupVO();
			arlAppVO = new ArrayList<ApplicationVO>();
			
			objApplicationGroupVO.setGroup_id(String.valueOf(objApplicationGroup.getApp_group_id()));
			objApplicationGroupVO.setGroupName(objApplicationGroup.getApp_group_name());
			
			Query queryApp = entityManager.createQuery("SELECT p FROM Application p where p.app_group_id=:app_group_id");
			queryApp.setParameter("app_group_id", objApplicationGroup.getApp_group_id());
			ArrayList<Application> arlAppEntity = (ArrayList<Application>) queryApp.getResultList();
			for(Application objAppEntity:arlAppEntity){
				objApplicationVO = new ApplicationVO();
				objApplicationVO.setAppDesc(objAppEntity.getApp_desc());
				objApplicationVO.setAppId(String.valueOf(objAppEntity.getApp_id()));
				objApplicationVO.setAppGroupId(String.valueOf(objAppEntity.getApp_group_id()));
				arlAppVO.add(objApplicationVO);
			}
			objApplicationGroupVO.setArlApps(arlAppVO);
			arlGroupVO.add(objApplicationGroupVO);
		}
		return arlGroupVO;
	}
	
	

	

	
	
}