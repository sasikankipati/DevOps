package com.uob.dashb.serviceImpl;


import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.CreateNewActivitiesDAO;
import com.uob.dashb.framework.database.entity.ActivityTransaction;
import com.uob.dashb.service.CreateNewActivitiesService;
import com.uob.dashb.vo.NewActivityVO;



@Service("CreateNewActivitiesService")
public class CreateNewActivitiesServiceImpl implements CreateNewActivitiesService {
	
	@Autowired
	CreateNewActivitiesDAO objCreateNewActivitiesDAO;
	
	@Autowired
	CommonDAO objCommonDAO;

	@Override
	public boolean createNewActivities() {
		boolean success = false;
		try{
			
			Calendar todayCal = Calendar.getInstance();
	        Date todayDate  = new Date(System.currentTimeMillis());
	        todayCal.setTime(todayDate);
	        
	        int dayOfWeek = todayDate.getDay();
	        if(dayOfWeek == 0){
	        	dayOfWeek = 7;
	        }
	        
	        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	        String curTime = String.format("%02d%02d", todayCal.get(Calendar.HOUR_OF_DAY), todayCal.get(Calendar.MINUTE));
	        String toTime = String.format("%02d%02d", todayCal.get(Calendar.HOUR_OF_DAY)+1, todayCal.get(Calendar.MINUTE));
	        
	        
	        ArrayList<NewActivityVO> arlActivities = objCreateNewActivitiesDAO.fetchNextActivities(String.valueOf(dayOfWeek),curTime,toTime);
	        
	        int nextGroupId;
	        HashMap<Integer, Integer> hmTxnGroup = new HashMap<Integer, Integer>();
	        
	        for(NewActivityVO objActivityVO:arlActivities){
	        	hmTxnGroup.put(objActivityVO.getActivitygroup(), 0);
	        }
	        
	        Iterator<Integer> itrGroupActivity = hmTxnGroup.keySet().iterator();
	        Integer itGroupAct;
	        while(itrGroupActivity.hasNext()){
	        	itGroupAct = itrGroupActivity.next();
	        	if(hmTxnGroup.get(itGroupAct) == 0){
	        		nextGroupId = objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ACTIVITY_GROUP_ID_SEQNO_SQL);
	        		hmTxnGroup.put(itGroupAct, nextGroupId);
	        	}
	        }
	        ActivityTransaction objActivityTransaction;
	        java.util.Date dt = new java.util.Date();
	        
	        for(NewActivityVO objActivityVO:arlActivities){
	        	objActivityTransaction = new ActivityTransaction();
	        	objActivityTransaction.setAct_tnx_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ACT_TNX_SEQNO_SQL));
	        	objActivityTransaction.setTask_activity_id(objActivityVO.getTask_activity_id());
	        	objActivityTransaction.setJob_master_id(objActivityVO.getJob_master_id());
	        	objActivityTransaction.setActivity_id(objActivityVO.getActivity_id());
	        	objActivityTransaction.setCreated_on(new Timestamp(System.currentTimeMillis()));
	        	objActivityTransaction.setCompletion_flag("N");
	        	objActivityTransaction.setGroup_id(objActivityVO.getGroup_id());
	        	objActivityVO.setCreatedBy("AUTOGEN");
	        	
	        	dt.setHours(Integer.valueOf(objActivityVO.getStart_time().substring(0, 2)));
	        	dt.setMinutes(Integer.valueOf(objActivityVO.getStart_time().substring(2)));
	        	objActivityTransaction.setScheduled_on(new Timestamp(dt.getTime()));
	        	objActivityTransaction.setTxngroup(hmTxnGroup.get(objActivityVO.getActivitygroup()));
	        	
	        	int completedBy = Integer.valueOf(objActivityVO.getStart_time().substring(2));
	        	completedBy = completedBy + Integer.valueOf(objActivityVO.getMinutes());
	        	dt.setMinutes(completedBy);
	        	objActivityTransaction.setTo_be_completed_on(new Timestamp(dt.getTime()));
	        	boolean saved = objCreateNewActivitiesDAO.saveNewActivity(objActivityTransaction);
	        }
			
			success = true;
		}catch(Exception e){
			e.printStackTrace();
		}
		return success;
	}

	
	
	
}