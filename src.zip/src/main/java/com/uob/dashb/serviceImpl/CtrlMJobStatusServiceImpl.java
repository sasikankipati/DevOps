package com.uob.dashb.serviceImpl;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.CreateNewActivitiesDAO;
import com.uob.dashb.framework.database.entity.JobLog;
import com.uob.dashb.framework.database.entity.JobTracker;
import com.uob.dashb.service.CtrlMJobStatusService;
import com.uob.dashb.service.JobMasterService;
import com.uob.dashb.vo.JobVO;


@Configuration
@Service("CtrlMJobStatusService")
public class CtrlMJobStatusServiceImpl implements CtrlMJobStatusService {
	
	@Autowired
	CreateNewActivitiesDAO objCreateNewActivitiesDAO;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	@Autowired
	JobMasterService objJobMasterService;

	@Value("${jobxls.path}")
	private String jobXlsPath;
	
	@Override
	@Transactional
	public boolean fetchJobsFromCtrlM() {
		ArrayList<JobVO> arlJobs = objJobMasterService.fetchJobsfullList();
		System.out.println("jobXlsPath"+jobXlsPath);
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		System.out.println(new SimpleDateFormat("EE", Locale.ENGLISH).format(date.getTime()));
		String jobLogPath = "JOB_LOG_"+new SimpleDateFormat("EE", Locale.ENGLISH).format(date.getTime());
		jobXlsPath = jobXlsPath+"/"+jobLogPath+".csv";
		ArrayList<String> jobLine = fetchCntrlMJobStatus(jobXlsPath);
		ArrayList<JobVO> finalList = new ArrayList<JobVO>();
		JobVO finalJobVO;
		if(jobLine.size() > 0){
			if(null != arlJobs && arlJobs.size() > 0){
				for(JobVO objJobVO:arlJobs){
					for(String eachLine:jobLine){
						if(null != eachLine && eachLine.contains(objJobVO.getJobName())){
							finalJobVO = new JobVO();
							finalJobVO.setJobName(objJobVO.getJobName());
							finalJobVO.setJobMasterId(objJobVO.getJobMasterId());
							finalJobVO.setAppName(objJobVO.getAppName());
							finalJobVO.setEachLine(eachLine);
							finalList.add(finalJobVO);
						}
					}
				}
			}else{
				System.out.println("No Master setup");
			}
		}else{
			System.out.println("Nothing returned by control-M");
		}
		JobLog objJobLog;
		//27/06/2016  2:00:10 AM   "2016-06-28 02:00:04"
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		SimpleDateFormat oDateFormat = new SimpleDateFormat("yyyyMMdd");
		Date parsedDate;
		try {
			if(null != finalList && finalList.size() > 0){
				for(JobVO finalVO:finalList){
					objJobLog = new JobLog();
					objJobLog.setJob_id(Integer.valueOf(finalVO.getJobMasterId()));
					objJobLog.setApp_id(finalVO.getAppName());
					
					String[] result = finalVO.getEachLine().split(",");
					for(int i = 0 ; i < result.length ; i++){
						switch (i) {
						case 0:
							objJobLog.setData_center(result[i].trim());
							break;
						case 1:
							objJobLog.setJob_table(result[i].trim());
							break;
						case 2:
							objJobLog.setJob_name(result[i].trim());
							break;
						case 4:
							objJobLog.setJob_group(result[i].trim());
							break;
						case 5:
							objJobLog.setJob_owner(result[i].trim());
							break;
						case 6:
							objJobLog.setNode_id(result[i].trim());
							break;
						case 7:
							objJobLog.setJob_status(result[i].trim());
							break;
						case 8:
							parsedDate = dateFormat.parse(result[i].trim());
							objJobLog.setStart_time(new java.sql.Timestamp(parsedDate.getTime()));
							break;
						case 9:
							parsedDate = dateFormat.parse(result[i].trim());
							objJobLog.setEnd_time(new java.sql.Timestamp(parsedDate.getTime()));
							break;
						case 10:
							parsedDate = oDateFormat.parse(result[i].trim());
							objJobLog.setOrder_date(new java.sql.Timestamp(parsedDate.getTime()));
							break;
						case 11:
							objJobLog.setRerun_counter(Integer.valueOf(result[i].trim()).intValue());
							break;
						case 12:
							objJobLog.setRun_time_sec(Integer.valueOf(result[i].trim()).intValue());
							break;
						default:
							break;
						}
					}
					for(JobVO objJobVO:arlJobs){
						if(objJobVO.getJobName().equalsIgnoreCase(objJobLog.getJob_name())){
							objJobLog.setJob_log_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_JOB_LOG_ID_SEQNO_SQL));
							objJobLog.setCreated_on(new Timestamp(System.currentTimeMillis()));
							JobTracker objJobTracker = null;
							try{
								objJobTracker = objJobMasterService.getJobTracker(Integer.valueOf(finalVO.getJobMasterId()));
							}catch(Exception e){
								System.out.println("No existing job tracker record for JOBID :: "+objJobLog.getJob_name());
							}
							if(null != objJobTracker){
								objJobTracker.setOrder_date(objJobLog.getOrder_date());
								objJobTracker.setCreated_on(objJobLog.getCreated_on());
								objJobMasterService.updateJobTracker(objJobTracker);
							}else{
								objJobTracker = new JobTracker();
								objJobTracker.setJob_id(Integer.valueOf(finalVO.getJobMasterId()));
								objJobTracker.setOrder_date(objJobLog.getOrder_date());
								objJobTracker.setCreated_on(objJobLog.getCreated_on());
								objJobTracker.setJob_tracker_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_JOB_TRACKER_ID_SEQNO_SQL));
								objJobMasterService.saveJobTracker(objJobTracker);
							}
							objJobLog.setJob_tracker_id(objJobTracker.getJob_tracker_id());
							objJobMasterService.saveJobLog(objJobLog);
							break;
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	private ArrayList<String> fetchCntrlMJobStatus(String xlsFilePath){
		ArrayList<String> jobLine = new ArrayList<String>();
		try {
			String DATE_PATTERN_SLASH_YYYY ="yyyyMMdd";
			String currentDate = "";
			String prevDate = "";
			
			Calendar cal = Calendar.getInstance();
	        SimpleDateFormat sdf = new SimpleDateFormat(DATE_PATTERN_SLASH_YYYY);
	        currentDate = sdf.format(cal.getTime());
	        cal.add(Calendar.DATE, -1);
	        prevDate = sdf.format(cal.getTime());
	        
			BufferedReader reader;
			URL url = new URL("http://ctmusg03:18080/ctmruninfo/GetRunInfoHistory");
			//String reqParam = "dataCenter=&table=&app=&group=&jobName=&owner=&nodeID=&jobStatus=ALL&orderDateBeg=20160628&orderDateEnd=20160628&startTimeBeg=&startTimeEnd=&endTimeBeg=&endTimeEnd=";
			String reqParam = "dataCenter=&table=&app=&group=&jobName=&owner=&nodeID=&jobStatus=ALL&orderDateBeg=START_DATE&orderDateEnd=END_DATE&startTimeBeg=&startTimeEnd=&endTimeBeg=&endTimeEnd=";
			
			reqParam = reqParam.replace("START_DATE", prevDate);
			reqParam = reqParam.replace("END_DATE", currentDate);
			
			byte[] postDataBytes = reqParam.toString().getBytes("UTF-8");

			HttpURLConnection conn = (HttpURLConnection)url.openConnection();
			conn.setRequestMethod( "POST" );
			conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
			conn.setRequestProperty("Accept-Encoding", "gzip, deflate");
			conn.setRequestProperty("Accept-Language", "en-US,en;q=0.8");
			conn.setRequestProperty( "Content-Type", "application/x-www-form-urlencoded"); 
			conn.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
			conn.setDoOutput(true);
			conn.getOutputStream().write(postDataBytes);

			int status = conn.getResponseCode();
			BufferedWriter bf = new BufferedWriter(new FileWriter(xlsFilePath));
	        if(HttpURLConnection.HTTP_OK == status){
	        	reader=new BufferedReader(new InputStreamReader(conn.getInputStream())); // now reading the data..
	            StringBuffer buff=new StringBuffer();
	            String outputData=null;
	            System.out.println(xlsFilePath);
	            while((outputData=reader.readLine())!=null) {
	            	buff.append(outputData);
	            	jobLine.add(outputData);
	            	buff.append("\n");
	            	bf.write(outputData);
	            	bf.write("\n");
	            }
	            bf.flush();
	            //System.out.println(buff);
	        }
	        bf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return jobLine;
	}
	
}