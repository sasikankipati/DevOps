package com.uob.dashb.serviceImpl;


import java.util.ArrayList;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.EnvironmentDAO;
import com.uob.dashb.framework.database.entity.Environment;
import com.uob.dashb.service.EnvironmentService;
import com.uob.dashb.vo.EnvironmentVO;



@Service("EnvironmentService")
public class EnvironmentServiceImpl implements EnvironmentService {

	@Autowired
	EnvironmentDAO objEnvironmentDAO;
	
	@Autowired
	CommonDAO objCommonDAO;
	

	@Override
	public ArrayList<EnvironmentVO> fetchAllList() {
		ArrayList<EnvironmentVO> arlEnvironmentVO = new ArrayList<EnvironmentVO>();
		ArrayList<Environment> arlEnvEntity = objEnvironmentDAO.fetchAllList();
		EnvironmentVO toObj;
		for(Environment fromObj:arlEnvEntity){
			toObj = new EnvironmentVO();
			BeanUtils.copyProperties(fromObj, toObj);
			arlEnvironmentVO.add(toObj);
		}
		return arlEnvironmentVO;
	}


	@Override
	public boolean saveEnvironment(EnvironmentVO objEnvironmentVO) {
		Environment objEnvironment = new Environment();
		BeanUtils.copyProperties(objEnvironmentVO, objEnvironment);
		objEnvironment.setRec_status("A");
		objEnvironment.setEnvironment_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_ENVIRONMENT_SEQNO_SQL));
		boolean success = objEnvironmentDAO.saveEnvironment(objEnvironment);
		return success;
	}


	@Override
	public EnvironmentVO viewEnvironment(EnvironmentVO objEnvironmentVO) {
		Environment objEnvironment = objEnvironmentDAO.viewTestCase(Integer.valueOf(objEnvironmentVO.getEnvironment_id()));
		BeanUtils.copyProperties(objEnvironment, objEnvironmentVO);
		return objEnvironmentVO;
	}


	@Override
	public boolean updateEnvironment(EnvironmentVO objEnvironmentVO) {
		boolean success = objEnvironmentDAO.updateEnvironment(objEnvironmentVO);
		return success;
	}


	@Override
	public boolean deleteEnvironment(EnvironmentVO objEnvironmentVO) {
		boolean success = objEnvironmentDAO.deleteEnvironment(Integer.valueOf(objEnvironmentVO.getEnvironment_id()));
		return success;
	}


	@Override
	public boolean duplicateCheck(EnvironmentVO objEnvironmentVO) {
		boolean exists = false;
		ArrayList<Environment> arlEnvEntity = objEnvironmentDAO.getEnvironment(objEnvironmentVO.getEnv_id());
		if(null != arlEnvEntity && arlEnvEntity.size() > 0){
			exists = true;
		}
		return exists;
	}

	
}