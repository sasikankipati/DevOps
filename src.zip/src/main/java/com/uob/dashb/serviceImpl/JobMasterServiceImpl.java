package com.uob.dashb.serviceImpl;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.JobDependency;
import com.uob.dashb.framework.database.entity.JobLog;
import com.uob.dashb.framework.database.entity.JobMaster;
import com.uob.dashb.framework.database.entity.JobTracker;
import com.uob.dashb.service.JobMasterService;
import com.uob.dashb.vo.JobDependencyVO;
import com.uob.dashb.vo.JobVO;



@Service("JobMasterService")
public class JobMasterServiceImpl implements JobMasterService {

	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional(readOnly = true)
	public ApplicationGroup getById(int id) {
		return entityManager.find(ApplicationGroup.class, id);
	}
	
	
	@Override
	public ArrayList<JobVO> fetchJobsfullList() {
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		JobVO objJobVO;
		Query query = entityManager.createQuery("SELECT p FROM JobMaster p");
		ArrayList<JobMaster> arlResult = (ArrayList<JobMaster>) query.getResultList();
		for(JobMaster objJobMaster:arlResult){
			objJobVO = new JobVO();
			objJobVO.setJobName(objJobMaster.getJob_name());
			objJobVO.setJobDesc(objJobMaster.getJob_desc());
			objJobVO.setJobMasterId(String.valueOf(objJobMaster.getJob_master_id()));
			objJobVO.setAppName(objJobMaster.getApp_id());
			arlJobs.add(objJobVO);
		}
		return arlJobs;
	}

	@Override
	public ArrayList<JobVO> fetchJobLogs() {
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		JobVO objJobVO;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		SimpleDateFormat oDateSdf = new SimpleDateFormat("dd-MM-yyyy");
		String query = "select jobmaster.job_master_id,jobmaster.job_name,jobLog.ORDER_DATE,jobmaster.job_desc,jobmaster.standard_stime,jobmaster.standard_etime,jobLog.JOB_STATUS,jobLog.START_TIME,jobLog.END_TIME "
						+"from job_log jobLog, job_master jobMaster where jobMaster.job_name = jobLog.JOB_NAME (+)";

		Query activityList = entityManager.createNativeQuery(query);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		
		for(Object[] obj:arlResult){
			objJobVO = new JobVO();
			objJobVO.setJobMasterId(String.valueOf(((BigDecimal)obj[0]).intValue()));
			objJobVO.setJobName((String)obj[1]);
			if(null != obj[2]){
				objJobVO.setOrderDate(oDateSdf.format(new Date(((Timestamp)obj[2]).getTime())));
			}
			objJobVO.setJobDesc((String)obj[3]);
			objJobVO.setStandardStartTime((String)obj[4]);
			objJobVO.setStandardEndTime((String)obj[5]);
			if(null != obj[6]){
				objJobVO.setStatus((String)obj[6]);
			}else{
				objJobVO.setStatus("No Data");
			}
			
			if(null != obj[7]){
				objJobVO.setActualStartTime(sdf.format(new Date(((Timestamp)obj[7]).getTime())));
			}else{
				objJobVO.setStatus("No Data");
			}
			
			if(null != obj[8]){
				objJobVO.setActualEndTime(sdf.format(new Date(((Timestamp)obj[8]).getTime())));
			}else{
				objJobVO.setStatus("No Data");
			}
						
			arlJobs.add(objJobVO);
		}
		return arlJobs;
	}
	
	@Override
	public ArrayList<JobVO> fetchAllJobs(String userId) {
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		JobVO objJobVO;
		
		String query = "select appgroup.app_group_name,appgroup.app_group_id,jobmaster.job_master_id,jobmaster.job_name,jobmaster.job_desc,jobmaster.standard_stime,jobmaster.standard_etime "
				+"from application_group appgroup , job_master jobmaster , user_profile usr, user_application_group userappgroup "
				+"where userappgroup.user_id=usr.user_id and usr.user_id=:userId and userappgroup.app_group_id = appgroup.app_group_id  and "
				+"appgroup.app_group_id=jobmaster.app_group_id ";
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("userId",userId);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		
		for(Object[] obj:arlResult){
			objJobVO = new JobVO();
			objJobVO.setGroupName((String)obj[0]);
			objJobVO.setJobName((String)obj[3]);
			objJobVO.setJobDesc((String)obj[4]);
			objJobVO.setStandardStartTime((String)obj[5]);
			objJobVO.setStandardEndTime((String)obj[6]);
			objJobVO.setJobMasterId(String.valueOf(((BigDecimal)obj[2]).intValue()));
			arlJobs.add(objJobVO);
		}
		return arlJobs;
	}

	@Override
	public ArrayList<JobDependencyVO> fetchDependencies(String jobMasterId) {
		ArrayList<JobDependencyVO> arlJobDependencyVO = new ArrayList<JobDependencyVO>();
		JobDependencyVO objJobDependencyVO;
		
		Query query = entityManager.createQuery("SELECT p FROM JobDependency p where p.job_master_id=:job_master_id");
		query.setParameter("job_master_id", Integer.valueOf(jobMasterId));
		ArrayList<JobDependency> arlDepenEnetity = (ArrayList<JobDependency>) query.getResultList();
		
		for(JobDependency depenEntity:arlDepenEnetity){
			objJobDependencyVO = new JobDependencyVO();
			objJobDependencyVO.setDownstreamDependency(depenEntity.getDownstream_dep());
			objJobDependencyVO.setUpstreamDependency(depenEntity.getUpstream_dep());
			objJobDependencyVO.setRemarks(depenEntity.getRemarks());
			objJobDependencyVO.setImpact(depenEntity.getImpact());
			arlJobDependencyVO.add(objJobDependencyVO);
		}
		
		return arlJobDependencyVO;
	}

	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void saveJobLog(JobLog objJobLog) {
		entityManager.persist(objJobLog);
		entityManager.flush();
	}

	@Override
	public JobTracker getJobTracker(Integer job_id) {
		Query query = entityManager.createQuery("SELECT p FROM JobTracker p where p.job_id=:job_id");
		query.setParameter("job_id", job_id);
		return (JobTracker) query.getSingleResult();
	}

	@Override
	@Transactional(readOnly = false)
	public void updateJobTracker(JobTracker objJobTracker) {
		JobTracker updateJobTracker = entityManager.find(JobTracker.class, objJobTracker.getJob_tracker_id());
		entityManager.persist(updateJobTracker);
		entityManager.flush();
	}
	
	@Override
	@Transactional(readOnly = false)
	public void saveJobTracker(JobTracker objJobTracker) {
		entityManager.persist(objJobTracker);
		entityManager.flush();
	}
	
}