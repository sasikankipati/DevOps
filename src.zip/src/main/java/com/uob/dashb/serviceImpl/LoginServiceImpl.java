package com.uob.dashb.serviceImpl;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.framework.database.entity.Roles;
import com.uob.dashb.framework.database.entity.UserProfile;
import com.uob.dashb.framework.database.entity.UserRoles;
import com.uob.dashb.service.LoginService;
import com.uob.dashb.vo.UserRolesVO;
import com.uob.dashb.vo.UserVO;



@Service("LoginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	CommonDAO objCommonDAO;
	
	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional(readOnly = true)
	public UserProfile getById(int id) {
		return entityManager.find(UserProfile.class, id);
	}
	
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public UserProfile updatePassword(UserVO objUserVO) {
		UserProfile objUserProfile = entityManager.find(UserProfile.class, Integer.valueOf(objUserVO.getUserId()));
		objUserProfile.setPassword(objUserVO.getPassword());
		entityManager.flush();
		return objUserProfile;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public List<UserProfile> getAll() {
		Query query = entityManager.createQuery("SELECT p FROM UserProfile p");
		List<UserProfile> items = null;
		items = query.getResultList();
		return items;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public UserProfile save(UserProfile userProfile) {
		entityManager.persist(userProfile);
		entityManager.flush();
		return userProfile;
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void insertUserRole(int user_id, String role) {
		UserRoles objUserRoles = new UserRoles();
		objUserRoles.setUser_role_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_USER_ROLE_SEQNO_SQL));
		objUserRoles.setRole_id(Integer.valueOf(role));
		objUserRoles.setUser_id(user_id);
		entityManager.persist(objUserRoles);
		entityManager.flush();
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public void updateUserRole(int user_id, String role) {
		Query queryFindItems = entityManager.createNativeQuery("update user_roles set role_id=:role_id where user_id=:userId");
		queryFindItems.setParameter("role_id", Integer.valueOf(role));
		queryFindItems.setParameter("userId",user_id);
		queryFindItems.executeUpdate();
	}
	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public UserProfile updateUser(UserVO objUserVO) {
		UserProfile objUserProfile = entityManager.find(UserProfile.class, Integer.valueOf(objUserVO.getUserId()));
		objUserProfile.setEmail(objUserVO.getEmail());
		objUserProfile.setLanid(objUserVO.getLanId());
		objUserProfile.setPassword(objUserVO.getPassword());
		objUserProfile.setPhone(objUserVO.getMobile());
		if(objUserVO.getAdmin()){
			objUserProfile.setAdminflag("Y");
		}else{
			objUserProfile.setAdminflag("N");
		}
		objUserProfile.setStatus("A");
		objUserProfile.setUser_name(objUserVO.getUserName());
		entityManager.flush();
		return objUserProfile;
	}
	
	@SuppressWarnings("unchecked")
	@Transactional(readOnly = true)
	public UserProfile findItems(String userName) {
		UserProfile result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserProfile p where p.user_id=:userId");
		queryFindItems.setParameter("userId", userName);
		List<UserProfile> userProfileList = queryFindItems.getResultList();
		if(userProfileList.size() > 0) {
			result = userProfileList.get(0);
		}
		return result;
	}

	@Override
	public UserProfile authenticateUser(String userId, String password) {
		UserProfile result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserProfile p where p.lanid=:userId and p.password=:password");
		queryFindItems.setParameter("userId", userId);
		queryFindItems.setParameter("password", password);
		List<UserProfile> userProfileList = queryFindItems.getResultList();
		if(userProfileList.size() > 0) {
			result = userProfileList.get(0);
		}
		return result;
	}
	
	@Override
	public UserProfile getUser(String userId) {
		UserProfile result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserProfile p where p.user_id=:userId");
		queryFindItems.setParameter("userId", Integer.valueOf(userId));
		List<UserProfile> userProfileList = queryFindItems.getResultList();
		if(userProfileList.size() > 0) {
			result = userProfileList.get(0);
		}
		return result;
	}

	@Override
	public UserVO getUserRole(Integer userId) {
		UserVO objUserVO = new UserVO();
		ArrayList<UserRoles> arlUserRoles = null;
		Query queryFindItems = entityManager.createNativeQuery("select rls.role_id,rls.role_desc from user_roles usrrole,roles rls where usrrole.role_id = rls.role_id and usrrole.user_id=:user_id");
		queryFindItems.setParameter("user_id", userId);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) queryFindItems.getResultList();
		if(arlResult.size() == 1){
			Object[] obj = arlResult.get(0) ;
			objUserVO.setRole(String.valueOf(((BigDecimal)obj[0]).intValue()));
			objUserVO.setRoleDesc((String)obj[1]);
		}
		return objUserVO;
	}

	@Override
	public ArrayList<UserVO> fetchAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserProfile fetchUserByLanId(String lanid) {
		UserProfile result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserProfile p where p.lanid=:lanid");
		queryFindItems.setParameter("lanid", lanid);
		List<UserProfile> userProfileList = queryFindItems.getResultList();
		if(userProfileList.size() > 0) {
			result = userProfileList.get(0);
		}
		return result;
	}

	@Override
	public ArrayList<UserRolesVO> fetchAllRoles() {
		Query query = entityManager.createQuery("SELECT p FROM Roles p");
		List<Roles> items = query.getResultList();
		ArrayList<UserRolesVO> arlUserRoles = new ArrayList<UserRolesVO>();
		UserRolesVO objUserRolesVO;
		for(Roles objRoles:items){
			objUserRolesVO = new UserRolesVO();
			objUserRolesVO.setRoleId(String.valueOf(objRoles.getRole_id()));
			objUserRolesVO.setRoleDesc(objRoles.getRole_desc());
			arlUserRoles.add(objUserRolesVO);
		}
		return arlUserRoles;
	}

	

	

	/*@Override
	public UserRoles getUserRole(String userId) {
		UserRoles result = null;
		Query queryFindItems = entityManager.createQuery("SELECT p FROM UserRoles p where p.user_id=:user_id");
		queryFindItems.setParameter("user_id", Integer.valueOf(userId));
		List<UserRoles> arlUserRoles = queryFindItems.getResultList();
		if(arlUserRoles.size() > 0) {
			result = arlUserRoles.get(0);
		}
		return result;
	}
*/
	

	
}