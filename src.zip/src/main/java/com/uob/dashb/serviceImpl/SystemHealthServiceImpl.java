package com.uob.dashb.serviceImpl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.SystemHealthDAO;
import com.uob.dashb.dao.TestScenarioDAO;
import com.uob.dashb.framework.database.entity.TestScenario;
import com.uob.dashb.framework.database.entity.TestStatus;
import com.uob.dashb.framework.database.entity.TestTracker;
import com.uob.dashb.service.ApplicationService;
import com.uob.dashb.service.SystemHealthService;
import com.uob.dashb.vo.CountryVO;
import com.uob.dashb.vo.EnvironmentVO;
import com.uob.dashb.vo.SystemHealthChkVO;



@Service("SystemHealthService")
public class SystemHealthServiceImpl implements SystemHealthService {

	@Autowired
	SystemHealthDAO objSystemHealthDAO;
	
	@Autowired
	TestScenarioDAO objTestScenarioDAO;
	
	@Autowired
	CommonDAO objCommonDAO; 
	
	@Autowired
	ApplicationService objApplicationService;

	@Override
	public String save(SystemHealthChkVO objSystemHealthChkVO) {
		String statusCode="000";
		/** Validate test scenarion & test case if exists **/
		 ArrayList<TestScenario> arlTSEntities = objTestScenarioDAO.checkTSifExists(objSystemHealthChkVO.getScenario_id(),objSystemHealthChkVO.getCase_id());
		if(null != arlTSEntities && arlTSEntities.size() > 0){
			/** Validate test tracker if exists else insert **/
			ArrayList<TestTracker> arlTracker = objSystemHealthDAO.checkTestTracker(objSystemHealthChkVO.getScenario_id());
			if(null == arlTracker || arlTracker.size() == 0){
				/** insert test tracker **/
				TestTracker objTestTracker = new TestTracker();
				objTestTracker.setTest_tracker_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TEST_TRACKER_ID_SEQNO_SQL));
				objTestTracker.setScenario_id(objSystemHealthChkVO.getScenario_id());
				objTestTracker.setExec_date(objSystemHealthChkVO.getExec_date());
				objTestTracker.setExec_time(objSystemHealthChkVO.getExec_time());
				boolean trackerSaved = objSystemHealthDAO.saveTracker(objTestTracker);
			}else{
				TestTracker objTestTracker = arlTracker.get(0);
				boolean trackerSaved = objSystemHealthDAO.updateTracker(objSystemHealthChkVO,objTestTracker);
			}
			TestStatus objTestStatus = new TestStatus();
			objTestStatus.setTest_status_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TEST_STATUS_SEQNO_SQL));
			objTestStatus.setCase_id(objSystemHealthChkVO.getCase_id());
			objTestStatus.setExec_date(objSystemHealthChkVO.getExec_date());
			objTestStatus.setExec_time(objSystemHealthChkVO.getExec_time());
			objTestStatus.setScenario_id(objSystemHealthChkVO.getScenario_id());
			objTestStatus.setStatus(objSystemHealthChkVO.getStatus());
			boolean testResultSaved = objSystemHealthDAO.saveTestStatus(objTestStatus);
			/** insert test status **/
		}else{
			statusCode="001";
		}
		return statusCode;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchAppLevelHealthCheck() {
		
		ArrayList<SystemHealthChkVO> arlHealthCheck = objSystemHealthDAO.fetchAppLvlStatus();
		HashMap<String, ArrayList<CountryVO>> hmApp = new HashMap<String, ArrayList<CountryVO>>();
		ArrayList<CountryVO> arlCountries;
		String exec_date="";
		String exec_time="";
		
		for(SystemHealthChkVO fulList:arlHealthCheck){
			
			if(null != fulList.getExec_date()){
				exec_date = fulList.getExec_date();
			}
			
			if(null != fulList.getExec_time()){
				exec_time = fulList.getExec_time();
			}
			
			if(hmApp.containsKey(fulList.getAppId())){
				
				arlCountries = hmApp.get(fulList.getAppId());
				boolean ctryExists = false;
				CountryVO toSet = new CountryVO();
				for(CountryVO eachCtry: arlCountries){
					if(null != eachCtry && null != eachCtry.getCountry() && eachCtry.getCountry().equalsIgnoreCase(fulList.getCountry())){
						ctryExists = true;
						toSet = eachCtry;
					}
				}
				
				if(fulList.getStatus().equalsIgnoreCase("R")){
					toSet.setRed(fulList.getCount());
				}else if(fulList.getStatus().equalsIgnoreCase("G")){
					toSet.setGreen(fulList.getCount());
				}else if(fulList.getStatus().equalsIgnoreCase("A")){
					toSet.setAmber(fulList.getCount());
				}
				toSet.setCountry(fulList.getCountry());
				if(!ctryExists){
					arlCountries.add(toSet);
				}
				hmApp.put(fulList.getAppId(), arlCountries);
			}else{
				arlCountries = new ArrayList<CountryVO>();
				CountryVO toSet = new CountryVO();
				if(null != fulList.getStatus()){
					if(fulList.getStatus().equalsIgnoreCase("R")){
						toSet.setRed(fulList.getCount());
					}else if(fulList.getStatus().equalsIgnoreCase("G")){
						toSet.setGreen(fulList.getCount());
					}else if(fulList.getStatus().equalsIgnoreCase("A")){
						toSet.setAmber(fulList.getCount());
					}
				}
				
				toSet.setCountry(fulList.getCountry());
				arlCountries.add(toSet);
				hmApp.put(fulList.getAppId(), arlCountries);
			}
		}
		
		ArrayList<SystemHealthChkVO> arlAppLevelChk = new ArrayList<SystemHealthChkVO>();
		SystemHealthChkVO objSystemHealthChkVO;	
		Iterator<String> itr = hmApp.keySet().iterator();
		String appId;
		while(itr.hasNext()){
			appId = itr.next();
			objSystemHealthChkVO = new SystemHealthChkVO();	
			objSystemHealthChkVO.setExec_date(exec_date);
			objSystemHealthChkVO.setExec_time(exec_time);
			objSystemHealthChkVO.setStatus("GREEN");
			objSystemHealthChkVO.setAppId(appId);
			objSystemHealthChkVO.setArlCountries(hmApp.get(appId));
			arlAppLevelChk.add(objSystemHealthChkVO);
		}
		
		return arlAppLevelChk;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchEnvLevelHealthCheck(String appId) {
		ArrayList<SystemHealthChkVO> arlEnvLevelChk = new ArrayList<SystemHealthChkVO>();
		SystemHealthChkVO objSystemHealthChkVO;	
		HashMap<String, ArrayList<EnvironmentVO>> hmEnv = new HashMap<String, ArrayList<EnvironmentVO>>();
		ArrayList<SystemHealthChkVO> arlHealthCheck = objSystemHealthDAO.fetchEnvLvlStatus(appId);
		String exec_date="";
		String exec_time="";
		ArrayList<EnvironmentVO> arlEnv;
		
		
		for(SystemHealthChkVO envSystemHealthChkVO:arlHealthCheck){
			
			if(null != envSystemHealthChkVO.getExec_date()){
				exec_date = envSystemHealthChkVO.getExec_date();
			}
			
			if(null != envSystemHealthChkVO.getExec_time()){
				exec_time = envSystemHealthChkVO.getExec_time();
			}
			
			if(hmEnv.containsKey(envSystemHealthChkVO.getCountry())){
				
				arlEnv = hmEnv.get(envSystemHealthChkVO.getCountry());
				boolean envExists = false;
				EnvironmentVO toSet = new EnvironmentVO();
				for(EnvironmentVO eachEnv: arlEnv){
					if(null != eachEnv && null != eachEnv.getEnv_name() && eachEnv.getEnv_name().equalsIgnoreCase(envSystemHealthChkVO.getEnv())){
						envExists = true;
						toSet = eachEnv;
					}
				}
				
				
				if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("R")){
					toSet.setRed(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}else if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("G")){
					toSet.setGreen(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}else if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("A")){
					toSet.setAmber(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}
				toSet.setEnv_name(envSystemHealthChkVO.getEnv());
				if(!envExists){
					arlEnv.add(toSet);
				}
				hmEnv.put(envSystemHealthChkVO.getCountry(), arlEnv);
			}else{
				arlEnv = new ArrayList<EnvironmentVO>();
				EnvironmentVO toSet = new EnvironmentVO();
				if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("R")){
					toSet.setRed(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}else if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("G")){
					toSet.setGreen(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}else if(envSystemHealthChkVO.getStatus().equalsIgnoreCase("A")){
					toSet.setAmber(String.valueOf(envSystemHealthChkVO.getCompletedCnt()));
				}
				toSet.setEnv_name(envSystemHealthChkVO.getEnv());
				arlEnv.add(toSet);
				hmEnv.put(envSystemHealthChkVO.getCountry(), arlEnv);
			}
		}
		
		
		Iterator<String> itr = hmEnv.keySet().iterator();
		String cnryId;
		while(itr.hasNext()){
			cnryId = itr.next();
			objSystemHealthChkVO = new SystemHealthChkVO();	
			objSystemHealthChkVO.setExec_date(exec_date);
			objSystemHealthChkVO.setExec_time(exec_time);
			objSystemHealthChkVO.setStatus("GREEN");
			objSystemHealthChkVO.setCountry(cnryId);
			objSystemHealthChkVO.setAppId(appId);
			objSystemHealthChkVO.setArlEnv(hmEnv.get(cnryId));
			arlEnvLevelChk.add(objSystemHealthChkVO);
		}
		
		return arlEnvLevelChk;
	}

	@Override
	public ArrayList<SystemHealthChkVO> fetchTSLevelHealthCheck(String appId,String country) {
		ArrayList<SystemHealthChkVO> arlHealthCheck = objSystemHealthDAO.fetchTSLvlStatus(appId,country);
		return arlHealthCheck;
	}
	
	
}