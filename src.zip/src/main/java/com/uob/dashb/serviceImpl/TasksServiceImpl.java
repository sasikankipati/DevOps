package com.uob.dashb.serviceImpl;


import java.math.BigDecimal;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.framework.database.entity.ActivityTransaction;
import com.uob.dashb.framework.database.entity.ApplicationGroup;
import com.uob.dashb.framework.database.entity.TaskMaster;
import com.uob.dashb.service.TasksService;
import com.uob.dashb.vo.ActivityVO;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.JobVO;
import com.uob.dashb.vo.TaskDetailVO;



@Service("TasksService")
public class TasksServiceImpl implements TasksService {

	private EntityManager entityManager;

	@PersistenceContext
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Transactional(readOnly = true)
	public ApplicationGroup getById(int id) {
		return entityManager.find(ApplicationGroup.class, id);
	}

	
	@Override
	public ArrayList<ActivityVO> fetchPendingTasks(String userId,int count) {
		ArrayList<ActivityVO> arlActivityVO = new ArrayList<ActivityVO>();
		
		String query = "select distinct actTxn.txngroup,actLink.priority,actTxn.activitygroup,actTxn.scheduled_on,actMaster.activity_desc,actLink.app_id from activity_master actMaster, activity_transaction actTxn , task_activity_link actLink , "
					   +"user_application_group usrAppGroup where actMaster.activity_id = actLink.activity_id and completion_flag = 'N' and SCHEDULED_ON <= sysdate and " 
					   +"actTxn.task_activity_id = actLink.task_activity_id and actLink.group_id = usrAppGroup.app_group_id "
					   +"and usrAppGroup.user_id=:userId order by actLink.priority asc";
		
		Query pendingList = entityManager.createNativeQuery(query);
		pendingList.setParameter("userId", Integer.valueOf(userId));
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) pendingList.getResultList();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		
		if(null != arlResult && arlResult.size() > 0){
			
			if(count > arlResult.size()){
				count = arlResult.size();
			}
			
			for(int i=0;i<count;i++){
				Object[] obj = arlResult.get(i);
				ActivityVO objActivityVO = new ActivityVO();
				objActivityVO.setActivityDesc((String)obj[4]);
				objActivityVO.setScheduleAt(dateFormat.format((Timestamp)obj[3]));
				objActivityVO.setAppId((String)obj[5]);
				objActivityVO.setActivityGroup(String.valueOf(((BigDecimal)obj[2]).intValue()));
				objActivityVO.setTxnGroup(String.valueOf(((BigDecimal)obj[0]).intValue()));
				objActivityVO.setPriority((String)obj[1]);
				objActivityVO.setStatus("Not Completed");
				arlActivityVO.add(objActivityVO);
			}
		}
		return arlActivityVO;
	}
	
	
	public ArrayList<ActivityVO> listActivities(int groupId) {
		String query = "select appgroup.app_group_name,appgroup.app_group_id , app.app_id , app.app_desc , actlink.activitygroup ,actlink.start_time, actMas.activity_id , actMas.activity_desc "
				+"from application_group appgroup , user_application_group userappgroup , application app , task_activity_link actlink  , activity_master actMas "
				+"where userappgroup.user_id=:userId and userappgroup.app_group_id = appgroup.app_group_id  and appgroup.app_group_id = app.app_group_id and "
				+"app.app_id = actlink.app_id and actMas.activity_id = actlink.activity_id group by appgroup.app_group_name,appgroup.app_group_id , app.app_id,"
				+" app.app_desc , actlink.activitygroup ,actlink.start_time, actMas.activity_id , actMas.activity_desc";
		
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("userId",groupId);
		
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<ActivityVO> arlActivityVO = new ArrayList<ActivityVO>();
		ActivityVO objActivityVO;
		for(Object[] obj:arlResult){
			 
			objActivityVO = new ActivityVO();
			objActivityVO.setActivityGroup(String.valueOf(((BigDecimal)obj[4]).intValue()));
			objActivityVO.setActivityDesc((String)obj[7]);
			objActivityVO.setActivityId(String.valueOf(((BigDecimal)obj[6]).intValue()));
			objActivityVO.setAppName((String)obj[3]);
			objActivityVO.setScheduleAt((String)obj[5]);
			arlActivityVO.add(objActivityVO);
		}
		
		return arlActivityVO;
	}
	
	
	
	
	@Override
	public ArrayList<TaskDetailVO> fetchAllTasks() {
		String query = "select tm.task_id,tm.task_desc,tm.status,appGroup.app_group_id,appGroup.app_group_name "
				+"from task_master tm, application_group appGroup where tm.app_group_id = appGroup.app_group_id";
		Query activityList = entityManager.createNativeQuery(query);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		ArrayList<TaskDetailVO> arlTaskDetailVO = new ArrayList<TaskDetailVO>();
		TaskDetailVO objTaskDetailVO;
		for(Object[] obj:arlResult){
			objTaskDetailVO = new TaskDetailVO();
			
			objTaskDetailVO.setTaskId(String.valueOf(((BigDecimal)obj[0]).intValue()));
			objTaskDetailVO.setGroupDesc((String)obj[4]);
			objTaskDetailVO.setTaskDesc((String)obj[1]);
			
			arlTaskDetailVO.add(objTaskDetailVO);
		}
		return arlTaskDetailVO;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean save(TaskMaster objTaskMaster) {
		entityManager.persist(objTaskMaster);
		entityManager.flush();
		return true;
	}

	@Override
	public CommonVO viewSelectedTxn(ActivityVO objActivityVO, String userId) {
		
		CommonVO objCommonVO = new CommonVO();
		JobVO objJobVO;
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		TaskDetailVO objTaskDetailVO;
		ArrayList<TaskDetailVO> arlTaskDetailVO = new ArrayList<TaskDetailVO>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
		
		Query actDesc = entityManager.createNativeQuery("select actMaster.activity_desc,actMaster.activity_id,actTxn.scheduled_on,actTxn.group_id from activity_transaction actTxn,activity_master actMaster where actMaster.activity_id = actTxn.activity_id and actTxn.txngroup=:txngroup");
		actDesc.setParameter("txngroup", Integer.valueOf(objActivityVO.getTxnGroup()));
		ArrayList<Object[]> arlActResult = (ArrayList<Object[]>) actDesc.getResultList();
		
		if(null != arlActResult && arlActResult.size() > 0){
			Object[] obj = arlActResult.get(0);
			objActivityVO.setActivityId(String.valueOf(((BigDecimal)obj[1]).intValue()));
			objActivityVO.setActivityDesc((String)obj[0]);	
			objActivityVO.setScheduleAt(dateFormat.format((Timestamp)obj[2]));
			objActivityVO.setGroupId(String.valueOf(((BigDecimal)obj[3]).intValue()));
		}
		
		Query jobDesc = entityManager.createNativeQuery("select jobMaster.job_name,actTxn.act_tnx_id,jobmaster.job_name,jobmaster.job_desc,jobmaster.standard_stime,jobmaster.standard_etime,jobmaster.job_master_id,actTxn.actual_stime,actTxn.actual_etime from activity_transaction actTxn,job_master jobMaster where jobMaster.job_master_id = actTxn.job_master_id and actTxn.txngroup=:txngroup");
		jobDesc.setParameter("txngroup", Integer.valueOf(objActivityVO.getTxnGroup()));
		ArrayList<Object[]> arlJobResult = (ArrayList<Object[]>) jobDesc.getResultList();
		
		if(null != arlJobResult && arlJobResult.size() > 0){
			
			for(Object[] obj:arlJobResult){
				objJobVO = new JobVO();
				objJobVO.setAct_tnx_id(String.valueOf(((BigDecimal)obj[1]).intValue()));
				objJobVO.setJobName((String)obj[0]);
				objJobVO.setJobDesc((String)obj[3]);
				objJobVO.setStandardStartTime((String)obj[4]);
				objJobVO.setStandardEndTime((String)obj[5]);
				objJobVO.setJobMasterId(String.valueOf(((BigDecimal)obj[6]).intValue()));
				objJobVO.setActualStartTime((String)obj[7]);
				objJobVO.setActualEndTime((String)obj[8]);
				objJobVO.setChecked(true);
				arlJobs.add(objJobVO);
			}
		}
		
		String taskQuery="select taskMaster.task_desc,actTxn.act_tnx_id,actTxn.rag,actTxn.remarks,actTxn.completion_flag,actTxn.force_reason from activity_transaction actTxn,task_activity_link actLink ,task_master taskMaster "
				+"where actTxn.task_activity_id = actLink.task_activity_id and actLink.task_id = taskMaster.task_id and actTxn.txngroup=:txngroup";
		Query taskDesc = entityManager.createNativeQuery(taskQuery);
		taskDesc.setParameter("txngroup", Integer.valueOf(objActivityVO.getTxnGroup()));
		ArrayList<Object[]> arlTaskResult = (ArrayList<Object[]>) taskDesc.getResultList();
		
		for(Object[] obj:arlTaskResult){
			objTaskDetailVO = new TaskDetailVO();
			objTaskDetailVO.setTaskDesc((String)obj[0]);
			objTaskDetailVO.setAct_tnx_id(String.valueOf(((BigDecimal)obj[1]).intValue()));
			objTaskDetailVO.setChecked(true);
			if(null != obj[4] && ((String)obj[4]).equalsIgnoreCase("Y")){
				objTaskDetailVO.setCompleted(true);
			}
			objTaskDetailVO.setStatus((String)obj[2]);
			objTaskDetailVO.setRemarks((String)obj[3]);
			objTaskDetailVO.setForceOkReason((String)obj[5]);
			if(null != objTaskDetailVO.getForceOkReason() && objTaskDetailVO.getForceOkReason().length() > 0){
				objTaskDetailVO.setForceOk(true);
			}
			arlTaskDetailVO.add(objTaskDetailVO);
		}
		
		objCommonVO.setArlTaskDetailVO(arlTaskDetailVO);
		objCommonVO.setArlJobs(arlJobs);
		
		if(arlJobs.size() > 0){
			objActivityVO.setJobChecked(true);
		}
		
		if(arlTaskDetailVO.size() > 0){
			objActivityVO.setTaskChecked(true);
		}
		
		objCommonVO.setObjActivityVO(objActivityVO);
		
		return objCommonVO;
	}
	
	
	private ArrayList<JobVO> fetchAllJobs(String userId) {
		ArrayList<JobVO> arlJobs = new ArrayList<JobVO>();
		JobVO objJobVO;
		
		String query = "select appgroup.app_group_name,appgroup.app_group_id,jobmaster.job_master_id,jobmaster.job_name,jobmaster.job_desc,jobmaster.standard_stime,jobmaster.standard_etime "
				+"from application_group appgroup , job_master jobmaster , user_profile usr, user_application_group userappgroup "
				+"where userappgroup.user_id=usr.user_id and usr.user_id=:userId and userappgroup.app_group_id = appgroup.app_group_id  and "
				+"appgroup.app_group_id=jobmaster.app_group_id ";
		Query activityList = entityManager.createNativeQuery(query);
		activityList.setParameter("userId",userId);
		ArrayList<Object[]> arlResult = (ArrayList<Object[]>) activityList.getResultList();
		
		for(Object[] obj:arlResult){
			objJobVO = new JobVO();
			objJobVO.setGroupName((String)obj[0]);
			objJobVO.setJobName((String)obj[3]);
			objJobVO.setJobDesc((String)obj[4]);
			objJobVO.setStandardStartTime((String)obj[5]);
			objJobVO.setStandardEndTime((String)obj[6]);
			objJobVO.setJobMasterId(String.valueOf(((BigDecimal)obj[2]).intValue()));
			arlJobs.add(objJobVO);
		}
		return arlJobs;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean updateActTxn(ActivityVO objActivityVO,int userId) {
		
		ActivityTransaction toUpdate;
		
		if(null != objActivityVO.getArlTasks()){
			for(TaskDetailVO objTaskDetailVO:objActivityVO.getArlTasks()){
				toUpdate = new ActivityTransaction();
				toUpdate.setAct_tnx_id(Integer.valueOf(objTaskDetailVO.getAct_tnx_id()));
				toUpdate.setRag(objTaskDetailVO.getStatus());
				toUpdate.setRemarks(objTaskDetailVO.getRemarks());
				if(objTaskDetailVO.getCompleted()){
					toUpdate.setCompletion_flag("Y");
				}else{
					toUpdate.setCompletion_flag("N");
				}
				toUpdate.setCompleted_by(String.valueOf(userId));
				toUpdate.setCompleted_time(new Timestamp(System.currentTimeMillis()));
				toUpdate.setForce_by(String.valueOf(userId));
				toUpdate.setForce_reason(objTaskDetailVO.getForceOkReason());
				toUpdate.setForce_time(new Timestamp(System.currentTimeMillis()));
				toUpdate.setUpdated_by(String.valueOf(userId));
				toUpdate.setUpdated_on(new Timestamp(System.currentTimeMillis()));
				updateTransaction(toUpdate);
			}
		}
		
		if(null != objActivityVO.getArlJobs()){
			for(JobVO objJobVO:objActivityVO.getArlJobs()){
				toUpdate = new ActivityTransaction();
				toUpdate.setAct_tnx_id(Integer.valueOf(objJobVO.getAct_tnx_id()));
				toUpdate.setRag("Green");
				toUpdate.setCompletion_flag("Y");
				toUpdate.setCompleted_by(String.valueOf(userId));
				toUpdate.setCompleted_time(new Timestamp(System.currentTimeMillis()));
				toUpdate.setActual_stime(objJobVO.getActualStartTime());
				toUpdate.setActual_etime(objJobVO.getActualEndTime());
				toUpdate.setUpdated_by(String.valueOf(userId));
				toUpdate.setUpdated_on(new Timestamp(System.currentTimeMillis()));
				updateTransaction(toUpdate);
			}
		}
		
		
		
		
		return true;
	}
	
	
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	private void updateTransaction(ActivityTransaction toUpdate){
		ActivityTransaction objActivityTransaction = entityManager.find(ActivityTransaction.class, toUpdate.getAct_tnx_id());
		/*objActivityTransaction.setActual_etime();
		objActivityTransaction.setActual_stime();*/
		objActivityTransaction.setCompleted_by(toUpdate.getCompleted_by());
		objActivityTransaction.setCompleted_time(toUpdate.getCompleted_time());
		objActivityTransaction.setCompletion_flag(toUpdate.getCompletion_flag());
		objActivityTransaction.setForce_by(toUpdate.getForce_by());
		objActivityTransaction.setForce_reason(toUpdate.getForce_reason());
		objActivityTransaction.setForce_time(toUpdate.getForce_time());
		objActivityTransaction.setRag(toUpdate.getRag());
		objActivityTransaction.setRemarks(toUpdate.getRemarks());
		objActivityTransaction.setUpdated_by(toUpdate.getUpdated_by());
		objActivityTransaction.setUpdated_on(toUpdate.getUpdated_on());
		entityManager.flush();
	}

	@Override
	@Transactional(readOnly=true)
	public TaskDetailVO viewSelectedTask(String taskId) {
		Query query = entityManager.createQuery("SELECT p FROM TaskMaster p where task_id=:task_id and status=:status");
		query.setParameter("status", "A");
		query.setParameter("task_id", Integer.valueOf(taskId));
		ArrayList<TaskMaster> items = (ArrayList<TaskMaster>) query.getResultList();
		TaskDetailVO objTaskDetailVO = new TaskDetailVO();
		if(null != items && items.size() >= 0 ){
			TaskMaster objTaskMaster = items.get(0);
			objTaskDetailVO.setTaskId(String.valueOf(objTaskMaster.getTask_id()));
			objTaskDetailVO.setTaskDesc(objTaskMaster.getTask_desc());
			objTaskDetailVO.setStatus(objTaskMaster.getStatus());
			objTaskDetailVO.setGroupId(String.valueOf(objTaskMaster.getApp_group_id()));
		}
		return objTaskDetailVO;
	}

	
	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean deleteTask(TaskDetailVO objTaskDetailVO) {
		TaskMaster objTaskMaster = entityManager.find(TaskMaster.class, Integer.valueOf(objTaskDetailVO.getTaskId()));
		objTaskMaster.setStatus("D");
		entityManager.persist(objTaskMaster);
		entityManager.flush();
		return true;
	}

	@Override
	@Transactional(readOnly=false, propagation=Propagation.REQUIRED)
	public boolean updateTask(TaskDetailVO objTaskDetailVO) {
		TaskMaster objTaskMaster = entityManager.find(TaskMaster.class, Integer.valueOf(objTaskDetailVO.getTaskId()));
		objTaskMaster.setTask_desc(objTaskDetailVO.getTaskDesc());
		objTaskMaster.setApp_group_id(Integer.valueOf(objTaskDetailVO.getGroupId()));
		entityManager.persist(objTaskMaster);
		entityManager.flush();
		return true;
	}

	@Override
	public String getEmailDistribution(String groupId) {
		ApplicationGroup obApplicationGroup = entityManager.find(ApplicationGroup.class, Integer.valueOf(groupId));
		return obApplicationGroup.getEmail_distribution();
	}
	
}