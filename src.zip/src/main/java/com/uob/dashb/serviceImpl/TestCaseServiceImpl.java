package com.uob.dashb.serviceImpl;


import java.util.ArrayList;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.TestCaseDAO;
import com.uob.dashb.framework.database.entity.TestCase;
import com.uob.dashb.service.TestCaseService;
import com.uob.dashb.vo.TestCaseVO;



@Service("TestCaseService")
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	TestCaseDAO objTestCaseDAO;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	@Override
	public ArrayList<TestCaseVO> fetchAllTestCases() {
		ArrayList<TestCase> arlTestCaseEnty = objTestCaseDAO.fetchAllTestCases();
		ArrayList<TestCaseVO> arlTestCaseVO = new ArrayList<TestCaseVO>();
		TestCaseVO toObj;
		for(TestCase fromObj:arlTestCaseEnty){
			toObj = new TestCaseVO();
			BeanUtils.copyProperties(fromObj, toObj);
			arlTestCaseVO.add(toObj);
		}
		return arlTestCaseVO;
	}

	@Override
	public boolean saveTestCase(TestCaseVO objTestCaseVO) {
		TestCase objTestCase = new TestCase();
		BeanUtils.copyProperties(objTestCaseVO, objTestCase);
		objTestCase.setTest_case_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TEST_CASE_SEQNO_SQL));
		boolean success = objTestCaseDAO.saveTestCase(objTestCase);
		return success;
	}

	@Override
	public boolean deleteTestCase(TestCaseVO objTestCaseVO) {
		boolean success = objTestCaseDAO.deleteTestCase(Integer.valueOf(objTestCaseVO.getTest_case_id()));
		return success;
	}

	@Override
	public TestCaseVO viewTestCase(TestCaseVO objTestCaseVO) {
		TestCase objTestCase = objTestCaseDAO.viewTestCase(Integer.valueOf(objTestCaseVO.getTest_case_id()));
		BeanUtils.copyProperties(objTestCase, objTestCaseVO);
		return objTestCaseVO;
	}

	@Override
	public boolean updateTestCase(TestCaseVO objTestCaseVO) {
		boolean success = objTestCaseDAO.updateTestCase(objTestCaseVO);
		return success;
	}

	@Override
	public boolean duplicateCheck(TestCaseVO objTestCaseVO) {
		boolean exists = false;
		ArrayList<TestCase> arlTestCaseEnty  = objTestCaseDAO.getTestCase(objTestCaseVO.getCase_id());
		if(null != arlTestCaseEnty && arlTestCaseEnty.size() > 0){
			exists = true;
		}
		return exists;
	}

	
}