package com.uob.dashb.serviceImpl;


import java.util.ArrayList;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uob.dashb.common.util.NextSequenceUtil;
import com.uob.dashb.dao.CommonDAO;
import com.uob.dashb.dao.TestCaseDAO;
import com.uob.dashb.dao.TestScenarioDAO;
import com.uob.dashb.framework.database.entity.TestCase;
import com.uob.dashb.framework.database.entity.TestScenario;
import com.uob.dashb.service.TestScenarioService;
import com.uob.dashb.vo.CommonVO;
import com.uob.dashb.vo.TestCaseVO;
import com.uob.dashb.vo.TestScenarioVO;



@Service("TestScenarioService")
public class TestScenarioServiceImpl implements TestScenarioService {

	@Autowired
	TestScenarioDAO objTestScenarioDAO;
	
	@Autowired
	CommonDAO objCommonDAO;
	
	@Autowired
	TestCaseDAO objTestCaseDAO;

	@Override
	public ArrayList<TestScenarioVO> fetchAllList() {
		ArrayList<TestScenarioVO> arlTestScenarioVO = new ArrayList<TestScenarioVO>();
		ArrayList<TestScenario> arlTSEntity = objTestScenarioDAO.fetchAllList();
		TestScenarioVO toObj;
		for(TestScenario fromObj:arlTSEntity){
			toObj = new TestScenarioVO();
			BeanUtils.copyProperties(fromObj, toObj);
			arlTestScenarioVO.add(toObj);
		}
		return arlTestScenarioVO;
	}


	@Override
	@Transactional
	public boolean saveTestScenario(TestScenarioVO objTestScenarioVO) {
		TestScenario objTestScenario;
		boolean success = false;
		try {
			for(String strTestCase:objTestScenarioVO.getTestCases()){
				objTestScenario = new TestScenario();
				objTestScenario.setTest_scenario_id(objCommonDAO.getNextSequence(NextSequenceUtil.DOP_SEQ_TEST_SCENARIO_SEQNO_SQL));
				objTestScenario.setApp_id(objTestScenarioVO.getApp_id());
				objTestScenario.setCase_id(strTestCase);
				objTestScenario.setEnv_id(objTestScenarioVO.getEnv_id());
				objTestScenario.setScenario_desc(objTestScenarioVO.getScenario_desc());
				objTestScenario.setScenario_id(objTestScenarioVO.getScenario_id());
				objTestScenarioDAO.saveTestScenario(objTestScenario);
			}
			success = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return success;
	}


	@Override
	public CommonVO viewTestScenario(TestScenarioVO objTestScenarioVO) {
		CommonVO objCommonVO = new CommonVO();
		
		ArrayList<TestCase> arlTestCaseEnty = objTestCaseDAO.fetchAllTestCases();
		ArrayList<TestCaseVO> arlTestCaseVO = new ArrayList<TestCaseVO>();
		TestCaseVO toObj;
		for(TestCase fromObj:arlTestCaseEnty){
			toObj = new TestCaseVO();
			BeanUtils.copyProperties(fromObj, toObj);
			arlTestCaseVO.add(toObj);
		}
		
		ArrayList<TestScenario> arlTestScenEntity = objTestScenarioDAO.viewTestScenario(objTestScenarioVO.getScenario_id());
		
		for(TestScenario objEntity:arlTestScenEntity){
			for(TestCaseVO objTestCaseVO:arlTestCaseVO){
				if(objEntity.getCase_id().equalsIgnoreCase(objTestCaseVO.getCase_id())){
					objTestCaseVO.setChecked(true);
				}
			}
		}
		
		TestScenario objTestScenario = arlTestScenEntity.get(0);
		objTestScenarioVO.setScenario_id(objTestScenario.getScenario_id());
		objTestScenarioVO.setScenario_desc(objTestScenario.getScenario_desc());
		objTestScenarioVO.setEnv_id(objTestScenario.getEnv_id());
		objTestScenarioVO.setApp_id(objTestScenario.getApp_id());
		
		objCommonVO.setObjTestScenarioVO(objTestScenarioVO);
		objCommonVO.setArlTestCases(arlTestCaseVO);
		return objCommonVO;
	}


	@Override
	public boolean updateTestScenario(TestScenarioVO objTestScenarioVO) {
		/** Delete existing setup **/
		objTestScenarioDAO.deleteTestScenario(objTestScenarioVO.getScenario_id());
		/** Insert new setup **/
		TestScenario objTestScenario;
		boolean success = false;
		try {
			for(String strTestCase:objTestScenarioVO.getTestCases()){
				objTestScenario = new TestScenario();
				objTestScenario.setApp_id(objTestScenarioVO.getApp_id());
				objTestScenario.setCase_id(strTestCase);
				objTestScenario.setEnv_id(objTestScenarioVO.getEnv_id());
				objTestScenario.setScenario_desc(objTestScenarioVO.getScenario_desc());
				objTestScenario.setScenario_id(objTestScenarioVO.getScenario_id());
				objTestScenarioDAO.saveTestScenario(objTestScenario);
			}
			success = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return success;
	}


	@Override
	public boolean deleteTestScenario(TestScenarioVO objTestScenarioVO) {
		/** Delete existing setup **/
		boolean success = objTestScenarioDAO.deleteTestScenario(objTestScenarioVO.getScenario_id());
		return success;
	}


	@Override
	public CommonVO copyTestScenario(TestScenarioVO objTestScenarioVO) {
CommonVO objCommonVO = new CommonVO();
		
		ArrayList<TestCase> arlTestCaseEnty = objTestCaseDAO.fetchAllTestCases();
		ArrayList<TestCaseVO> arlTestCaseVO = new ArrayList<TestCaseVO>();
		ArrayList<TestCaseVO> arlNewTestCaseVO = new ArrayList<TestCaseVO>();
		TestCaseVO toObj;
		for(TestCase fromObj:arlTestCaseEnty){
			toObj = new TestCaseVO();
			BeanUtils.copyProperties(fromObj, toObj);
			arlTestCaseVO.add(toObj);
		}
		
		ArrayList<TestScenario> arlTestScenEntity = objTestScenarioDAO.viewTestScenario(objTestScenarioVO.getScenario_id());
		
		for(TestScenario objEntity:arlTestScenEntity){
			for(TestCaseVO objTestCaseVO:arlTestCaseVO){
				if(objEntity.getCase_id().equalsIgnoreCase(objTestCaseVO.getCase_id())){
					objTestCaseVO.setChecked(true);
					arlNewTestCaseVO.add(objTestCaseVO);
				}
			}
		}
		
		TestScenario objTestScenario = arlTestScenEntity.get(0);
		objTestScenarioVO.setScenario_id(objTestScenario.getScenario_id());
		objTestScenarioVO.setScenario_desc(objTestScenario.getScenario_desc());
		objTestScenarioVO.setEnv_id(objTestScenario.getEnv_id());
		objTestScenarioVO.setApp_id(objTestScenario.getApp_id());
		
		objCommonVO.setObjTestScenarioVO(objTestScenarioVO);
		objCommonVO.setArlTestCases(arlNewTestCaseVO);
		return objCommonVO;
	}


	@Override
	public boolean duplicateCheck(TestScenarioVO objTestScenarioVO) {
		boolean exists = false;
		ArrayList<TestScenario> arlTSEntity  = objTestScenarioDAO.viewTestScenario(objTestScenarioVO.getScenario_id());
		if(null != arlTSEntity && arlTSEntity.size() > 0){
			exists = true;
		}
		return exists;
	}



	
}