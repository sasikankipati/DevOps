package com.uob.dashb.vo;

import java.util.ArrayList;

public class ActivitiesMainVO extends BaseVO{

	private ArrayList<ActivityVO> arlActivityVO;

	public ArrayList<ActivityVO> getArlActivityVO() {
		return arlActivityVO;
	}

	public void setArlActivityVO(ArrayList<ActivityVO> arlActivityVO) {
		this.arlActivityVO = arlActivityVO;
	}

	
}
