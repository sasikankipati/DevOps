package com.uob.dashb.vo;

import java.util.ArrayList;

public class ActivityVO {

	private String groupId;
	private String groupName;
	private String appId;
	private String appName;
	private String activityDesc;
	private String activityId;
	private String taskActivityId;
	private String activityGroup;
	private String txnGroup;
	private String scheduleAt;
	private String givenTime;
	private String priority;
	private String daysOfWeek;
	private String status;
	private ArrayList<TaskDetailVO> arlTasks;
	private ArrayList<JobVO> arlJobs;
	private ArrayList<String> taskList;
	private ArrayList<String> jobList;
	private ArrayList<String> envList;
	private String environment;
	private boolean taskChecked;
	private boolean jobChecked;
	private boolean sendmail;
	
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getActivityDesc() {
		return activityDesc;
	}
	public void setActivityDesc(String activityDesc) {
		this.activityDesc = activityDesc;
	}
	public String getScheduleAt() {
		return scheduleAt;
	}
	public void setScheduleAt(String scheduleAt) {
		this.scheduleAt = scheduleAt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ArrayList<TaskDetailVO> getArlTasks() {
		return arlTasks;
	}
	public void setArlTasks(ArrayList<TaskDetailVO> arlTasks) {
		this.arlTasks = arlTasks;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getGivenTime() {
		return givenTime;
	}
	public void setGivenTime(String givenTime) {
		this.givenTime = givenTime;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDaysOfWeek() {
		return daysOfWeek;
	}
	public void setDaysOfWeek(String daysOfWeek) {
		this.daysOfWeek = daysOfWeek;
	}
	public ArrayList<String> getTaskList() {
		return taskList;
	}
	public void setTaskList(ArrayList<String> taskList) {
		this.taskList = taskList;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getTaskActivityId() {
		return taskActivityId;
	}
	public void setTaskActivityId(String taskActivityId) {
		this.taskActivityId = taskActivityId;
	}
	public String getActivityGroup() {
		return activityGroup;
	}
	public void setActivityGroup(String activityGroup) {
		this.activityGroup = activityGroup;
	}
	public ArrayList<String> getJobList() {
		return jobList;
	}
	public void setJobList(ArrayList<String> jobList) {
		this.jobList = jobList;
	}
	public boolean getTaskChecked() {
		return taskChecked;
	}
	public void setTaskChecked(boolean taskChecked) {
		this.taskChecked = taskChecked;
	}
	public boolean getJobChecked() {
		return jobChecked;
	}
	public void setJobChecked(boolean jobChecked) {
		this.jobChecked = jobChecked;
	}
	public boolean getSendmail() {
		return sendmail;
	}
	public void setSendmail(boolean sendmail) {
		this.sendmail = sendmail;
	}
	public ArrayList<String> getEnvList() {
		return envList;
	}
	public void setEnvList(ArrayList<String> envList) {
		this.envList = envList;
	}
	public ArrayList<JobVO> getArlJobs() {
		return arlJobs;
	}
	public void setArlJobs(ArrayList<JobVO> arlJobs) {
		this.arlJobs = arlJobs;
	}
	public String getTxnGroup() {
		return txnGroup;
	}
	public void setTxnGroup(String txnGroup) {
		this.txnGroup = txnGroup;
	}
	
}
