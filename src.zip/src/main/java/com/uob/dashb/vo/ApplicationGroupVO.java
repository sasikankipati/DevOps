package com.uob.dashb.vo;

import java.util.ArrayList;

public class ApplicationGroupVO {

	private String groupName;
	private String email;
	private String groupOwner;
	private String displayOrder;
	private String group_id;
	private ArrayList<ApplicationVO> arlApps;
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGroupOwner() {
		return groupOwner;
	}
	public void setGroupOwner(String groupOwner) {
		this.groupOwner = groupOwner;
	}
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getGroup_id() {
		return group_id;
	}
	public void setGroup_id(String group_id) {
		this.group_id = group_id;
	}
	public ArrayList<ApplicationVO> getArlApps() {
		return arlApps;
	}
	public void setArlApps(ArrayList<ApplicationVO> arlApps) {
		this.arlApps = arlApps;
	}
	
	
}
