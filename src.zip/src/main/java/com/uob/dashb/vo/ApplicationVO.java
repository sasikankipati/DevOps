package com.uob.dashb.vo;

public class ApplicationVO {

	private String appDesc;
	private String appOwner;
	private String group;
	private String appGroupId;
	private String asccAppCode;
	private String displayOrder;
	private String appId;
	private String appOwnerId;
	
	public String getAppDesc() {
		return appDesc;
	}
	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}
	public String getAppOwner() {
		return appOwner;
	}
	public void setAppOwner(String appOwner) {
		this.appOwner = appOwner;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getAsccAppCode() {
		return asccAppCode;
	}
	public void setAsccAppCode(String asccAppCode) {
		this.asccAppCode = asccAppCode;
	}
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getAppGroupId() {
		return appGroupId;
	}
	public void setAppGroupId(String appGroupId) {
		this.appGroupId = appGroupId;
	}
	public String getAppOwnerId() {
		return appOwnerId;
	}
	public void setAppOwnerId(String appOwnerId) {
		this.appOwnerId = appOwnerId;
	}
	
	
}
