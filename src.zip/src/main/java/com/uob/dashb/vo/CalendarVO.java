package com.uob.dashb.vo;


public class CalendarVO {

	private String title;
	private String type;
	private String startsAt;
	private String endsAt;
	private boolean draggable;
	private boolean resizable;
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStartsAt() {
		return startsAt;
	}
	public void setStartsAt(String startsAt) {
		this.startsAt = startsAt;
	}
	public String getEndsAt() {
		return endsAt;
	}
	public void setEndsAt(String endsAt) {
		this.endsAt = endsAt;
	}
	public boolean getDraggable() {
		return draggable;
	}
	public void setDraggable(boolean draggable) {
		this.draggable = draggable;
	}
	public boolean getResizable() {
		return resizable;
	}
	public void setResizable(boolean resizable) {
		this.resizable = resizable;
	}
	
	
	
	
}
