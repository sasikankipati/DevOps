package com.uob.dashb.vo;

import java.util.ArrayList;
import java.util.List;


public class CommonVO extends BaseVO{

	private ArrayList<ApplicationGroupVO> arlAppGroups;
	private ArrayList<ApplicationVO> arlApplications;
	private ArrayList<UserVO> arlUser;
	private ArrayList<UserRolesVO> arlUserRoles;
	private ApplicationGroupVO objApplicationGroupVO;
	private ApplicationVO objApplicationVO;
	private ArrayList<UserVO> arlUsersVO;
	private UserVO objUserVO;
	private ArrayList<UserApplicationGroupVO> arlUserAppGroup;
	private List<String> lsAppGroupIds;
	private ArrayList<TaskDetailVO> arlTaskDetailVO;
	private ActivityVO objActivityVO;
	private List<String> ragList;
	private List<String> envList;
	private ArrayList<JobVO> arlJobs;
	private ArrayList<JobDependencyVO> arlJobDependencyVO;
	private ArrayList<ActivityVO> arlPendingAct;
	private String errorCode;
	private ArrayList<CalendarVO> arlCalendarVO;
	private ArrayList<TestCaseVO> arlTestCases;
	private List<String> arlSeverity;
	private TestCaseVO objTestCaseVO;
	private ArrayList<EnvironmentVO> arlEnvironmentVO;
	private EnvironmentVO objEnvironmentVO;
	private ArrayList<TestScenarioVO> arlTestScenarioVO;
	private TestScenarioVO objTestScenarioVO;
	private ArrayList<SystemHealthChkVO> arlSystemHealthChk;
	private TaskDetailVO objTaskDetailVO;
	
	public ArrayList<ApplicationGroupVO> getArlAppGroups() {
		return arlAppGroups;
	}

	public void setArlAppGroups(ArrayList<ApplicationGroupVO> arlAppGroups) {
		this.arlAppGroups = arlAppGroups;
	}

	public ArrayList<ApplicationVO> getArlApplications() {
		return arlApplications;
	}

	public void setArlApplications(ArrayList<ApplicationVO> arlApplications) {
		this.arlApplications = arlApplications;
	}

	public ArrayList<UserVO> getArlUser() {
		return arlUser;
	}

	public void setArlUser(ArrayList<UserVO> arlUser) {
		this.arlUser = arlUser;
	}

	public ApplicationGroupVO getObjApplicationGroupVO() {
		return objApplicationGroupVO;
	}

	public void setObjApplicationGroupVO(ApplicationGroupVO objApplicationGroupVO) {
		this.objApplicationGroupVO = objApplicationGroupVO;
	}

	public ApplicationVO getObjApplicationVO() {
		return objApplicationVO;
	}

	public void setObjApplicationVO(ApplicationVO objApplicationVO) {
		this.objApplicationVO = objApplicationVO;
	}

	public ArrayList<UserVO> getArlUsersVO() {
		return arlUsersVO;
	}

	public void setArlUsersVO(ArrayList<UserVO> arlUsersVO) {
		this.arlUsersVO = arlUsersVO;
	}

	public UserVO getObjUserVO() {
		return objUserVO;
	}

	public void setObjUserVO(UserVO objUserVO) {
		this.objUserVO = objUserVO;
	}

	public ArrayList<UserApplicationGroupVO> getArlUserAppGroup() {
		return arlUserAppGroup;
	}

	public void setArlUserAppGroup(ArrayList<UserApplicationGroupVO> arlUserAppGroup) {
		this.arlUserAppGroup = arlUserAppGroup;
	}

	public List<String> getLsAppGroupIds() {
		return lsAppGroupIds;
	}

	public void setLsAppGroupIds(List<String> lsAppGroupIds) {
		this.lsAppGroupIds = lsAppGroupIds;
	}


	public ArrayList<UserRolesVO> getArlUserRoles() {
		return arlUserRoles;
	}

	public void setArlUserRoles(ArrayList<UserRolesVO> arlUserRoles) {
		this.arlUserRoles = arlUserRoles;
	}

	public ArrayList<TaskDetailVO> getArlTaskDetailVO() {
		return arlTaskDetailVO;
	}

	public void setArlTaskDetailVO(ArrayList<TaskDetailVO> arlTaskDetailVO) {
		this.arlTaskDetailVO = arlTaskDetailVO;
	}

	public ActivityVO getObjActivityVO() {
		return objActivityVO;
	}

	public void setObjActivityVO(ActivityVO objActivityVO) {
		this.objActivityVO = objActivityVO;
	}

	public List<String> getRagList() {
		return ragList;
	}

	public void setRagList(List<String> ragList) {
		this.ragList = ragList;
	}

	public ArrayList<JobVO> getArlJobs() {
		return arlJobs;
	}

	public void setArlJobs(ArrayList<JobVO> arlJobs) {
		this.arlJobs = arlJobs;
	}

	public ArrayList<JobDependencyVO> getArlJobDependencyVO() {
		return arlJobDependencyVO;
	}

	public void setArlJobDependencyVO(ArrayList<JobDependencyVO> arlJobDependencyVO) {
		this.arlJobDependencyVO = arlJobDependencyVO;
	}

	public ArrayList<ActivityVO> getArlPendingAct() {
		return arlPendingAct;
	}

	public void setArlPendingAct(ArrayList<ActivityVO> arlPendingAct) {
		this.arlPendingAct = arlPendingAct;
	}

	public List<String> getEnvList() {
		return envList;
	}

	public void setEnvList(List<String> envList) {
		this.envList = envList;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public ArrayList<CalendarVO> getArlCalendarVO() {
		return arlCalendarVO;
	}

	public void setArlCalendarVO(ArrayList<CalendarVO> arlCalendarVO) {
		this.arlCalendarVO = arlCalendarVO;
	}

	public ArrayList<TestCaseVO> getArlTestCases() {
		return arlTestCases;
	}

	public void setArlTestCases(ArrayList<TestCaseVO> arlTestCases) {
		this.arlTestCases = arlTestCases;
	}

	public List<String> getArlSeverity() {
		return arlSeverity;
	}

	public void setArlSeverity(List<String> arlSeverity) {
		this.arlSeverity = arlSeverity;
	}

	public TestCaseVO getObjTestCaseVO() {
		return objTestCaseVO;
	}

	public void setObjTestCaseVO(TestCaseVO objTestCaseVO) {
		this.objTestCaseVO = objTestCaseVO;
	}

	public ArrayList<EnvironmentVO> getArlEnvironmentVO() {
		return arlEnvironmentVO;
	}

	public void setArlEnvironmentVO(ArrayList<EnvironmentVO> arlEnvironmentVO) {
		this.arlEnvironmentVO = arlEnvironmentVO;
	}

	public EnvironmentVO getObjEnvironmentVO() {
		return objEnvironmentVO;
	}

	public void setObjEnvironmentVO(EnvironmentVO objEnvironmentVO) {
		this.objEnvironmentVO = objEnvironmentVO;
	}

	public ArrayList<TestScenarioVO> getArlTestScenarioVO() {
		return arlTestScenarioVO;
	}

	public void setArlTestScenarioVO(ArrayList<TestScenarioVO> arlTestScenarioVO) {
		this.arlTestScenarioVO = arlTestScenarioVO;
	}

	public TestScenarioVO getObjTestScenarioVO() {
		return objTestScenarioVO;
	}

	public void setObjTestScenarioVO(TestScenarioVO objTestScenarioVO) {
		this.objTestScenarioVO = objTestScenarioVO;
	}

	public ArrayList<SystemHealthChkVO> getArlSystemHealthChk() {
		return arlSystemHealthChk;
	}

	public void setArlSystemHealthChk(
			ArrayList<SystemHealthChkVO> arlSystemHealthChk) {
		this.arlSystemHealthChk = arlSystemHealthChk;
	}

	public TaskDetailVO getObjTaskDetailVO() {
		return objTaskDetailVO;
	}

	public void setObjTaskDetailVO(TaskDetailVO objTaskDetailVO) {
		this.objTaskDetailVO = objTaskDetailVO;
	}

	 
}
