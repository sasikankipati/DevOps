package com.uob.dashb.vo;


public class CountryVO {

	private String red = "0";
	private String green = "0";
	private String amber = "0";
	private String country;
	
	public String getRed() {
		return red;
	}
	public void setRed(String red) {
		this.red = red;
	}
	public String getGreen() {
		return green;
	}
	public void setGreen(String green) {
		this.green = green;
	}
	public String getAmber() {
		return amber;
	}
	public void setAmber(String amber) {
		this.amber = amber;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	
}
