package com.uob.dashb.vo;



public class EnvironmentVO {
	
	private int environment_id;
	private String env_id;
	private String env_name;
	private String env_desc;
	private String rec_status;
	private String remarks;
	private String country;
	
	private Integer totalCnt;
	private Integer completedCnt;
	private String red = "0";
	private String green = "0";
	private String amber = "0";

	public int getEnvironment_id() {
		return environment_id;
	}

	public void setEnvironment_id(int environment_id) {
		this.environment_id = environment_id;
	}

	public String getEnv_id() {
		return env_id;
	}

	public void setEnv_id(String env_id) {
		this.env_id = env_id;
	}

	public String getEnv_name() {
		return env_name;
	}

	public void setEnv_name(String env_name) {
		this.env_name = env_name;
	}

	public String getEnv_desc() {
		return env_desc;
	}

	public void setEnv_desc(String env_desc) {
		this.env_desc = env_desc;
	}

	public String getRec_status() {
		return rec_status;
	}

	public void setRec_status(String rec_status) {
		this.rec_status = rec_status;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Integer getTotalCnt() {
		return totalCnt;
	}

	public void setTotalCnt(Integer totalCnt) {
		this.totalCnt = totalCnt;
	}

	public Integer getCompletedCnt() {
		return completedCnt;
	}

	public void setCompletedCnt(Integer completedCnt) {
		this.completedCnt = completedCnt;
	}

	public String getRed() {
		return red;
	}

	public void setRed(String red) {
		this.red = red;
	}

	public String getGreen() {
		return green;
	}

	public void setGreen(String green) {
		this.green = green;
	}

	public String getAmber() {
		return amber;
	}

	public void setAmber(String amber) {
		this.amber = amber;
	}
	
}
