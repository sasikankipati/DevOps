package com.uob.dashb.vo;

public class JobDependencyVO {

	private int jobMasterId;
	private String jobName;
	private String upstreamDependency;
	private String downstreamDependency;
	private String impact;
	private String remarks;
	
	
	public int getJobMasterId() {
		return jobMasterId;
	}
	public void setJobMasterId(int jobMasterId) {
		this.jobMasterId = jobMasterId;
	}
	public String getUpstreamDependency() {
		return upstreamDependency;
	}
	public void setUpstreamDependency(String upstreamDependency) {
		this.upstreamDependency = upstreamDependency;
	}
	public String getDownstreamDependency() {
		return downstreamDependency;
	}
	public void setDownstreamDependency(String downstreamDependency) {
		this.downstreamDependency = downstreamDependency;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
}
