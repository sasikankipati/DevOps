package com.uob.dashb.vo;

import java.util.ArrayList;

public class JobVO {

	private String act_tnx_id;
	private String groupName;
	private String appName;
	private String jobName;
	private String orderDate;
	private String jobDesc;
	private String standardStartTime;
	private String standardEndTime;
	private String actualStartTime;
	private String actualEndTime;
	private String dropDeadTime;
	private String frequency;
	private String daysOfWeek;
	private String upstreamDependency;
	private String downstreamDependency;
	private String impact;
	private String remarks;
	private String status;
	private ArrayList<JobDependencyVO> arlDependents;
	private String jobMasterId;
	private boolean checked;
	private String eachLine;
	
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	public String getJobDesc() {
		return jobDesc;
	}
	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}
	public String getStandardStartTime() {
		return standardStartTime;
	}
	public void setStandardStartTime(String standardStartTime) {
		this.standardStartTime = standardStartTime;
	}
	public String getStandardEndTime() {
		return standardEndTime;
	}
	public void setStandardEndTime(String standardEndTime) {
		this.standardEndTime = standardEndTime;
	}
	public String getDropDeadTime() {
		return dropDeadTime;
	}
	public void setDropDeadTime(String dropDeadTime) {
		this.dropDeadTime = dropDeadTime;
	}
	public String getFrequency() {
		return frequency;
	}
	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}
	public String getDaysOfWeek() {
		return daysOfWeek;
	}
	public void setDaysOfWeek(String daysOfWeek) {
		this.daysOfWeek = daysOfWeek;
	}
	public String getUpstreamDependency() {
		return upstreamDependency;
	}
	public void setUpstreamDependency(String upstreamDependency) {
		this.upstreamDependency = upstreamDependency;
	}
	public String getDownstreamDependency() {
		return downstreamDependency;
	}
	public void setDownstreamDependency(String downstreamDependency) {
		this.downstreamDependency = downstreamDependency;
	}
	public String getImpact() {
		return impact;
	}
	public void setImpact(String impact) {
		this.impact = impact;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public ArrayList<JobDependencyVO> getArlDependents() {
		return arlDependents;
	}
	public void setArlDependents(ArrayList<JobDependencyVO> arlDependents) {
		this.arlDependents = arlDependents;
	}
	public String getJobMasterId() {
		return jobMasterId;
	}
	public void setJobMasterId(String jobMasterId) {
		this.jobMasterId = jobMasterId;
	}
	public boolean getChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public String getActualStartTime() {
		return actualStartTime;
	}
	public void setActualStartTime(String actualStartTime) {
		this.actualStartTime = actualStartTime;
	}
	public String getActualEndTime() {
		return actualEndTime;
	}
	public void setActualEndTime(String actualEndTime) {
		this.actualEndTime = actualEndTime;
	}
	public String getAct_tnx_id() {
		return act_tnx_id;
	}
	public void setAct_tnx_id(String act_tnx_id) {
		this.act_tnx_id = act_tnx_id;
	}
	public String getEachLine() {
		return eachLine;
	}
	public void setEachLine(String eachLine) {
		this.eachLine = eachLine;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	
	
}
