package com.uob.dashb.vo;

import java.security.Timestamp;

public class NewActivityVO {

	private int task_activity_id;
	private int task_id;
	private int job_master_id;
	private int activity_id; 
	private int group_id;
	private String app_id;
	private String start_time;
	private String minutes;
	private String priority;
	private String day_of_week;
	private int activitygroup;
	private String scheduledOn;
	private String toBeCompletedBy;
	private String createdOn;
	private String createdBy;
	private int txngroup;

	public int getTask_activity_id() {
		return task_activity_id;
	}
	public void setTask_activity_id(int task_activity_id) {
		this.task_activity_id = task_activity_id;
	}
	public int getTask_id() {
		return task_id;
	}
	public void setTask_id(int task_id) {
		this.task_id = task_id;
	}
	public int getJob_master_id() {
		return job_master_id;
	}
	public void setJob_master_id(int job_master_id) {
		this.job_master_id = job_master_id;
	}
	public int getActivity_id() {
		return activity_id;
	}
	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}
	public int getGroup_id() {
		return group_id;
	}
	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}
	public String getApp_id() {
		return app_id;
	}
	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getMinutes() {
		return minutes;
	}
	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getDay_of_week() {
		return day_of_week;
	}
	public void setDay_of_week(String day_of_week) {
		this.day_of_week = day_of_week;
	}
	public int getActivitygroup() {
		return activitygroup;
	}
	public void setActivitygroup(int activitygroup) {
		this.activitygroup = activitygroup;
	}
	public String getScheduledOn() {
		return scheduledOn;
	}
	public void setScheduledOn(String scheduledOn) {
		this.scheduledOn = scheduledOn;
	}
	public String getToBeCompletedBy() {
		return toBeCompletedBy;
	}
	public void setToBeCompletedBy(String toBeCompletedBy) {
		this.toBeCompletedBy = toBeCompletedBy;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public int getTxngroup() {
		return txngroup;
	}
	public void setTxngroup(int txngroup) {
		this.txngroup = txngroup;
	}
	
}
