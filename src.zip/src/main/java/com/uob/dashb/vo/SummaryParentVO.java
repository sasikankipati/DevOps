package com.uob.dashb.vo;

import java.util.ArrayList;


public class SummaryParentVO extends BaseVO {

	private ArrayList<SummaryVO> arlSummary = new ArrayList<SummaryVO>();
	
	public ArrayList<SummaryVO> getArlSummary() {
		return arlSummary;
	}
	public void setArlSummary(ArrayList<SummaryVO> arlSummary) {
		this.arlSummary = arlSummary;
	}
	
}
