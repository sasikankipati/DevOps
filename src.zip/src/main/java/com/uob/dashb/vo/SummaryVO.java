package com.uob.dashb.vo;


public class SummaryVO {

	private String groupId;
	private String application;
	private String lastActivity;
	private String latestActivity;
	private String status;
	
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getLastActivity() {
		return lastActivity;
	}
	public void setLastActivity(String lastActivity) {
		this.lastActivity = lastActivity;
	}
	public String getLatestActivity() {
		return latestActivity;
	}
	public void setLatestActivity(String latestActivity) {
		this.latestActivity = latestActivity;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	
}
