package com.uob.dashb.vo;

import java.io.Serializable;
import java.security.Timestamp;
import java.util.ArrayList;

public class SystemHealthChkVO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String appId;
	private int appGroupId;
	private String status;
	private String country;	
	private Timestamp status_on;
	private String env;
	
	private String scenario_id;
	private String case_id;
	private String exec_date;
	private String exec_time;
	private String noOfTestScenarios;
	
	private String count;
	private Integer totalCnt;
	private Integer completedCnt;
	private ArrayList<CountryVO> arlCountries;
	private ArrayList<EnvironmentVO> arlEnv;
	
	@Override
	public String toString() {
		return "SystemHealthChkVO [appId=" + appId + ", appGroupId="
				+ appGroupId + ", status=" + status + ", country=" + country
				+ ", status_on=" + status_on + "]";
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public int getAppGroupId() {
		return appGroupId;
	}

	public void setAppGroupId(int appGroupId) {
		this.appGroupId = appGroupId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public Timestamp getStatus_on() {
		return status_on;
	}

	public void setStatus_on(Timestamp status_on) {
		this.status_on = status_on;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getScenario_id() {
		return scenario_id;
	}

	public void setScenario_id(String scenario_id) {
		this.scenario_id = scenario_id;
	}

	public String getCase_id() {
		return case_id;
	}

	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}

	public String getExec_date() {
		return exec_date;
	}

	public void setExec_date(String exec_date) {
		this.exec_date = exec_date;
	}

	public String getExec_time() {
		return exec_time;
	}

	public void setExec_time(String exec_time) {
		this.exec_time = exec_time;
	}

	public String getNoOfTestScenarios() {
		return noOfTestScenarios;
	}

	public void setNoOfTestScenarios(String noOfTestScenarios) {
		this.noOfTestScenarios = noOfTestScenarios;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public ArrayList<CountryVO> getArlCountries() {
		return arlCountries;
	}

	public void setArlCountries(ArrayList<CountryVO> arlCountries) {
		this.arlCountries = arlCountries;
	}

	public Integer getTotalCnt() {
		return totalCnt;
	}

	public void setTotalCnt(Integer totalCnt) {
		this.totalCnt = totalCnt;
	}

	public Integer getCompletedCnt() {
		return completedCnt;
	}

	public void setCompletedCnt(Integer completedCnt) {
		this.completedCnt = completedCnt;
	}

	public ArrayList<EnvironmentVO> getArlEnv() {
		return arlEnv;
	}

	public void setArlEnv(ArrayList<EnvironmentVO> arlEnv) {
		this.arlEnv = arlEnv;
	}


	
}
