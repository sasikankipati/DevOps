package com.uob.dashb.vo;

public class TaskDetailVO {

	private String act_tnx_id;
	private String taskId;
	private String taskDesc;
	private String groupId;
	private String groupDesc;
	private String recStatus;
	private boolean checked;
	private String taskActivityId;
	private String remarks;
	private boolean completed;
	private String status;
	private boolean forceOk;
	private String forceOkReason;
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getTaskDesc() {
		return taskDesc;
	}
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupDesc() {
		return groupDesc;
	}
	public void setGroupDesc(String groupDesc) {
		this.groupDesc = groupDesc;
	}
	public boolean getChecked() {
		return checked;
	}
	public void setChecked(boolean checked) {
		this.checked = checked;
	}
	public String getRecStatus() {
		return recStatus;
	}
	public void setRecStatus(String recStatus) {
		this.recStatus = recStatus;
	}
	public String getTaskActivityId() {
		return taskActivityId;
	}
	public void setTaskActivityId(String taskActivityId) {
		this.taskActivityId = taskActivityId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public boolean getCompleted() {
		return completed;
	}
	public void setCompleted(boolean completed) {
		this.completed = completed;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean getForceOk() {
		return forceOk;
	}
	public void setForceOk(boolean forceOk) {
		this.forceOk = forceOk;
	}
	public String getForceOkReason() {
		return forceOkReason;
	}
	public void setForceOkReason(String forceOkReason) {
		this.forceOkReason = forceOkReason;
	}
	public String getAct_tnx_id() {
		return act_tnx_id;
	}
	public void setAct_tnx_id(String act_tnx_id) {
		this.act_tnx_id = act_tnx_id;
	}
	
	
}
