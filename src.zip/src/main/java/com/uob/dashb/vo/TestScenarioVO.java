package com.uob.dashb.vo;

import java.util.ArrayList;



public class TestScenarioVO {
	
	private int test_scenario_id;
	private String scenario_id;
	private String scenario_desc;
	private String case_id;
	private String env_id;
	private String app_id;
	private ArrayList<String> testCases;

	public int getTest_scenario_id() {
		return test_scenario_id;
	}

	public void setTest_scenario_id(int test_scenario_id) {
		this.test_scenario_id = test_scenario_id;
	}

	public String getScenario_id() {
		return scenario_id;
	}

	public void setScenario_id(String scenario_id) {
		this.scenario_id = scenario_id;
	}

	public String getScenario_desc() {
		return scenario_desc;
	}

	public void setScenario_desc(String scenario_desc) {
		this.scenario_desc = scenario_desc;
	}

	public String getCase_id() {
		return case_id;
	}

	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}

	public String getEnv_id() {
		return env_id;
	}

	public void setEnv_id(String env_id) {
		this.env_id = env_id;
	}

	public String getApp_id() {
		return app_id;
	}

	public void setApp_id(String app_id) {
		this.app_id = app_id;
	}

	public ArrayList<String> getTestCases() {
		return testCases;
	}

	public void setTestCases(ArrayList<String> testCases) {
		this.testCases = testCases;
	}

}
