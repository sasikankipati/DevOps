package com.uob.dashb.vo;

import java.util.ArrayList;


public class User {

	private int userId;
	
	private String username;
	
	
	private String password;
	private String role;
	private String status;
	private String email;
	private String lanid;
	private String phone;
	private boolean success;
	private boolean admin;
	private ArrayList<ActivityVO> arlPendAct;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLanid() {
		return lanid;
	}
	public void setLanid(String lanid) {
		this.lanid = lanid;
	}
	
	
	@Override
	public String toString(){
		return "{}";
	}
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public boolean getAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public ArrayList<ActivityVO> getArlPendAct() {
		return arlPendAct;
	}
	public void setArlPendAct(ArrayList<ActivityVO> arlPendAct) {
		this.arlPendAct = arlPendAct;
	}
	
	public String validate(){
		String errorMsg ="";
		
		if(username == null || username.length() > 6){
			errorMsg = "Login not successful, UserName validation error ...!";
		}else if(password == null || password.length() > 100){
			errorMsg = "Login not successful, Password validation error ...!";
		}
		
		return errorMsg;
	}
	
}
