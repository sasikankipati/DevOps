package com.uob.dashb.vo;

public class UserApplicationGroupVO {

	private String userAppGroupId;
	private String appGroupId;
	private String userId;
	
	public String getUserAppGroupId() {
		return userAppGroupId;
	}
	public void setUserAppGroupId(String userAppGroupId) {
		this.userAppGroupId = userAppGroupId;
	}
	public String getAppGroupId() {
		return appGroupId;
	}
	public void setAppGroupId(String appGroupId) {
		this.appGroupId = appGroupId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
