package com.uob.dashb.vo;

import java.util.List;

public class UserVO {
	
	private String userId;
	private String userName;
	private String password;
	private String email;
	private String lanId;
	private String mobile;
	private String appGroupIds;
	private List<String> lsAppGroupIds;
	private boolean admin;
	private String role;
	private String roleDesc;
	private String curPassword;
	private String newPassword;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getLanId() {
		return lanId;
	}
	public void setLanId(String lanId) {
		this.lanId = lanId;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAppGroupIds() {
		return appGroupIds;
	}
	public void setAppGroupIds(String appGroupIds) {
		this.appGroupIds = appGroupIds;
	}
	public List<String> getLsAppGroupIds() {
		return lsAppGroupIds;
	}
	public void setLsAppGroupIds(List<String> lsAppGroupIds) {
		this.lsAppGroupIds = lsAppGroupIds;
	}
	public boolean getAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getRoleDesc() {
		return roleDesc;
	}
	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}
	public String getCurPassword() {
		return curPassword;
	}
	public void setCurPassword(String curPassword) {
		this.curPassword = curPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	

}
