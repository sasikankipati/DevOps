﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('FillActivityController', FillActivityController);

    FillActivityController.$inject = ['$location', 'ActivitiesService', 'FlashService','$routeParams'];
    function FillActivityController($location, ActivitiesService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateFilledActivity = updateFilledActivity;
        
        vm.dataLoading = true;
        ActivitiesService.actOnActivity($scope.param1,function (response) {
            if (response.success) {
            	 vm.arlTaskDetailVO = response.arlTaskDetailVO;
            	 vm.arlAppGroups = response.arlAppGroups;
            	 vm.arlJobs = response.arlJobs;
            	 vm.envList = response.envList;
            	 vm.objActivityVO = response.objActivityVO;
            	 vm.ragList = response.ragList;
            	 vm.activityDesc = vm.objActivityVO.activityDesc;
            	 vm.groupId = vm.objActivityVO.groupId;
            	 vm.appId = vm.objActivityVO.appId;
            	 vm.scheduleAt = vm.objActivityVO.scheduleAt;
            	 vm.taskChecked = vm.objActivityVO.taskChecked;
            	 vm.jobChecked = vm.objActivityVO.jobChecked;
            	 ActivitiesService.setRadio(vm.objActivityVO);
            	 vm.environment = vm.objActivityVO.environment;
            	 vm.activityGroup = vm.objActivityVO.activityGroup;
            	 vm.dataLoading = false;
            	 /*var c;
            	 var x =0;
            	 for (x = 0; x < vm.daysOfWeek.length; x = x+1) {
            	     c = vm.daysOfWeek.charAt(x);
            	     if(x == 0){
            	    	 vm.monday = selected(c);
            	     }else if(x == 1){
            	    	 vm.tuesday = selected(c);
            	     }else if(x == 2){
            	    	 vm.wednesday = selected(c);
            	     }else if(x == 3){
            	    	 vm.thrusday = selected(c);
            	     }else if(x == 4){
            	    	 vm.friday = selected(c);
            	     }else if(x == 5){
            	    	 vm.saturday = selected(c);
            	     }else if(x == 6){
            	    	 vm.sunday = selected(c);
            	     }
            	 }*/
            	 
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        
        function selected(c){
       	 if(c == '0'){
	    		 return false;
	    	 }else{
	    		 return true;
	    	 }
        }
        
        function updateFilledActivity(){
        	var i=0;
        	/*var taskList=[];
        	
        	//vm.sendmail
        	
        	for(i = 0; i< vm.arlTaskDetailVO.length;i++ ){
        		if(vm.arlTaskDetailVO[i].checked){
        			taskList.push(vm.arlTaskDetailVO[i].taskId);
        		}
        	}*/
        	vm.dataLoading = true;
        	 var formData = {
        			 activityDesc: vm.activityDesc,
        			 activityGroup: vm.activityGroup,
        			 groupId: vm.groupId,
        			 appId: vm.appId,
        			 scheduleAt: vm.scheduleAt,
        			 givenTime: vm.givenTime,
        			 priority: vm.priority,
        			 daysOfWeek: vm.daysOfWeek,
        			 arlTasks: vm.arlTaskDetailVO,
        			 jobList: vm.arlJobs,
        			 environment: vm.environment,
        			 sendmail: vm.sendmail
              };
             ActivitiesService.updateFilledActivity(formData,function (response) {
                 if (response.success) {
                	 ActivitiesService.setPendingList(response.arlPendingAct);
                	 vm.dataLoading = false;
                 	$location.path('/showActivities'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
        
    }

})();
