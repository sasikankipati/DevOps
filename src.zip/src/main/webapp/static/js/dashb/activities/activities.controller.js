﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ActivitiesController', ActivitiesController);

    ActivitiesController.$inject = ['$location', 'ActivitiesService', 'FlashService'];
    function ActivitiesController($location, ActivitiesService, FlashService,$scope) {
        var vm = this;

        vm.dataLoading = true;
        ActivitiesService.fetchAllActivities(function (response) {
            if (response.success) {
            	ActivitiesService.setValues(response.arlActivityVO);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
