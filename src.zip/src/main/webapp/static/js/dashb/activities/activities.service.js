﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('ActivitiesService', ActivitiesService);

    ActivitiesService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function ActivitiesService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllActivities = fetchAllActivities;
        service.fetchNewActivityInfo = fetchNewActivityInfo;
        service.actOnActivity = actOnActivity;
        service.setValues = setValues;
        service.viewSelectedActivity = viewSelectedActivity;
        service.setPassValues = setPassValues;
        service.submitActivity = submitActivity;
        service.saveActivity = saveActivity;
        service.updateActivity = updateActivity;
        service.updateFilledActivity = updateFilledActivity;
        service.arlTaskDetailVO={};
        service.arlAppGroups={};
        service.objActivityVO={};
        service.arlJobs={};
        service.setShowHide=setShowHide;
        service.getPendActions=getPendActions;
        service.setRadio = setRadio;
        service.setPendingList = setPendingList;
        service.fetchActivityHistory = fetchActivityHistory;
        service.setArlGroups = setArlGroups;
        return service;

        function setArlGroups(arlAppGroups){
        	$rootScope.arlAppGroups = arlAppGroups;
        }
        
        $rootScope.getGroupChange = function(groupId){
        	alert(groupId);
        };
        
        
        function setRadio(objActivityVO){
        	if(objActivityVO.taskChecked){
        		$rootScope.showHideTest = false;
        	}else{
        		$rootScope.showHideTest = true;
        	}
        }
        
        
        function updateFilledActivity(formData,callback) {
            $http.post('/DashBoard/updateFilledActivity',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function actOnActivity(formData,callback) {
            $http.post('/DashBoard/actOnActivity',{txnGroup : formData})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function updateActivity(formData,callback) {
            $http.post('/DashBoard/updateActivity',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewSelectedActivity(formData,callback) {
            $http.post('/DashBoard/viewSelectedActivity',{activityGroup : formData})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function saveActivity(formData,callback) {
            $http.post('/DashBoard/saveActivity',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function submitActivity(formData,callback) {
            $http.post('/DashBoard/submitActivity',formData)
                .success(function (response) {
                    callback(response);
            });
        }

        
        function fetchActivityHistory(callback) {
            $http.post('/DashBoard/fetchActivityHistory')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllActivities(callback) {
            $http.post('/DashBoard/fetchAllActivities')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchNewActivityInfo(callback) {
            $http.post('/DashBoard/fetchNewActivityInfo')
                .success(function (response) {
                    callback(response);
            });
        }

        function setValues(arlActivityVO) {
        	$rootScope.arlActivity=arlActivityVO;
        }

        function setShowHide(){
     	   $rootScope.showHideTest=false;
        }
        
        function setPassValues(response){
        	$rootScope.arlTaskDetailVO = response.arlTaskDetailVO;
        	$rootScope.arlAppGroups = response.arlAppGroups; 
        	$rootScope.objActivityVO = response.objActivityVO;
        }
        
        function setPendingList(arlPendAct){
        	$rootScope.arlPendAct=arlPendAct;
        }
        
        function getPassValues(){
        	$rootScope.arlTaskDetailVO = response.arlTaskDetailVO;
        	$rootScope.arlAppGroups = response.arlAppGroups; 
        	$rootScope.objActivityVO = response.objActivityVO;
        }
        
        function getPendActions(arlPendAct){
        	$rootScope.arlPendAct=arlPendAct;
        	$rootScope.pendAlert=arlPendAct.length;
        }
    }


})();