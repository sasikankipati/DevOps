﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewActivityController', NewActivityController);

    NewActivityController.$inject = ['$location', 'ActivitiesService', 'FlashService'];
    function NewActivityController($location, ActivitiesService, FlashService,$scope) {
        var vm = this;
        vm.submitActivity = submitActivity;
        
        vm.dataLoading = true;
        ActivitiesService.fetchNewActivityInfo(function (response) {
            if (response.success) {
            	ActivitiesService.setArlGroups(response.arlAppGroups);
            	vm.arlAppGroups = response.arlAppGroups;
            	vm.dataLoading = false;
            	vm.envList = response.envList;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });

        function selectedVal(bol){
        	if(bol){
        		return "1";
        	}else{
        		return "0";
        	}
        }
        
        function submitActivity(){
        	
        	var days = "";
        	
        	days = days+selectedVal(vm.monday);
        	days = days+selectedVal(vm.tuesday);
        	days = days+selectedVal(vm.wednesday);
        	days = days+selectedVal(vm.thrusday);
        	days = days+selectedVal(vm.friday);
        	days = days+selectedVal(vm.saturday);
        	days = days+selectedVal(vm.sunday);
        	
        	 var formData = {
        			 activityDesc: vm.activityDesc,
        			 groupId: vm.groupId.group_id,
        			 appId: vm.appId.appId,
        			 scheduleAt: vm.scheduleAt,
        			 givenTime: vm.givenTime,
        			 priority: vm.priority,
        			 taskChecked: vm.taskChecked,
        			 jobChecked: vm.jobChecked,
        			 environment: vm.environment,
        			 daysOfWeek: days
              };
             vm.dataLoading = true;
             ActivitiesService.submitActivity(formData,function (response) {
                 if (response.success) {
                	 
                	 ActivitiesService.setPassValues(response);
                	 ActivitiesService.arlJobs = response.arlJobs;
                	 ActivitiesService.arlTaskDetailVO = response.arlTaskDetailVO;
                	 ActivitiesService.arlAppGroups = response.arlAppGroups; 
                	 ActivitiesService.objActivityVO = response.objActivityVO;
                	 ActivitiesService.envList = response.envList;
                	 ActivitiesService.setShowHide();
                	 vm.dataLoading = false;
                	 $location.path('/showTaskSelection'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
        
       /* $scope.getGroupChange = function(){
            ActivitiesService.getGroupChange(vm.groupId);
        };
        */
    }

})();
