﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewActivityTaskController', NewActivityTaskController);

    NewActivityTaskController.$inject = ['$location', 'ActivitiesService', 'FlashService','$routeParams'];
    function NewActivityTaskController($location, ActivitiesService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.saveActivity = saveActivity;
        
         (function initController() {
        	 vm.dataLoading = true;
        	 vm.arlTaskDetailVO = ActivitiesService.arlTaskDetailVO;
        	 vm.arlAppGroups = ActivitiesService.arlAppGroups;
        	 vm.objActivityVO = ActivitiesService.objActivityVO;
        	 vm.arlJobs = ActivitiesService.arlJobs;
        	 vm.activityDesc = vm.objActivityVO.activityDesc;
        	 vm.groupId = vm.objActivityVO.groupId;
        	 vm.appId = vm.objActivityVO.appId;
        	 vm.scheduleAt = vm.objActivityVO.scheduleAt;
        	 vm.givenTime = vm.objActivityVO.givenTime;
        	 vm.priority = vm.objActivityVO.priority;
        	 vm.daysOfWeek = vm.objActivityVO.daysOfWeek;
        	 vm.taskChecked = vm.objActivityVO.taskChecked;
        	 vm.jobChecked = vm.objActivityVO.jobChecked;
        	 ActivitiesService.setRadio(vm.objActivityVO);
        	 vm.environment = vm.objActivityVO.environment;
        	 vm.envList = ActivitiesService.envList;
        	 
        	 var c;
        	 var x =0;
        	 for (x = 0; x < vm.daysOfWeek.length; x = x+1) {
        	     c = vm.daysOfWeek.charAt(x);
        	     if(x == 0){
        	    	 vm.monday = selected(c);
        	     }else if(x == 1){
        	    	 vm.tuesday = selected(c);
        	     }else if(x == 2){
        	    	 vm.wednesday = selected(c);
        	     }else if(x == 3){
        	    	 vm.thrusday = selected(c);
        	     }else if(x == 4){
        	    	 vm.friday = selected(c);
        	     }else if(x == 5){
        	    	 vm.saturday = selected(c);
        	     }else if(x == 6){
        	    	 vm.sunday = selected(c);
        	     }
        	 }
        	 vm.dataLoading = false;
        })();
        
         function selected(c){
        	 if(c == '0'){
	    		 return false;
	    	 }else{
	    		 return true;
	    	 }
         }
        
         function selectedVal(bol){
         	if(bol){
         		return "1";
         	}else{
         		return "0";
         	}
         }
         
        function saveActivity(){
        	var i=0;
        	var taskList=[];
        	var jobList=[];
        	
        	for(i = 0; i< vm.arlTaskDetailVO.length;i++ ){
        		if(vm.arlTaskDetailVO[i].checked){
        			taskList.push(vm.arlTaskDetailVO[i].taskId);
        		}
        	}
        	
        	for(i = 0; i< vm.arlJobs.length;i++ ){
        		if(vm.arlJobs[i].checked){
        			jobList.push(vm.arlJobs[i].jobMasterId);
        		}
        	}
        	
        	var days = "";
        	
        	days = days+selectedVal(vm.monday);
        	days = days+selectedVal(vm.tuesday);
        	days = days+selectedVal(vm.wednesday);
        	days = days+selectedVal(vm.thrusday);
        	days = days+selectedVal(vm.friday);
        	days = days+selectedVal(vm.saturday);
        	days = days+selectedVal(vm.sunday);
        	
	    	 var formData = {
	    			 activityDesc: vm.activityDesc,
	    			 groupId: vm.groupId,
	    			 appId: vm.appId,
	    			 scheduleAt: vm.scheduleAt,
	    			 givenTime: vm.givenTime,
	    			 priority: vm.priority,
	    			 daysOfWeek: days,
	    			 taskList: taskList,
	    			 jobList: jobList,
	    			 environment: vm.environment
	          };
	    	 
	         vm.dataLoading = true;
	         ActivitiesService.saveActivity(formData,function (response) {
	             if (response.success) {
	            	 vm.dataLoading = false;
	             	$location.path('/showActivities'); 
	             } else {
	                 FlashService.Error(response.message);
	                 vm.dataLoading = false;
	             }
	         });
        };
        
    }

})();
