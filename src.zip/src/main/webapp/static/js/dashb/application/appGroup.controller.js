﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('AppGroupController', AppGroupController);

    AppGroupController.$inject = ['$location', 'AppGroupService', 'FlashService'];
    function AppGroupController($location, AppGroupService, FlashService,$scope) {
        var vm = this;

        
        AppGroupService.fetchAllAppGroups(function (response) {
            if (response.success) {
            	AppGroupService.setValues(response.arlAppGroups);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
