﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('AppGroupService', AppGroupService);

    AppGroupService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function AppGroupService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllAppGroups = fetchAllAppGroups;
        service.setValues = setValues;
        
        return service;

        function fetchAllAppGroups(callback) {
            $http.post('/DashBoard/fetchAllAppGroups')
                .success(function (response) {
                    callback(response);
            });
        }
        

        function setValues(arlAppGroups) {
        	$rootScope.arlAppGroups=arlAppGroups;
        }

    }


})();