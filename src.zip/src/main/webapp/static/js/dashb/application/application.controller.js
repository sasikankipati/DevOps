﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ApplicationController', ApplicationController);

    ApplicationController.$inject = ['$location', 'ApplicationService', 'FlashService'];
    function ApplicationController($location, ApplicationService, FlashService,$scope) {
        var vm = this;

        
        ApplicationService.fetchAllApplications(function (response) {
            if (response.success) {
            	ApplicationService.setValues(response.arlApplications);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
