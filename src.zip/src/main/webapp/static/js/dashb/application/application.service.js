﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('ApplicationService', ApplicationService);

    ApplicationService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function ApplicationService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllApplications = fetchAllApplications;
        service.setValues = setValues;
        service.viewApplication=viewApplication;
        service.updateApplication = updateApplication;
        service.saveNewApplication = saveNewApplication;
        service.newApplication = newApplication;
        
        return service;

        
        function newApplication(callback) {
            $http.post('/DashBoard/newApplication')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function saveNewApplication(formData,callback) {
            $http.post('/DashBoard/saveNewApplication',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function updateApplication(formData,callback) {
            $http.post('/DashBoard/updateApplication',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewApplication(param1,callback){
        	 $http.post('/DashBoard/viewApplication',{appId : param1})
             	.success(function (response) {
             		callback(response);
             });
        }
        
        function fetchAllApplications(callback) {
            $http.post('/DashBoard/fetchAllApplications')
                .success(function (response) {
                    callback(response);
            });
        }
        

        function setValues(arlApplications) {
        	$rootScope.arlApplications=arlApplications;
        }

    }


})();