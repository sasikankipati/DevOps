﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewApplicationController', NewApplicationController);

    NewApplicationController.$inject = ['$location', 'ApplicationService', 'FlashService'];
    function NewApplicationController($location, ApplicationService, FlashService,$scope) {
        var vm = this;
        vm.saveNewApplication = saveNewApplication;
        
        
        (function initController() {
        	ApplicationService.newApplication(function (response) {
                if (response.success) {
                	vm.arlAppGroups = response.arlAppGroups;
                	vm.arlUsersVO = response.arlUsersVO;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        function saveNewApplication() {
        	var formData = {
        			appId: vm.appId,
        			appDesc: vm.appDesc,
        			appOwner: vm.appOwner,
        			asccAppCode: vm.asccAppCode,
        			appGroupId: vm.group_id,
        			appOwnerId: vm.appOwnerId,
              		displayOrder: vm.displayOrder
              };
             vm.dataLoading = true;
             ApplicationService.saveNewApplication(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showApplications'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
