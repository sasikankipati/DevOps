﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewAppGroupController', NewAppGroupController);

    NewAppGroupController.$inject = ['$location', 'NewAppGroupService', 'FlashService'];
    function NewAppGroupController($location, NewAppGroupService, FlashService,$scope) {
        var vm = this;
        vm.saveNewAppGroup = saveNewAppGroup;
        
        
        (function initController() {
        	NewAppGroupService.ClearValues();
        })();
        
        function saveNewAppGroup() {
        	 var formData = {
             		groupName: vm.groupName,
             		email: vm.email,
             		groupOwner: vm.groupOwner,
             		displayOrder: vm.displayOrder
             };
            vm.dataLoading = true;
            NewAppGroupService.saveNewAppGroup(formData,function (response) {
                if (response.success) {
                	//NewAppGroupService.setValues(response.arlApplications);
                	$location.path('/showApplicationGroup'); 
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        };
    }

})();
