﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('NewAppGroupService', NewAppGroupService);

    NewAppGroupService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function NewAppGroupService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.ClearValues = ClearValues;
        service.saveNewAppGroup = saveNewAppGroup;
        service.setValues = setValues;
        
        return service;

        function saveNewAppGroup(formData,callback) {
            $http.post('/DashBoard/saveNewAppGroup',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function ClearValues() {
        	$rootScope.appGroupFB={};
        }
        
        function setValues(arlApplications) {
        	$rootScope.arlApplications=arlApplications;
        }

    }


})();