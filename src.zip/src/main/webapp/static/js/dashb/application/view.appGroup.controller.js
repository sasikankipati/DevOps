﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewAppGroupController', ViewAppGroupController);

    ViewAppGroupController.$inject = ['$location', 'ViewAppGroupService', 'FlashService','$routeParams'];
    function ViewAppGroupController($location, ViewAppGroupService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateAppGroup = updateAppGroup;
        vm.toggleEdit = toggleEdit;
        
        
        ViewAppGroupService.viewAppGroup($scope.param1,function (response) {
            if (response.success) {
            	ViewAppGroupService.setValues(response.objApplicationGroupVO);
            	vm.groupName=response.objApplicationGroupVO.groupName;
            	vm.email=response.objApplicationGroupVO.email;
            	vm.groupOwner=response.objApplicationGroupVO.groupOwner;
            	vm.displayOrder=response.objApplicationGroupVO.displayOrder;
            	vm.group_id=response.objApplicationGroupVO.group_id;
            	vm.editGroupName=false;
            	//vm.dataLoading = true;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        function updateAppGroup() {
        	 var formData = {
             		groupName: vm.groupName,
             		email: vm.email,
             		group_id: vm.group_id,
             		groupOwner: vm.groupOwner,
             		displayOrder: vm.displayOrder
             };
            vm.dataLoading = true;
            ViewAppGroupService.updateAppGroup(formData,function (response) {
                if (response.success) {
                	//ViewAppGroupService.setValues(response.arlApplications);
                	$location.path('/showApplicationGroup'); 
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        };
        
        function toggleEdit(val){
        	alert(val);
        }
        
        $scope.toggleEdit1 = function(val){
        	if(val == 'editGroupName'){
        		alert(vm.editGroupName);
        		vm.editGroupName = true;
        	}
        };
    }

})();
