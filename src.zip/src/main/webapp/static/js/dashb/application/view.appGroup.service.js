﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('ViewAppGroupService', ViewAppGroupService);

    ViewAppGroupService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function ViewAppGroupService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.ClearValues = ClearValues;
        service.viewAppGroup = viewAppGroup;
        service.setValues = setValues;
        service.updateAppGroup=updateAppGroup;
        
        return service;

        function viewAppGroup(param1,callback) {
            $http.post('/DashBoard/viewAppGroup',{group_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function updateAppGroup(formData,callback) {
            $http.post('/DashBoard/updateAppGroup',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function ClearValues() {
        	$rootScope.appGroupFB={};
        }
        
        function setValues(objApplicationGroupVO) {
        	$rootScope.objApplicationGroupVO=objApplicationGroupVO;
        }

    }


})();