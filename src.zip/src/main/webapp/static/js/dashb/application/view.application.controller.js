﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewApplicationController', ViewApplicationController);

    ViewApplicationController.$inject = ['$location', 'ApplicationService', 'FlashService','$routeParams'];
    function ViewApplicationController($location, ApplicationService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateApplication = updateApplication;
        
        ApplicationService.viewApplication($scope.param1,function (response) {
            if (response.success) {
            	//ApplicationService.setValues(response.arlApplications);
            	vm.appDesc = response.objApplicationVO.appDesc;
            	vm.appId= response.objApplicationVO.appId;
            	vm.appOwner= response.objApplicationVO.appOwner;
            	vm.asccAppCode= response.objApplicationVO.asccAppCode;
            	vm.group= response.objApplicationVO.group;
            	vm.group_id=response.objApplicationVO.appGroupId;
            	vm.displayOrder= response.objApplicationVO.displayOrder;
            	vm.arlAppGroups = response.arlAppGroups;
            	vm.arlUsersVO = response.arlUsersVO;
            	vm.appOwnerId = response.objApplicationVO.appOwnerId;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        function updateApplication(){
        	 var formData = {
        			appId: vm.appId,
        			appDesc: vm.appDesc,
        			appOwner: vm.appOwner,
        			asccAppCode: vm.asccAppCode,
        			appGroupId: vm.group_id,
        			appOwnerId: vm.appOwnerId,
              		displayOrder: vm.displayOrder
              };
             vm.dataLoading = true;
             ApplicationService.updateApplication(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showApplications'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        }
          
          
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
