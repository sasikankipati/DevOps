﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('CommonService', CommonService);

    CommonService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function CommonService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};
        service.spinnerOn = spinnerOn;
        service.spinnerOff = spinnerOff;
        return service;

        function spinnerOn() {
        	$rootScope.spinner.on();
        }
        
        function spinnerOff() {
        	$rootScope.spinner.off();
        }

    }
})();