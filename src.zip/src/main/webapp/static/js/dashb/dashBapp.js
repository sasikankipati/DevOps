(function () {
    'use strict';
    
angular.module('app', ['ngRoute', 'ngCookies','angular.morris-chart','mwl.calendar', 'ngAnimate', 'ui.bootstrap','treasure-overlay-spinner']).config(config).run(run);



config.$inject = ['$routeProvider', '$locationProvider'];
function config($routeProvider, $locationProvider) {
    $routeProvider
    
    
	    .when('/showJobLog', {
	        controller: 'JobLogController',
	        templateUrl: 'views/jobs/jobLogs.html',
	        controllerAs: 'vm'
	    })
    
	    .when('/tsLvlDetails/:param1/:param2', {
		    controller: 'HealthCheckTsLvlController',
		    templateUrl: 'views/healthcheck/tsLevel_health.html',
		    controllerAs: 'vm'
		})
	    .when('/envLvlDetails/:param1', {
		    controller: 'HealthCheckEnvLvlController',
		    templateUrl: 'views/healthcheck/envLevel_health.html',
		    controllerAs: 'vm'
		})
	    .when('/showHealthCheck', {
		    controller: 'HealthCheckSummaryController',
		    templateUrl: 'views/healthcheck/appLevel_health.html',
		    controllerAs: 'vm'
		})
	    .when('/showTestScenarios', {
		    controller: 'TestScenarioController',
		    templateUrl: 'views/testscenario/allTestScenarios.html',
		    controllerAs: 'vm'
		})
		.when('/viewTestScenario/:param1', {
		    controller: 'ViewTestScenarioController',
		    templateUrl: 'views/testscenario/viewTestScenario.html',
		    controllerAs: 'vm'
		})
		.when('/copyTestScenario/:param1', {
		    controller: 'CopyTestScenarioController',
		    templateUrl: 'views/testscenario/copyTestScenario.html',
		    controllerAs: 'vm'
		})
		.when('/addTestScenario', {
		    controller: 'AddTestScenarioController',
		    templateUrl: 'views/testscenario/addTestScenario.html',
		    controllerAs: 'vm'
		})
		.when('/deleteTestScenario/:param1', {
		    controller: 'DeleteTestScenarioController',
		    templateUrl: 'views/testscenario/allTestScenarios.html',
		    controllerAs: 'vm'
		})
    
	    .when('/showEnvironments', {
		    controller: 'EnvironmentController',
		    templateUrl: 'views/environment/allEnvironments.html',
		    controllerAs: 'vm'
		})
		.when('/viewEnvironment/:param1', {
		    controller: 'ViewEnvironmentController',
		    templateUrl: 'views/environment/viewEnvironment.html',
		    controllerAs: 'vm'
		})
		.when('/addEnvironment', {
		    controller: 'AddEnvironmentController',
		    templateUrl: 'views/environment/addEnvironment.html',
		    controllerAs: 'vm'
		})
		.when('/deleteEnvironment/:param1', {
		    controller: 'DeleteEnvironmentController',
		    templateUrl: 'views/environment/allEnvironments.html',
		    controllerAs: 'vm'
		})
	
	    .when('/viewTestCase/:param1',{
	    	controller: 'ViewTestCaseController',
	    	templateUrl: 'views/testcase/ViewTestCase.html',
	    	controllerAs:'vm'
	    })
	    .when('/deleteTestCase/:param1',{
        	controller: 'DeleteTestCaseController',
        	templateUrl: 'views/testcase/allTestCases.html',
        	controllerAs:'vm'
        })
	    .when('/addTestCase', {
		    controller: 'AddTestCaseController',
		    templateUrl: 'views/testcase/addTestCase.html',
		    controllerAs: 'vm'
		})
	    .when('/showTestCases', {
		    controller: 'TestCasesController',
		    templateUrl: 'views/testcase/allTestCases.html',
		    controllerAs: 'vm'
		})
		
	    .when('/logout', {
		    controller: 'LogoutController',
		    templateUrl: 'views/users/logout.html',
		    controllerAs: 'vm'
		})
	    .when('/changePassword', {
		    controller: 'ChangePasswordController',
		    templateUrl: 'views/users/changePassword.html',
		    controllerAs: 'vm'
		})
		.when('/viewProfile', {
		    controller: 'ViewProfileController',
		    templateUrl: 'views/users/viewProfile.html',
		    controllerAs: 'vm'
		})
	    .when('/activityHistory', {
	        controller: 'ActivityHistoryController',
	        templateUrl: 'views/history/ActivityHistory.html',
	        controllerAs: 'vm'
	    })
	    .when('/showGraph', {
	        controller: 'IncidentTrendController',
	        templateUrl: 'views/incident/IncidentTrend.html',
	        controllerAs: 'vm'
	    })
        .when('/login', {
            controller: 'LoginController',
            templateUrl: 'views/login/login.html',
            controllerAs: 'vm'
        })
        .when('/addNewUser', {
            controller: 'NewUserController',
            templateUrl: 'views/users/NewUser.html',
            controllerAs: 'vm'
        })
        .when('/addTask', {
            controller: 'NewTasksController',
            templateUrl: 'views/tasks/NewTask.html',
            controllerAs: 'vm'
        })
        .when('/showJobs', {
            controller: 'JobsController',
            templateUrl: 'views/jobs/allJobs.html',
            controllerAs: 'vm'
        })
        .when('/showTasks', {
            controller: 'TasksController',
            templateUrl: 'views/tasks/allTasks.html',
            controllerAs: 'vm'
        })
        .when('/showApplications', {
            controller: 'ApplicationController',
            templateUrl: 'views/application/allApplication.html',
            controllerAs: 'vm'
        })
        .when('/showApplicationGroup', {
            controller: 'AppGroupController',
            templateUrl: 'views/application/allAppGroups.html',
            controllerAs: 'vm'
        })
        .when('/addApplication',{
        	controller: 'NewApplicationController',
        	templateUrl: 'views/application/NewApplication.html',
        	controllerAs:'vm'
        })
        .when('/addAppGroup',{
        	controller: 'NewAppGroupController',
        	templateUrl: 'views/application/NewAppGroup.html',
        	controllerAs:'vm'
        })
        .when('/viewUser/:param1',{
        	controller: 'ViewUserController',
        	templateUrl: 'views/users/ViewUser.html',
        	controllerAs:'vm'
        })
        .when('/viewSelectedTask/:param1',{
        	controller: 'ViewSelectedTaskController',
        	templateUrl: 'views/tasks/ViewTask.html',
        	controllerAs:'vm'
        })
        .when('/deleteSelectedTask/:param1',{
        	controller: 'DeleteSelectedTaskController',
        	templateUrl: 'views/tasks/allTasks.html',
        	controllerAs:'vm'
        })
        .when('/viewSelectedActivity/:param1',{
        	controller: 'ViewSelectedActivityController',
        	templateUrl: 'views/activity/ViewActivity.html',
        	controllerAs:'vm'
        })
        .when('/actOnActivity/:param1',{
        	controller: 'FillActivityController',
        	templateUrl: 'views/action/ActOnActivity.html',
        	controllerAs:'vm'
        })
        .when('/viewAppGroup/:param1',{
        	controller: 'ViewAppGroupController',
        	templateUrl: 'views/application/ViewAppGroup.html',
        	controllerAs:'vm'
        })
        .when('/viewApplication/:param1',{
        	controller: 'ViewApplicationController',
        	templateUrl: 'views/application/ViewApplication.html',
        	controllerAs:'vm'
        })
        .when('/showUsers', {
            controller: 'UsersController',
            templateUrl: 'views/users/allUsers.html',
            controllerAs: 'vm'
        })
        .when('/addActivity', {
            controller: 'NewActivityController',
            templateUrl: 'views/activity/newActivity.html',
            controllerAs: 'vm'
        })
        .when('/showTaskSelection', {
        	controller: 'NewActivityTaskController',
            templateUrl: 'views/activity/newActivityTasks.html',
            controllerAs: 'vm'
        })
        .when('/showSummary', {
            controller: 'SummaryController',
            templateUrl: 'views/healthcheck/dayView.html',
            controllerAs: 'vm'
        })
        .when('/showActivities', {
            controller: 'ActivitiesController',
            templateUrl: 'views/activity/allActivities.html',
            controllerAs: 'vm'
        })
        .when('/groupViewDetails/:param1', {
            controller: 'GroupSummaryController',
            templateUrl: 'views/healthcheck/groupView.html',
            controllerAs: 'vm'
        })
        .otherwise({ redirectTo: '/logout' });
}

run.$inject = ['$rootScope', '$location', '$cookieStore', '$http'];
function run($rootScope, $location, $cookieStore, $http) {
    // keep user logged in after page refresh
    $rootScope.globals = $cookieStore.get('globals') || {};
    if ($rootScope.globals.currentUser) {
        $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
    }

    $rootScope.$on('$locationChangeStart', function (event, next, current) {
        // redirect to login page if not logged in and trying to access a restricted page
        var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
        var loggedIn = $rootScope.username;
        if (restrictedPage && !loggedIn) {
            $location.path('/login');
        }
        
    });

	    $rootScope.spinner = {
		active : false,
		on : function() {
			this.active = true;
		},
		off : function() {
			this.active = false;
		}
	};
}

})();

