﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('AddEnvironmentController', AddEnvironmentController);

    AddEnvironmentController.$inject = ['$location', 'EnvironmentService', 'FlashService'];
    function AddEnvironmentController($location, EnvironmentService, FlashService,$scope) {
        var vm = this;
        vm.saveEnvironment = saveEnvironment;
        
        
        (function initController() {
        	
        	
        })();
        
        function saveEnvironment() {
        	var formData = {
        			environment_id:vm.environment_id,
    				env_id:vm.env_id,
    				env_name:vm.env_name,
    				env_desc:vm.env_desc,
    				rec_status:vm.rec_status,
    				remarks:vm.remarks,
    				country:vm.country
              };
             vm.dataLoading = true;
             EnvironmentService.saveEnvironment(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showEnvironments'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
