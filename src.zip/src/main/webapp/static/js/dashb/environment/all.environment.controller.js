﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('EnvironmentController', EnvironmentController);

    EnvironmentController.$inject = ['$location', 'EnvironmentService', 'FlashService'];
    function EnvironmentController($location, EnvironmentService, FlashService,$scope) {
        var vm = this;

        vm.dataLoading = true;
        EnvironmentService.fetchAllEnvironments(function (response) {
            if (response.success) {
            	EnvironmentService.setValues(response.arlEnvironmentVO);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
