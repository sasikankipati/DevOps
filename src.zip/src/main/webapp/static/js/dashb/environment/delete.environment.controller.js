﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('DeleteEnvironmentController', DeleteEnvironmentController);

    DeleteEnvironmentController.$inject = ['$location', 'EnvironmentService', 'FlashService','$routeParams'];
    function DeleteEnvironmentController($location, EnvironmentService, FlashService,$scope,$routeParams) {
        var vm = this;
        
        (function initController() {
        	
        	EnvironmentService.deleteEnvironment($scope.param1,function (response) {
                if (response.success) {
                	$location.path('/showEnvironments'); 
                	 vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
    }

})();
