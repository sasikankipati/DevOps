﻿(function () {
    'use strict';

    angular.module('app').factory('EnvironmentService', EnvironmentService);

    EnvironmentService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function EnvironmentService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllEnvironments = fetchAllEnvironments;
        service.setValues = setValues;
        service.saveEnvironment = saveEnvironment;
        service.updateEnvironment = updateEnvironment;
        service.viewEnvironment = viewEnvironment;
        service.deleteEnvironment = deleteEnvironment;
        return service;
        
        
        function updateEnvironment(formData,callback) {
            $http.post('/DashBoard/updateEnvironment',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewEnvironment(param1,callback) {
            $http.post('/DashBoard/viewEnvironment',{environment_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function deleteEnvironment(param1,callback) {
            $http.post('/DashBoard/deleteEnvironment',{environment_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        
        function saveEnvironment(formData,callback) {
            $http.post('/DashBoard/saveEnvironment',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllEnvironments(callback) {
            $http.post('/DashBoard/fetchAllEnvironments')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function setValues(arlEnvironmentVO) {
        	$rootScope.arlEnvironmentVO = arlEnvironmentVO;
        }

    }
})();