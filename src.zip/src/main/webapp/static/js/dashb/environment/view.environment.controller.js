﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewEnvironmentController', ViewEnvironmentController);

    ViewEnvironmentController.$inject = ['$location', 'EnvironmentService', 'FlashService','$routeParams'];
    function ViewEnvironmentController($location, EnvironmentService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateEnvironment = updateEnvironment;
        
        
        (function initController() {
        	EnvironmentService.viewEnvironment($scope.param1,function (response) {
                if (response.success) {
                	vm.environment_id = response.objEnvironmentVO.environment_id;
    				vm.env_id = response.objEnvironmentVO.env_id;
    				vm.env_name = response.objEnvironmentVO.env_name;
    				vm.env_desc = response.objEnvironmentVO.env_desc;
    				vm.rec_status = response.objEnvironmentVO.rec_status;
    				vm.remarks = response.objEnvironmentVO.remarks;
    				vm.country = response.objEnvironmentVO.country;
                	vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
        function updateEnvironment() {
        	var formData = {
        			environment_id:vm.environment_id,
    				env_id:vm.env_id,
    				env_name:vm.env_name,
    				env_desc:vm.env_desc,
    				rec_status:vm.rec_status,
    				remarks:vm.remarks,
    				country:vm.country
              };
             vm.dataLoading = true;
             EnvironmentService.updateEnvironment(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showEnvironments'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
