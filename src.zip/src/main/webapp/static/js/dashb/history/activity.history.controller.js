﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ActivityHistoryController', ActivityHistoryController);

    ActivityHistoryController.$inject = ['$location', 'ActivitiesService', 'FlashService'];
    function ActivityHistoryController($location, ActivitiesService, FlashService,$scope,$calendarProvider) {
        var vm = this;

        
         (function initController() {
           
        	 ActivitiesService.fetchActivityHistory(function (response) {
                 if (response.success) {
                 	vm.calendarView = 'month';
            	    vm.viewDate = new Date();
            	    vm.events = response.arlCalendarVO;
            	    vm.isCellOpen = true;
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        	 
        	 
        	 
        	 
        })();
        
        
        vm.login = login;
        vm.eventEdited = eventEdited;
        
        function eventEdited(calendarEvent){
        	alert(calendarEvent);
        };
       
        function login() {
            vm.dataLoading = true;
        };
    }

})();
