﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('IncidentTrendController', IncidentTrendController);

    IncidentTrendController.$inject = ['$location', 'FlashService'];
    function IncidentTrendController($location, FlashService,$scope) {


    	 (function initController() {
    		 
    		 /*var hostDate = '[{ "device": "2016-04-26", "geekbench": "136","geekbench2": "110" },'+ 
    			 			'{ "device": "2016-04-27","geekbench": "137","geekbench2": "110" }, {'+
    			 			'"device": "2016-04-28","geekbench": "275","geekbench2": "110"}, {'+
    			 			'"device": "2016-04-29","geekbench": "380","geekbench2": "110"}, {'+
    			 			'"device": "2016-04-30","geekbench": "655","geekbench2": "110"}]';*/
    		 
    		 var hostDate = [{
		            device: '2016-04-26',
		            geekbench: 140,
		            geekbench2: 110
		        }, {
		            device: '2016-04-27',
		            geekbench: 137,
		            geekbench2: 110
		        }, {
		            device: '2016-04-28',
		            geekbench: 275,
		            geekbench2: 110
		        }, {
		            device: '2016-04-29',
		            geekbench: 380,
		            geekbench2: 110
		        }, {
		            device: '2016-04-30',
		            geekbench: 655,
		            geekbench2: 110
		        }];
    		 
    		 // Bar Chart
    		    Morris.Bar({
    		        element: 'morris-bar-chart',
    		        data: hostDate,
    		        xkey: 'device',
    		        colors: ["#9CC4E4", "#3A89C9"],
    		        ykeys: ['geekbench','geekbench2'],
    		        labels: ['Filled','Not Filled'],
    		        barRatio: 0.4,
    		        xLabelAngle: 35,
    		        hideHover: 'auto',
    		        resize: true
    		    });
    		    
    		    
    		 Morris.Donut({ 
    	            element: 'morris-donut-chart',
    	            colors: ["#9CC4E4", "#3A89C9", "#F26C4F"],
    	            data: [{
    	                label: "Week-1",
    	                value: 12
    	            }, {
    	                label: "Week-2",
    	                value: 30
    	            }, {
    	                label: "Week-3",
    	                value: 20
    	            }, {
    	                label: "Week-4",
    	                value: 22
    	            }],
    	            resize: true
    	        });
        })();
        
    }

})();
