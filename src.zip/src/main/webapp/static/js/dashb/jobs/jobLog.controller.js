﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('JobLogController', JobLogController);

    JobLogController.$inject = ['$location', 'JobsService', 'FlashService'];
    function JobLogController($location, JobsService, FlashService,$scope) {
        var vm = this;

        
        JobsService.fetchJobLogs(function (response) {
            if (response.success) {
            	vm.arlJobs = response.arlJobs;
            	JobsService.setJobs(response.arlJobs);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        
       
    }

})();
