﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('JobsController', JobsController);

    JobsController.$inject = ['$location', 'JobsService', 'FlashService'];
    function JobsController($location, JobsService, FlashService,$scope) {
        var vm = this;

        
        JobsService.fetchAllJobs(function (response) {
            if (response.success) {
            	vm.arlJobs = response.arlJobs;
            	JobsService.setJobs(response.arlJobs);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        
       
    }

})();
