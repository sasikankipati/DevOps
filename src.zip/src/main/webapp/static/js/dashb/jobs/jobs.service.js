﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('JobsService', JobsService);

    JobsService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function JobsService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllJobs = fetchAllJobs;
        service.viewJobDependencies = viewJobDependencies;
        service.setShowHide = setShowHide; 
        service.setJobs = setJobs;
        service.fetchJobLogs = fetchJobLogs;
        return service;
        
        function setJobs(arlJobs){
        	$rootScope.arlJobs = arlJobs;
        }
        
        function fetchJobLogs(callback) {
            $http.post('/DashBoard/fetchJobLogs')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllJobs(callback) {
            $http.post('/DashBoard/fetchAllJobs')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewJobDependencies(param1,callback){
       	 $http.post('/DashBoard/viewJobDependencies',{jobMasterId : param1})
            	.success(function (response) {
            		callback(response);
            });
       }
        
       function setShowHide(){
    	   alert();
    	   $rootScope.showHideExample = false;
    	   $rootScope.showHideTest=false;
       }

    }
})();