﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$location', 'AuthenticationService','CommonService', 'FlashService'];
    function LoginController($location, AuthenticationService,CommonService, FlashService,$scope) {
        var vm = this;

        vm.login = login;
        
        (function initController() {
            AuthenticationService.ClearCredentials();
        })();

        function login() {
        	CommonService.spinnerOn();
            AuthenticationService.Login(vm.username, vm.password, function (response) {
                if (response.success) {
                    AuthenticationService.SetCredentials(response);
                    CommonService.spinnerOff();
                    $location.path('/showHealthCheck'); 
                } else {
                    FlashService.Error(response.message);
                    CommonService.spinnerOff();
                }
            });
        };
    }

})();
