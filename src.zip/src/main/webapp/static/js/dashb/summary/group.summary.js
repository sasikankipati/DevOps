﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('GroupSummaryController', GroupSummaryController);

    GroupSummaryController.$inject = ['$location', 'SummaryService', 'FlashService','$routeParams'];
    function GroupSummaryController($location, SummaryService, FlashService,$scope,$routeParams) {
        var vm = this;

        
        SummaryService.groupSummary($scope.param1, function (response) {
            if (response.success) {
            	SummaryService.setValues(response.arlSummary);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
