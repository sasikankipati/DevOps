﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HealthCheckSummaryController', HealthCheckSummaryController);

    HealthCheckSummaryController.$inject = ['$location', 'SummaryService', 'FlashService'];
    function HealthCheckSummaryController($location, SummaryService, FlashService,$scope) {
        var vm = this;

        vm.dataLoading = true;
        SummaryService.fetchAppLevelHealthCheck(function (response) {
            if (response.success) {
            	SummaryService.setHealthCheckValues(response.arlSystemHealthChk);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
