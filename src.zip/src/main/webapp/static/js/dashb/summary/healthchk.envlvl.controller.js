﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HealthCheckEnvLvlController', HealthCheckEnvLvlController);

    HealthCheckEnvLvlController.$inject = ['$location', 'SummaryService', 'FlashService','$routeParams'];
    function HealthCheckEnvLvlController($location, SummaryService, FlashService,$scope,$routeParams) {
        var vm = this;

        vm.dataLoading = true;
        SummaryService.fetchEnvLevelHealthCheck($scope.param1,function (response) {
            if (response.success) {
            	SummaryService.setHealthCheckValues(response.arlSystemHealthChk);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
