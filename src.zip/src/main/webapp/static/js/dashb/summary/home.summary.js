﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('SummaryController', SummaryController);

    SummaryController.$inject = ['$location', 'SummaryService', 'FlashService'];
    function SummaryController($location, SummaryService, FlashService,$scope) {
        var vm = this;

        
        SummaryService.summaryDetails(vm.username, vm.password, function (response) {
            if (response.success) {
            	SummaryService.setValues(response.arlSummary);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
