﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('SummaryService', SummaryService);

    SummaryService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function SummaryService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.summaryDetails = summaryDetails;
        service.setValues = setValues;
        service.ClearCredentials = ClearCredentials;
        service.groupSummary = groupSummary;
        service.fetchAppLevelHealthCheck = fetchAppLevelHealthCheck;
        service.setHealthCheckValues = setHealthCheckValues;
        service.fetchEnvLevelHealthCheck = fetchEnvLevelHealthCheck;
        service.fetchTsLevelHealthCheck = fetchTsLevelHealthCheck;
        return service;

        function fetchTsLevelHealthCheck(param1,param2, callback) {
            $http.post('/DashBoard/fetchTsLevelHealthCheck', { appId:param1 ,country:param2})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchEnvLevelHealthCheck(param1, callback) {
            $http.post('/DashBoard/fetchEnvLevelHealthCheck', { appId:param1 })
                .success(function (response) {
                    callback(response);
            });
        }
        
        function setHealthCheckValues(arlSystemHealthChk){
        	$rootScope.arlSystemHealthChk = arlSystemHealthChk;
        }
        
        //fetchAppLevelHealthCheck
        function fetchAppLevelHealthCheck(callback) {
            $http.post('/DashBoard/fetchAppLevelHealthCheck')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function summaryDetails(username, password, callback) {
            $http.post('/DashBoard/showSummary')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function groupSummary(param1, callback) {
            $http.post('/DashBoard/groupSummary', { groupid:param1 })
                .success(function (response) {
                    callback(response);
            });
        }

        function setValues(arlSummary) {
        	$rootScope.arlSummary=arlSummary;
        }

        function ClearCredentials() {
           
        }
    }


})();