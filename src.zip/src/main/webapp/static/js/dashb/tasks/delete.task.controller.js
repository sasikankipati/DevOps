﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('DeleteSelectedTaskController', DeleteSelectedTaskController);

    DeleteSelectedTaskController.$inject = ['$location', 'TasksService', 'FlashService','$routeParams'];
    function DeleteSelectedTaskController($location, TasksService, FlashService,$scope,$routeParams) {
        var vm = this;

        (function initController() {
        	TasksService.deleteTask($scope.param1,function (response) {
                if (response.success) {
                	$location.path('/showTasks'); 
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
    }

})();
