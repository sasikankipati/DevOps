﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewTasksController', NewTasksController);

    NewTasksController.$inject = ['$location', 'TasksService', 'FlashService'];
    function NewTasksController($location, TasksService, FlashService,$scope) {
        var vm = this;

        
        TasksService.setNewTask(function (response) {
            if (response.success) {
            	vm.arlAppGroups = response.arlAppGroups;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.saveNewTask = saveNewTask;
        
        function saveNewTask() {

        	var formData = {
        			groupId: vm.groupId,
        			taskDesc: vm.taskDesc
              };
             vm.dataLoading = true;
             TasksService.saveNewTask(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTasks'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
            
        };
    }

})();
