﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('TasksController', TasksController);

    TasksController.$inject = ['$location', 'TasksService', 'FlashService'];
    function TasksController($location, TasksService, FlashService,$scope) {
        var vm = this;

        
        TasksService.fetchAllTasks(function (response) {
            if (response.success) {
            	vm.arlTaskDetailVO = response.arlTaskDetailVO;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        
       
    }

})();
