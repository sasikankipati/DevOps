﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('TasksService', TasksService);

    TasksService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function TasksService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllTasks = fetchAllTasks;
        service.setValues = setValues;
        service.setNewTask = setNewTask;
        service.saveNewTask = saveNewTask;
        service.viewSelectedTask = viewSelectedTask;
        service.updateTask = updateTask;
        service.deleteTask = deleteTask;
        return service;
        
        function updateTask(formData,callback) {
            $http.post('/DashBoard/updateTask',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function deleteTask(formData,callback) {
            $http.post('/DashBoard/deleteTask',{taskId : formData})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewSelectedTask(formData,callback) {
            $http.post('/DashBoard/viewSelectedTask',{taskId : formData})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllTasks(callback) {
            $http.post('/DashBoard/fetchAllTasks')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function setNewTask(callback) {
            $http.post('/DashBoard/setNewTask')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function saveNewTask(formData,callback) {
            $http.post('/DashBoard/saveNewTask',formData)
                .success(function (response) {
                    callback(response);
            });
        }

        function setValues(arlTaskDetailVO) {
        	$rootScope.arlTaskDetailVO=arlTaskDetailVO;
        }

    }


})();