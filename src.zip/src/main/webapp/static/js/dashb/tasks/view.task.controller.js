﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewSelectedTaskController', ViewSelectedTaskController);

    ViewSelectedTaskController.$inject = ['$location', 'TasksService', 'FlashService','$routeParams'];
    function ViewSelectedTaskController($location, TasksService, FlashService,$scope,$routeParams) {
        var vm = this;

        (function initController() {
        	TasksService.viewSelectedTask($scope.param1,function (response) {
                if (response.success) {
                	vm.taskId = response.objTaskDetailVO.taskId;
                	vm.groupId = response.objTaskDetailVO.groupId;
        			vm.taskDesc = response.objTaskDetailVO.taskDesc;
       				vm.arlAppGroups = response.arlAppGroups;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        vm.updateTask = updateTask;
        
        function updateTask() {
        	var formData = {
        			taskId: vm.taskId,
        			groupId: vm.groupId,
        			taskDesc: vm.taskDesc
              };
             vm.dataLoading = true;
             TasksService.updateTask(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTasks'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
        
    }

})();
