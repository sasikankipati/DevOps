﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('AddTestCaseController', AddTestCaseController);

    AddTestCaseController.$inject = ['$location', 'TestCaseService', 'FlashService'];
    function AddTestCaseController($location, TestCaseService, FlashService,$scope) {
        var vm = this;
        vm.saveNewTestCase = saveNewTestCase;
        
        
        (function initController() {
        	
        	TestCaseService.loadNewTestCase(function (response) {
                if (response.success) {
                	 vm.arlSeverity = response.arlSeverity;
                	 vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
        function saveNewTestCase() {
        	var formData = {
        			test_case_id: vm.test_case_id,
        			case_id: vm.case_id,
        			case_desc: vm.case_desc,
        			rec_status: vm.rec_status,
        			severity: vm.severity,
        			remarks: vm.remarks
              };
             vm.dataLoading = true;
             TestCaseService.saveNewTestCase(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTestCases'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
