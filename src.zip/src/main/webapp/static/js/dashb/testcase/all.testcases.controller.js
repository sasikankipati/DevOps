﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('TestCasesController', TestCasesController);

    TestCasesController.$inject = ['$location', 'TestCaseService', 'FlashService'];
    function TestCasesController($location, TestCaseService, FlashService,$scope) {
        var vm = this;

        vm.dataLoading = true;
        TestCaseService.fetchAllTestCases(function (response) {
            if (response.success) {
            	TestCaseService.setValues(response.arlTestCases);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
