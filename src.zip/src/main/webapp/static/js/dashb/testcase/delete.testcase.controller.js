﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('DeleteTestCaseController', DeleteTestCaseController);

    DeleteTestCaseController.$inject = ['$location', 'TestCaseService', 'FlashService','$routeParams'];
    function DeleteTestCaseController($location, TestCaseService, FlashService,$scope,$routeParams) {
        var vm = this;
        
        
        (function initController() {
        	
        	TestCaseService.deleteTestCase($scope.param1,function (response) {
                if (response.success) {
                	$location.path('/showTestCases'); 
                	 vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
    }

})();
