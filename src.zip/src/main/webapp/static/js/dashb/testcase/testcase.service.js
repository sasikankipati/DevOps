﻿(function () {
    'use strict';

    angular.module('app').factory('TestCaseService', TestCaseService);

    TestCaseService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function TestCaseService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllTestCases = fetchAllTestCases;
        service.setValues = setValues;
        service.saveNewTestCase = saveNewTestCase;
        service.loadNewTestCase = loadNewTestCase;
        service.updateTestCase = updateTestCase;
        service.viewTestCase = viewTestCase;
        service.deleteTestCase = deleteTestCase;
        return service;
        
        
        function updateTestCase(formData,callback) {
            $http.post('/DashBoard/updateTestCase',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewTestCase(param1,callback) {
            $http.post('/DashBoard/viewTestCase',{test_case_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function deleteTestCase(param1,callback) {
            $http.post('/DashBoard/deleteTestCase',{test_case_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function loadNewTestCase(callback) {
            $http.post('/DashBoard/loadNewTestCase')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function saveNewTestCase(formData,callback) {
            $http.post('/DashBoard/saveNewTestCase',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllTestCases(callback) {
            $http.post('/DashBoard/fetchAllTestCases')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function setValues(arlTestCases) {
        	$rootScope.arlTestCases = arlTestCases;
        }

    }
})();