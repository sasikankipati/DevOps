﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewTestCaseController', ViewTestCaseController);

    ViewTestCaseController.$inject = ['$location', 'TestCaseService', 'FlashService','$routeParams'];
    function ViewTestCaseController($location, TestCaseService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateNewTestCase = updateNewTestCase;
        
        
        (function initController() {
        	
        	TestCaseService.viewTestCase($scope.param1,function (response) {
                if (response.success) {
                	vm.test_case_id = response.objTestCaseVO.test_case_id;
                	vm.case_id = response.objTestCaseVO.case_id; 
        			vm.case_desc = response.objTestCaseVO.case_desc;
        			vm.rec_status = response.objTestCaseVO.rec_status;
        			vm.severity = response.objTestCaseVO.severity;
        			vm.remarks = response.objTestCaseVO.remarks;
        			vm.arlSeverity = response.arlSeverity;
                	vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
        function updateNewTestCase() {
        	var formData = {
        			test_case_id: vm.test_case_id,
        			case_id: vm.case_id,
        			case_desc: vm.case_desc,
        			rec_status: vm.rec_status,
        			severity: vm.severity,
        			remarks: vm.remarks
              };
             vm.dataLoading = true;
             TestCaseService.updateTestCase(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTestCases'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
