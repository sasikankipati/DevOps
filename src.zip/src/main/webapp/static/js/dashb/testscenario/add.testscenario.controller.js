﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('AddTestScenarioController', AddTestScenarioController);

    AddTestScenarioController.$inject = ['$location', 'TestScenarioService', 'FlashService'];
    function AddTestScenarioController($location, TestScenarioService, FlashService,$scope) {
        var vm = this;
        vm.saveTestScenario = saveTestScenario;
        
        (function initController() {
        	TestScenarioService.loadTestScenario(function (response) {
                if (response.success) {
                	vm.arlEnvironmentVO = response.arlEnvironmentVO;
                	vm.arlApplications = response.arlApplications;
                	vm.arlTestCases = response.arlTestCases;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        function saveTestScenario() {
        	var i=0;
        	var testcases=[];
        	
        	for(i = 0; i< vm.arlTestCases.length;i++ ){
        		if(vm.arlTestCases[i].checked){
        			testcases.push(vm.arlTestCases[i].case_id);
        		}
        	}
        	
        	var formData = {
        			scenario_id:vm.scenario_id,
        			scenario_desc:vm.scenario_desc,
        			env_id:vm.env_id,
        			app_id:vm.app_id,
    				testCases:testcases
              };
             vm.dataLoading = true;
             TestScenarioService.saveTestScenario(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTestScenarios'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
