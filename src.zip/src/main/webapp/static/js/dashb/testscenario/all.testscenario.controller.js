﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('TestScenarioController', TestScenarioController);

    TestScenarioController.$inject = ['$location', 'TestScenarioService', 'FlashService'];
    function TestScenarioController($location, TestScenarioService, FlashService,$scope) {
        var vm = this;

        vm.dataLoading = true;
        TestScenarioService.fetchAllTestScenarios(function (response) {
            if (response.success) {
            	TestScenarioService.setValues(response.arlTestScenarioVO);
            	vm.dataLoading = false;
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
