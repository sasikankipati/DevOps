﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('CopyTestScenarioController', CopyTestScenarioController);

    CopyTestScenarioController.$inject = ['$location', 'TestScenarioService', 'FlashService','$routeParams'];
    function CopyTestScenarioController($location, TestScenarioService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.copyNewTestScenario = copyNewTestScenario;
        
        
        (function initController() {
        	TestScenarioService.copyTestScenario($scope.param1,function (response) {
                if (response.success) {
                	vm.arlEnvironmentVO = response.arlEnvironmentVO;
                	vm.arlApplications = response.arlApplications;
                	vm.arlTestCases = response.arlTestCases;
                	
                	vm.testScenario_id = response.objTestScenarioVO.testScenario_id;
                	vm.scenario_id = response.objTestScenarioVO.scenario_id;
    				vm.scenario_desc = response.objTestScenarioVO.scenario_desc;
    				vm.env_id = response.objTestScenarioVO.env_id;
    				vm.app_id = response.objTestScenarioVO.app_id;
    				
                	vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        	
        })();
        
        function copyNewTestScenario() {
        	var i=0;
        	var testcases=[];
        	
        	for(i = 0; i< vm.arlTestCases.length;i++ ){
        		if(vm.arlTestCases[i].checked){
        			testcases.push(vm.arlTestCases[i].case_id);
        		}
        	}
        	
        	var formData = {
        			scenario_id:vm.scenario_id,
        			scenario_desc:vm.scenario_desc,
        			env_id:vm.env_id,
        			app_id:vm.app_id,
    				testCases:testcases
              };
             vm.dataLoading = true;
             TestScenarioService.copyNewTestScenario(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showTestScenarios'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
    }

})();
