﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('DeleteTestScenarioController', DeleteTestScenarioController);

    DeleteTestScenarioController.$inject = ['$location', 'TestScenarioService', 'FlashService','$routeParams'];
    function DeleteTestScenarioController($location, TestScenarioService, FlashService,$scope,$routeParams) {
        var vm = this;
        (function initController() {
        	TestScenarioService.deleteTestScenario($scope.param1,function (response) {
                if (response.success) {
                	$location.path('/showTestScenarios'); 
                	 vm.dataLoading = false;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
    }

})();
