﻿(function () {
    'use strict';

    angular.module('app').factory('TestScenarioService', TestScenarioService);

    TestScenarioService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function TestScenarioService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllTestScenarios = fetchAllTestScenarios;
        service.setValues = setValues;
        service.loadTestScenario = loadTestScenario;
        service.saveTestScenario = saveTestScenario;
        service.viewTestScenario = viewTestScenario;
        service.copyTestScenario = copyTestScenario;
        service.updateTestScenario = updateTestScenario;
        service.deleteTestScenario = deleteTestScenario;
        service.copyNewTestScenario = copyNewTestScenario;
        return service;
        
        
        function copyNewTestScenario(formData,callback) {
            $http.post('/DashBoard/copyNewTestScenario',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function deleteTestScenario(param1,callback) {
            $http.post('/DashBoard/deleteTestScenario',{scenario_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function copyTestScenario(param1,callback) {
            $http.post('/DashBoard/copyTestScenario',{scenario_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function viewTestScenario(param1,callback) {
            $http.post('/DashBoard/viewTestScenario',{scenario_id : param1})
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllTestScenarios(callback) {
            $http.post('/DashBoard/fetchAllTestScenarios')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function setValues(arlTestScenarioVO) {
        	$rootScope.arlTestScenarioVO = arlTestScenarioVO;
        }
        
        function loadTestScenario(callback) {
            $http.post('/DashBoard/loadTestScenario')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function saveTestScenario(formData,callback) {
            $http.post('/DashBoard/saveTestScenario',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
        function updateTestScenario(formData,callback) {
            $http.post('/DashBoard/updateTestScenario',formData)
                .success(function (response) {
                    callback(response);
            });
        }
        
    }
})();