﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ChangePasswordController', ChangePasswordController);

    ChangePasswordController.$inject = ['$location', 'UsersService', 'FlashService'];
    function ChangePasswordController($location, UsersService, FlashService,$scope) {
        var vm = this;

        
        (function initController() {
        	
        })();
        
        
        vm.changePassword = changePassword;
        
       
        function changePassword() {
        	
        	var formData = {
        			curPassword: vm.curPassword,
        			newPassword: vm.newPassword
              };
        	
             vm.dataLoading = true;
        	
        	UsersService.changePassword(formData,function (response) {
                if (response.success) {
                	$location.path('/showHealthCheck'); 
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
            
        };
    }

})();
