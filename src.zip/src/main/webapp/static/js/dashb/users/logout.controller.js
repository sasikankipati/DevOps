﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LogoutController', LogoutController);

    LogoutController.$inject = ['$location', 'UsersService', 'FlashService'];
    function LogoutController($location, UsersService, FlashService,$scope) {
        var vm = this;

        (function initController() {
        	UsersService.logout(function (response) {
                if (response.success) {
                	UsersService.clearOnLogout();
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        
        
       
    }

})();
