﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('NewUserController', NewUserController);

    NewUserController.$inject = ['$location', 'UsersService', 'FlashService'];
    function NewUserController($location, UsersService, FlashService,$scope) {
        var vm = this;
        vm.saveNewUser = saveNewUser;

        (function initController() {
        	UsersService.newUser(function (response) {
                if (response.success) {
                	vm.arlAppGroups = response.arlAppGroups;
                	vm.arlUserRoles = response.arlUserRoles;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        function saveNewUser() {
        	var formData = {
        			userName: vm.userName,
        			password: vm.password,
        			email: vm.email,
        			lanId: vm.lanId,
        			role: vm.roleId,
        			admin: vm.adminflag,
        			mobile: vm.mobile,
        			lsAppGroupIds: vm.appGroupIds
        			
              };
             vm.dataLoading = true;
             UsersService.saveNewUser(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showUsers'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
        
    }

})();
