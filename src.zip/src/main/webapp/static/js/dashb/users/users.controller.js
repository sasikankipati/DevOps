﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('UsersController', UsersController);

    UsersController.$inject = ['$location', 'UsersService', 'FlashService'];
    function UsersController($location, UsersService, FlashService,$scope) {
        var vm = this;

        
        UsersService.fetchAllUsers(function (response) {
            if (response.success) {
            	UsersService.setValues(response.arlUser);
            } else {
                FlashService.Error(response.message);
                vm.dataLoading = false;
            }
        });
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
