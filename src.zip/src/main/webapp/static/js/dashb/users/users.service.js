﻿(function () {
    'use strict';

    angular
        .module('app')
        .factory('UsersService', UsersService);

    UsersService.$inject = ['$http', '$cookieStore', '$rootScope', '$timeout'];
    function UsersService($http, $cookieStore, $rootScope, $timeout,$scope) {
        var service = {};

        service.fetchAllUsers = fetchAllUsers;
        service.setValues = setValues;
        service.newUser = newUser;
        service.saveNewUser = saveNewUser;
        service.viewUser = viewUser;
        service.updateUser = updateUser;
        service.viewProfile = viewProfile;
        service.changePassword  = changePassword;
        service.logout = logout;
        service.clearOnLogout = clearOnLogout;
        
        return service;
      
        function logout(callback) {
            $http.post('/DashBoard/logout')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function clearOnLogout(arlUser) {
        	$rootScope.arlUser=null;
        	$rootScope.username=null;
            $rootScope.admin=null;
            $rootScope.arlPendAct=null;
            $rootScope.pendAlert=0;
        }
        
        function viewProfile(callback) {
            $http.post('/DashBoard/viewProfile')
                .success(function (response) {
                    callback(response);
            });
        }
      
       function viewUser(param1,callback) {
            $http.post('/DashBoard/viewUser',{userId : param1})
                .success(function (response) {
                    callback(response);
            });
        }
       
       
       function changePassword(formData,callback) {
           $http.post('/DashBoard/changePassword',formData)
               .success(function (response) {
                   callback(response);
           });
       }
       
       function updateUser(formData,callback) {
           $http.post('/DashBoard/updateUser',formData)
               .success(function (response) {
                   callback(response);
           });
       }
        function saveNewUser(formData,callback) {
            $http.post('/DashBoard/saveNewUser',formData)
                .success(function (response) {
                    callback(response);
            });
        }

        function newUser(callback) {
            $http.post('/DashBoard/newUser')
                .success(function (response) {
                    callback(response);
            });
        }
        
        function fetchAllUsers(callback) {
            $http.post('/DashBoard/fetchAllUsers')
                .success(function (response) {
                    callback(response);
            });
        }
        

        function setValues(arlUser) {
        	$rootScope.arlUser=arlUser;
        }

    }


})();