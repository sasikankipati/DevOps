﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewProfileController', ViewProfileController);

    ViewProfileController.$inject = ['$location', 'UsersService', 'FlashService'];
    function ViewProfileController($location, UsersService, FlashService,$scope) {
        var vm = this;

        
        (function initController() {
        	UsersService.viewProfile(function (response) {
                if (response.success) {
                	vm.userId=response.objUserVO.userId;
                	vm.userName=response.objUserVO.userName;
                	vm.password=response.objUserVO.password;
                	vm.email=response.objUserVO.email;
                	vm.lanId=response.objUserVO.lanId;
                	vm.adminflag=response.objUserVO.admin;
                	vm.roleId=response.objUserVO.role;
                	vm.mobile=response.objUserVO.mobile;
                	vm.appGroupIds=response.objUserVO.appGroupIds;
                	vm.arlAppGroups=response.arlAppGroups;
                	vm.lsAppGroupIds = response.lsAppGroupIds;
                	vm.arlUserRoles = response.arlUserRoles;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        
        vm.login = login;
        
       
        function login() {
            vm.dataLoading = true;
            
        };
    }

})();
