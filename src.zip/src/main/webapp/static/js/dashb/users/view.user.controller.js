﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('ViewUserController', ViewUserController);

    ViewUserController.$inject = ['$location', 'UsersService', 'FlashService','$routeParams'];
    function ViewUserController($location, UsersService, FlashService,$scope,$routeParams) {
        var vm = this;
        vm.updateUser = updateUser;

        (function initController() {
        	UsersService.viewUser($scope.param1,function (response) {
                if (response.success) {
                	vm.userId=response.objUserVO.userId;
                	vm.userName=response.objUserVO.userName;
                	vm.password=response.objUserVO.password;
                	vm.email=response.objUserVO.email;
                	vm.lanId=response.objUserVO.lanId;
                	vm.adminflag=response.objUserVO.admin;
                	vm.roleId=response.objUserVO.role;
                	vm.mobile=response.objUserVO.mobile;
                	vm.appGroupIds=response.objUserVO.appGroupIds;
                	vm.arlAppGroups=response.arlAppGroups;
                	vm.lsAppGroupIds = response.lsAppGroupIds;
                	vm.arlUserRoles = response.arlUserRoles;
                } else {
                    FlashService.Error(response.message);
                    vm.dataLoading = false;
                }
            });
        })();
        
        function updateUser() {
        	var formData = {
        			userName: vm.userName,
        			password: vm.password,
        			email: vm.email,
        			admin: vm.adminflag,
        			lanId: vm.lanId,
        			role: vm.roleId,
        			mobile: vm.mobile,
        			appGroupIds: vm.appGroupIds,
        			lsAppGroupIds: vm.lsAppGroupIds,
        			userId: vm.userId
              };
             vm.dataLoading = true;
             UsersService.updateUser(formData,function (response) {
                 if (response.success) {
                 	$location.path('/showUsers'); 
                 } else {
                     FlashService.Error(response.message);
                     vm.dataLoading = false;
                 }
             });
        };
        
    }

})();
